# CADERNO DE IMPLEMENTAÇÕES — arquitetura do sistema (aberto 25/08, reordenado 25/08)

**O que é isto:** a lista viva das mudanças que o Luis decidiu fazer no sistema.
**Nada aqui foi executado.** Estados: `ANOTADO` (a discutir) · `DECIDIDO` (Luis cravou,
falta executar) · `FEITO`. Só o Luis muda estado. Sessão nenhuma executa item `ANOTADO`.

---

# REGRA 00 — ONDE MORAM AS COISAS (Luis, 25/08)

> *"Não grave em outro lugar, sempre grava lá — senão a gente fica com várias cópias
> em vários lugares e fica ruim de gerenciar."*

**O arranjo da obra (decidido pelo Luis em 25/08):**

> *"Vou baixar a pasta do GitHub e colocar DENTRO da pasta que o GPT enviou. Essa pasta
> vai ser a ÚNICA em que a gente faz inserções e alterações. Quando finalizar tudo, a
> gente sobe ela e substitui a do GitHub — e depois disso não mexe mais nela: tudo passa
> a ser feito por lá."*

```
DURANTE A OBRA                           DEPOIS DA OBRA
SITE-ATUALIZADO-2026-08-24/              GitHub `truefootball-api`
 ├─ (o sistema/tela, do GPT)      ──►    volta a ser o ÚNICO lugar de código.
 └─ (o repo do GitHub, baixado)  sobe    A pasta local aposenta e não se toca mais.
 = A ÚNICA OFICINA. Toda inserção
   e alteração acontece aqui.
os dados ........................ Supabase (sempre)
coletas brutas (efootballdb) .... matéria-prima: entram no banco com assinatura
```

Regras: (1) arquivo solto FORA da oficina não é fonte — sessão nenhuma trabalha em cima
de cópia avulsa; (2) nenhuma cópia nova nasce em outro canto; (3) na substituição final
do GitHub, o que não foi tocado se preserva — em especial o cofre (`encaixe_B_v159.html.gz`)
e os registros históricos do repo; (4) é SISTEMA, não "site" — vocabulário oficial.

---

# PRINCÍPIO 0 — O BANCO É VIVO (Luis, 25/08)

> *"Esse retrato do banco hoje não é fixo, é dinâmico. Entram insumos diariamente,
> os motores processam e gravam o resultado, e os usuários gravam pelo site."*

O ciclo diário, com os papéis fechados:

```
COLETOR/VIGIA ──grava──► INSUMO (cartas, ímpetos, boxes)      só ele escreve aqui
MOTOR (máquina do Luis, sob ordem dele) ──grava──► RESULTADO  só ele escreve aqui
USUÁRIO (site, com login) ──grava──► a tabela DELE            só ele escreve aqui
                                     (FUTURO: o sistema ainda NÃO está publicado —
                                      esta porta nasce no lançamento)
DERIVADOS (topo, tela, mediana) ── NINGUÉM escreve ──         refazem-se sozinhos
```

Consequências que valem para TODOS os itens deste caderno:
1. Toda mudança de estrutura tem que dizer quem é o escritor diário da tabela e por
   qual porta (qual chave) ele entra. Tabela sem escritor declarado é derivada.
2. O furo das 6.824 cópias foi uma violação disto: escreveram na camada de
   apresentação, que não tem escritor.
3. **Item Z (a rota):** por ser banco vivo (insumos e rodadas continuam entrando mesmo
   sem público), antes de virar a chave roda-se um ACERTO DE DIFERENÇA (o que entrou no
   velho desde a cópia vai pro novo), em janela escolhida pelo Luis, sem rodada de motor
   no meio. Como ainda não há usuários, a janela é livre — sem pressão de tráfego.
5. **Contexto de fase (Luis, 25/08): o sistema está em PRÉ-LANÇAMENTO.** Ainda não foi
   publicado; a otimização atual é preparação para pôr na internet. Os itens A e B são
   condição de qualidade PRÉ-publicação, não conserto emergencial de produção.
4. A coleta do efootballdb (ímpetos/boxes) precisa deixar de ser evento único e virar
   rotina periódica — hoje é script manual no Console (o SOFTWARE-RECOLETA-BOXES já
   existe na máquina do Luis; avaliar encaixe no vigia). `ANOTADO`.

---

# ORDEM DE EXECUÇÃO — decidida pelo Luis em 25/08

> *"A rota de construção tem que ser uma das tarefas, mas tem que ser a ÚLTIMA.
> A gente tem que resolver as outras primeiro."*

```
1º  Conferir as OTIMIZADAS contra a fonte da verdade dos ímpetos  (item A)
2º  O furo do nome das funções                                    (item B)
3º  Auditoria do código no GitHub + inventário dos pedacinhos     (item C)
4º  O ALIMENTADOR — software único de entrada automática          (item I)
5º  Demais consertos no banco/sistema de hoje                     (itens D–H)
ÚLTIMO  A rota das nove fases — o banco novo do lado              (item Z)
```

---

## A · AS OTIMIZADAS FEITAS COM ÍMPETO ERRADO — `DECIDIDO` · PRIORIDADE 1

> Ordem do Luis, 25/08: *"A gente tem que verificar quais [otimizadas] foram feitas com
> ímpetos errados, agora que a gente tem a fonte da verdade. E tem que MARCÁ-LAS pra
> poder refazer. Não posso esquecer disso. É muito importante. Isso é um furo."*

**Contexto:** foi detectado (~600–700 cards) que os ímpetos no sistema estavam errados.
A fonte da verdade agora é o **efootballdb** (coleta completa na máquina do Luis:
24.744 + 5.063 = 29.807 cards, com booster/booster2/booster3 por card + catálogo de 410
ímpetos com efeito por atributo). O banco tem `card_impeto` com 6.626 linhas, sendo
1.977 com id em dúvida e 28 "não sei".

**O plano (3 passos, cada um com prova):**
1. **Montar a verdade:** ler os 31 lotes do efootballdb e extrair, por card, os ímpetos
   nativos reais. Vira uma tabela de conferência no banco (aditiva, não mexe em nada).
2. **Cruzar:** verdade × `card_impeto`/`cards_base` → relatório: quais cards estavam com
   ímpeto errado no insumo. Depois: quais linhas da `builds` (as otimizadas) foram
   calculadas usando esses insumos errados.
3. **Marcar:** as builds atingidas ganham marca de "refazer" (a `builds` já tem o
   mecanismo de fila — `na_fila` — ou coluna própria de suspeita, a decidir na hora).
   ⛔ **Marcar ≠ rodar.** O motor é do Luis, roda na máquina dele, sob ordem dele.

**Pré-requisito:** transferir/ler os ~1,5 GB de lotes (estão em Downloads, conectado).

## B · O FURO DO NOME DAS FUNÇÕES — `DECIDIDO` · PRIORIDADE 2

A função passa a ser chaveada pelo `codigo` (a chave já existe na `funcoes`); apagar as
6.824 cópias com etiqueta da `tela_encaixe` e regenerar da `builds` completa e com
`forca`; o site pergunta por código e mostra o rótulo.
Fatos medidos e pré-requisitos: FKs de `builds`/`molde`/`estilo_valor` → `funcoes(nome)`
tratadas primeiro; gatilhos `atualiza_topos` na jogada; `tela_encaixe` é tabela física
sem FK; 294 pares da `builds` faltam na tela (120 GO def, 44 GO of…).
Consequência visível: 3.574 encaixes voltam ao site (ex.: Neymar 87 recupera a melhor
função dele, 441,4) e o % do topo das 8 funções volta a ter âncora.

## C · AUDITORIA DO CÓDIGO NO GITHUB — `DECIDIDO` (acesso pendente)

Pedido do Luis: olhar o código do sistema (repo `truefootball-api`, privado) atrás de
outros furos como os dois acima. **Acesso combinado: Luis baixa o ZIP do repo
(Code → Download ZIP) para Downloads, que já está conectado.** Sem token no chat.
Sem conector oficial do GitHub no catálogo (verificado 25/08).
Escopo: motores (equação, bônus, otimização), vigia, cargas, scripts SQL — procurar
nome-como-chave, fonte dupla, escrita sem assinatura, constante que devia ser tabela.

## I · O ALIMENTADOR — um software único de entrada de dados — `DECIDIDO`

> Luis, 25/08: *"Eu não posso ficar fazendo essas inserções manualmente. A gente tem que
> desenvolver um software pra fazer isso automático. A gente já tem esse software, só que
> ele está espalhado. Precisa pegar todos esses pedacinhos e colocar num software único."*

**O que ele é:** a esteira de entrada do Princípio 0, automatizada:
`coletar → conferir → subir pro banco (com assinatura) → marcar o que precisa de motor`.
⛔ O Alimentador PARA na marcação — rodar motor continua sendo ordem do Luis, sempre.

**Os pedacinhos espalhados que ele unifica (inventário inicial; o item C completa):**
vigia do Railway (pacotes/boxes, já automático) · scripts de coleta do efHub ·
o coletor do efootballdb (script de Console + SOFTWARE-RECOLETA-BOXES) ·
subir_base / UNIFICAR-BASE / ENVIAR / enviar_continuo · subir_insumos ·
resgatar_da_tela · as cargas SQL avulsas.

**Rumo CRAVADO pelo Luis (25/08):** o Alimentador **roda SOMENTE na máquina dele e
nunca fica online**; o GitHub guarda o código apenas como backup. O vigia do Railway
segue à parte, só para DETECÇÃO.
**MARCO ZERO (Luis, 25/08):** antes do Alimentador virar só-incremental, completar o
retrato do jogo: o jogo tem 42.806 cartas; ímpetos/boxes já estão completos
(efootballdb); faltam ~29.222 fichas do efHub (Tarefa 7 do GPT — 30 lotes, só o 1º
feito). Primeiro fecha-se o estoque, depois o Alimentador só coleta o que vier de novo.

**Pré-requisito:** o inventário do item C (o ZIP do repo) — não dá pra unificar sem ver
todos os pedaços.

## D · CONSERTAR A MED (mediana por função no site) — `ANOTADO`

`Falso nove` e `Centroavante móvel` dividem a mesma mediana na constante `MED` — funções
diferentes (Σ|Δalvo|=93,5). Uma das duas está com régua errada; a `MED` toda é foto
velha. Mediana passa a ser medida do banco, por função.

## E · UMA TABELA DE RESULTADO SÓ — `ANOTADO`

`builds` × `tela_encaixe` discordam (294 pares + a ilha do item B). Rumo: `builds` é o
único depósito; `tela_encaixe` vira derivada com dono único. (Realiza-se por inteiro no
item Z; o item B já elimina a ilha antes disso.)

## F · TIRAR O 1,5 MB DE DADO CONGELADO DO SITE — `ANOTADO`

`dados-e-catalogos.js`: `BONUS_PRONTO` (1.045 KB = cópia da tabela `bonus`),
`CORPO_EFHUB` (308 KB), `CORPO_MOTOR` (127 KB), `PIMP` (30 KB), `CORPO_MOLDE` (14 KB).
O que tem tabela vira consulta; o que não tem, ganha tabela.

## G · TABELA DO USUÁRIO + LOGIN (RLS) — `ANOTADO`

A metade de cima do `user-state-repository.js` que o site novo já traz: tabela por
usuário, escrita só com login, regra de linha `auth.uid()`.

## H · CARGA DO SITE SEM TELA PRETA — `ANOTADO`

Carga inicial síncrona (~13 MB travando a tela); falha de rede apaga o `body` inteiro.
Vira carga assíncrona com erro recuperável e linha mais magra.

## Z · A ROTA DAS NOVE FASES — `DECIDIDO` como ÚLTIMA tarefa

O banco novo das seis camadas construído DO LADO, enchido com o que existe, provado pela
prova dos nove, chave virada consumidor por consumidor. Documento:
`ROTA-2508-CONSTRUIR-O-NOVO-DO-LADO-as-nove-fases.md`. Só começa quando A–H estiverem
resolvidos ou conscientemente dispensados.

---

## REGISTRO DE DECISÕES DE FONTE

- **Ímpetos e boxes: efootballdb. Todo o resto: efHub.** (Luis, 25/08)
- Coletas na máquina do Luis, manifestos conferidos sem falhas (24.744 + 5.063).

## PERGUNTAS ABERTAS

- O cadeado comercial do MODO B (🔒) nas seis páginas do Elenco: fica ou sai?
- `cards_efhub` × `cards_base`: declarar a `cards_base` como única fonte de consulta?
- Respostas do GPT ao `PERGUNTAS-PARA-O-GPT.md` (caderno de pendências dele, história
  dos ímpetos, autoria das cópias da tela_encaixe) — aguardando o Luis colar.
