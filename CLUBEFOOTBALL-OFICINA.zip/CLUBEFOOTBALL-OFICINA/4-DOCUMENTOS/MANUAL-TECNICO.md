# MANUAL TÉCNICO — ClubEfootball / Sistema Encaixe (TrueFootball)
**Documento vivo.** Regra de manutenção (ordem do Luis, 25/08):
o manual descreve **[A] como o sistema ESTÁ hoje** e **[B] como VAI FICAR após as
implementações**. A cada implementação concluída, a sessão que a fez VOLTA aqui,
move o que mudou de B para A e refaz o passo a passo de reconstrução. O manual
nunca descreve um estado que não existe como se existisse.

Versão: **1.0 — 25/08/2026** · fotografia medida no banco, no código e nos
documentos de transferência do GPT.

---

# ═══════════ PARTE A · O SISTEMA COMO ESTÁ HOJE (25/08/2026) ═══════════

## A1 · O QUE O SISTEMA É

O eFootball (Konami) tem milhares de cartas de jogadores. Cada carta pode ocupar
**19 funções** (Ponta criadora, Zagueiro de combate, Goleiro ofensivo…). O sistema
responde a pergunta: **"quanto esta carta vale nesta função, na melhor configuração
possível?"** — escolhendo barras de progressão, ímpeto, técnico e habilidades que
maximizam a nota. O produto final é um site de consulta (ranking, ficha da carta,
boxes, elenco) com modelo comercial de venda de builds otimizadas por posição.

### A1.1 As cinco peças

```
COLETORES  → trazem os dados das fontes (efHub, efootballdb, efScout)
BANCO      → Supabase (Postgres): insumos, resultados e apresentação
MOTORES    → programas Python na máquina do Luis: calculam nota e bônus
SITE       → HTML+JS estático no Netlify: consulta o banco, não calcula
VIGIA      → serviço no Railway: detecta box/carta nova sozinho
```

### A1.2 As regras da casa (imutáveis)

1. O banco é a origem e o destino; arquivo em pasta é cópia descartável.
2. O motor NUNCA roda sem ordem explícita do Luis.
3. A chave secreta (`sb_secret_...`/service_role) só existe no Railway e no
   `config.txt` do motor. NUNCA em HTML, NUNCA no Netlify.
4. A chave publicável (`sb_publishable_...`) é pública de propósito: só lê.
   Quem protege é RLS, não o segredo.
5. Quando não se sabe um número, mostra-se "não sei" — nunca zero, nunca inventado.
6. Nome nunca é chave; chave é código estável (regra nova, 25/08).
7. Fontes da verdade por assunto (25/08): **ímpetos e boxes = efootballdb;
   o resto = efHub**.

---

## A2 · A MATEMÁTICA (os dois motores)

### A2.1 A equação do jogo (`programas/equacao.py`)
A "lei da física": como o eFootball calcula o atributo final a partir de
base + barras + ímpeto + técnico. **Medida no videogame** em 04/08/2026
(265 medições, zero erro). Documento que manda: `AS-DUAS-EQUACOES-NAO-MEXER.md`.
Esta peça não decide nada — só reproduz o jogo.

### A2.2 A régua (`programas/regua.py`)
A "lei do valor": quanto VALE estar acima do alvo do molde e quanto CUSTA estar
abaixo. Régua de dois trechos ancorada em: molde = 92 · mediana da função = 78 ·
teto teórico = 100. Acima do alvo cada ponto vale menos (degraus), do décimo em
diante vale zero. Documento que manda: `NAO-MEXER-formula-do-molde-e-do-motor.md`
(partes 2.4/2.5).

### A2.3 O molde (o que define cada função)
Por função: 26 alvos + 26 pesos (um por atributo). Pesos: 12 = indispensável ·
7/6 = desejável · 3 = útil · 1 = acessório · 0 = não conta. Vive em
`insumo_molde` (494 linhas = 19 funções × 26). O método de montar molde está nas
skills `truefootball-molde` e `truefootball-peso` do projeto.

### A2.4 O motor principal (`programas/motor.py` + `roda_lote_v6.py`)
O executor: escolhe **quatro coisas ao mesmo tempo** — distribuição das barras,
ímpeto fabricado, técnico e as 5 habilidades — para maximizar os pontos do
Bloco 1. Roda a `fila_v6.json` carta×função; tem "entrada quente" (fica olhando
`fila_EXTRA.json` para cartas novas). Resultado: **b1 = a nota**. Grava direto na
tabela `builds` via `grava_direto.py` (lote = 1, com disjuntor de rede).

### A2.5 O motor de bônus (`programas/motor_bonus.py`)
Calcula o que soma sobre o b1: corpo (16 medidas, −2/0/+2/+4), pé ruim,
estilo de jogo da IA (0,4 por COM, teto +2) e estilo. Grava na tabela `bonus`.
**Nota que o usuário vê = builds.b1 + bonus.b_total.**
⚠️ As colunas `nota`, `b1n`, `b2`, `b4`, `b5`, `b4r` da builds são legado 100% NULL.

### A2.6 Regras de negócio dos ímpetos
- Catálogo fabricável: 58 ímpetos; condicionais existem em degraus 1/2/3;
  o ímpeto ADICIONADO por fabricação é sempre +1 (níveis maiores só de fábrica).
- **Regra da vaga (efootballdb, comprovada 24/08):** vaga livre SOMENTE quando
  `booster_type=4` E `booster_sub_type=4` E `up_point=1`. Campos todos nulos =
  SEM ímpeto e SEM vaga (interpretar nulo como vaga foi o erro que gerou os
  870 divergentes).

---

## A3 · O BANCO (Supabase, projeto trqqpsnafpbudtvvicch)

Postgres 17, região sa-east-1. **Todas as tabelas com RLS ligada.** Duas gerações
convivem: o **legado** (schema `public`, o que o site usa) e o **canônico v2**
(schemas `clubef_*_v2`, construído pelo GPT em 24-25/08, ainda não consumido).

### A3.1 PUBLIC — Insumo (o que entra)

| tabela | linhas | o que é |
|---|---:|---|
| `cards_base` | 6.953 | **O CADASTRO.** 1 linha/carta, 93 colunas (nome, ovr, tier, posições, estilo, corpo, pé ruim, 26 atributos, vagas, box…) |
| `cards_efhub` | 10.218 | o cru do efHub, sem tratamento (não consultar; matéria-prima) |
| `card_impeto` | 6.626 | ímpetos por carta, com ESTADO: 3.361 sabido · 28 "não sei" · 1.977 id em dúvida |
| `impeto` / `impeto_atributo` | 428 / 2.158 | catálogo de ímpetos + delta por atributo |
| `boxes` / `box_cards` / `box_card_retratos` / `box_etiquetas` | 1.510 / 107 / 2.601 / 6 | as boxes e seus cards |
| `cards_lancamento` | 12.090 | data de lançamento por carta |
| `faltas` / `coletas` / `arquivos_insumo` | 12.068 / 1 / 3 | controle de completude e proveniência |

### A3.2 PUBLIC — Receita (o que o motor lê)

| tabela | linhas | o que é |
|---|---:|---|
| `funcoes` | 19 | **O DICIONÁRIO**: `nome` (chave atual) · `codigo` (chave estável) · `rotulo` (etiqueta) · família/grupo/posições |
| `insumo_molde` | 494 | alvo+peso por função×atributo (o molde vigente) |
| `molde` / `molde_versao` | 1.430 / 5 | molde histórico e versões |
| `parametros` | 13 | constantes da nota (K, DEG, âncora…) |
| `insumo_tecnico` | 1.664 | os técnicos (usar o ID — há 5 "Mourinho") |
| `insumo_habilidade` | 65 | efeito de cada habilidade (44 comuns competem, 21 raras somam) |
| `insumo_bloqueio` | 246 | habilidade × função proibida |
| `insumo_regra_funcao` | 2 | posição → funções que disputa |
| `estilo_valor` | 144 | valor de cada estilo por função |
| `insumo_impeto_catalogo` | 58 | ímpetos fabricáveis |
| `insumo_player_type` | 137 | tipos de carta (Standard, POTW, Epic…) |
| `traducao` | 438 | de-para de nomes |

### A3.3 PUBLIC — Resultado e apresentação

| tabela | linhas | o que é |
|---|---:|---|
| `builds` | 17.798 | **O RESULTADO**: 1 linha carta×função. Nota = `b1`. FK `funcao→funcoes(nome)`. `funcao_codigo` preenchida 60% |
| `bonus` | 17.668 | o bônus por carta×função (`b_total` soma no b1) |
| `tela_encaixe` | 24.328 | **tabela física** (103 MB): o "prato pronto" que o site lê — 1 JSON de 66 campos por carta×função. ⚠️ contém 6.824 cópias com rótulo no lugar do nome, sem `forca` (defeito aberto) |
| `topos_funcao` | 19 | o topo oficial por função = `tela_encaixe.forca + bonus.b_total`; mantido por 3 triggers na tela_encaixe + 3 na bonus + pg_cron de hora em hora (`private_topos.recalcular_topos_funcao`) |
| `meu_time` | 114 | time do Luis (vira `usuario_estado` no login) |
| views de conferência | — | `impeto_conferir`, `impeto_orfao`, `chave_sem_par` (19), `chave_a_trocar` (3), `falta_de_verdade` (40), `faltas_agora` (4.636), `builds_vigente`, `cards_completos` (view pública controlada, 0 linhas) |

**FKs que amarram o nome:** `builds.funcao`, `molde.funcao`, `estilo_valor.funcao`
→ `funcoes(nome)`. Qualquer renomeação passa por elas.

### A3.4 O MODELO CANÔNICO V2 (schemas do GPT, 24-25/08) — construído, não consumido

| schema.tabela | linhas | o que é |
|---|---:|---|
| `clubef_read_v2.cards_v2` | 42.807 | TODAS as cartas do jogo (42.806 + 1 sentinela) |
| `clubef_read_v2.card_impulses_v2` | 85.612 | slots de ímpeto canônicos — **inclui a correção dos 870** |
| `clubef_read_v2.card_habilidades_v2` | 59.224 | habilidades por carta |
| `clubef_read_v2.boxes_v2` / `card_boxes_v2` | 2.014 / 13.350 | boxes do efootballdb |
| `clubef_read_v2.card_function_targets_v2` | 17.798 | espelho dos alvos carta×função |
| `clubef_read_v2.card_projection_v2` | 3 | a projeção final (rebuild ESTOUROU O ARMAZENAMENTO e foi revertida) |
| `clubef_stage_v2.card_field_lineage_v2` | 677.980 | **781 MB** — proveniência campo a campo |
| `clubef_stage_v2.card_snapshots_v2` | 55.851 | 148 MB — fotografias |
| `clubef_stage_v2.rollback_*` | — | pontos de volta de cada carga |
| `clubef_user_v2.user_builds_v2` | 0 | a tabela do usuário, vazia |

⚠️ `clubef_stage_v2` sozinho ocupa ~950 MB — foi o que esgotou o armazenamento.
Gate de publicação: 3 flags (cadastro nativo / otimização / bônus) — hoje **0 cartas
elegíveis**, por isso `cards_completos` devolve vazio.

---

## A4 · OS PROGRAMAS (o repositório, 66 arquivos em `programas/`)

Cada `.bat` da raiz roda um `.py` de `programas/`. Agrupados por papel:

### A4.1 Coletar (trazem dado de fora)
`o_vigia.py` (roda no Railway: detecta box nova às 4h, puxa ficha, NUNCA roda motor) ·
`gerar_coleta_efhub.py` + Console do Chrome (a API do efHub dá 403 fora do navegador —
o bloco roda no Console e baixa `efhub_fichas.json`) · `coletar_box.py` ·
`coletar_efscout.py` (campanha/box pelo id Konami) · `coletar_vaga_efootballdb.py` ·
`braco_efootballdb.py` (visita só cartas "não sei" e grava com data) ·
`impeto_do_efscout.py` (decodifica o binário efscout_players.bin: 92 bytes/registro).
Coletor efootballdb em massa: script de Console (pasta `EFootballDB Ímpetos`,
lotes de 1.000, manifesto com sha256 — 29.807 cartas coletadas em 23-24/08).

### A4.2 Entrar (põem o coletado na base, com recibo)
`entrar_com_o_efhub.py` (cada campo no lugar, com recibo `recibos_de_coleta.jsonl`,
contraprova `divergencias.json` — fonte que discorda NÃO sobrescreve — e memória
`ja_perguntei.json`) · `entrar_com_as_box.py` · `inserir_novos.py` ·
`separar_os_impetos.py` (nome do ímpeto → id do jogo) · `separar_a_data_do_box.py` ·
`separar_barrinha_de_bonus.py` · `resgatar_da_tela.py` (salva os 8 campos que só
existiam dentro dos HTML antigos) · `unificar_base.py` (monta `base_unica.json`) ·
`monta_catalogo_impeto.py`.

### A4.3 Subir (da pasta para o banco)
`subir_base.py` (→ cards_base) · `subir_os_impetos.py` (→ impeto/impeto_atributo/
card_impeto) · `subir_tradutor.py` (→ funcoes/traducao) · `subir_versoes.py`
(→ molde/versões/md5 dos motores) · `subir_metadados_da_tela.py` · `subir_o_local.py` ·
`backup_base.py` / `backup_do_banco.py` (SEMPRE antes de escrever) ·
`baixar_base.py` (o contrário: banco → pasta).

### A4.4 Calcular (os motores — só com ordem do Luis)
`motor.py` · `equacao.py` · `regua.py` · `funcao_nativa.py` (posição+estilo → a
função nativa única) · `regras_do_card.py` (a regra mora num arquivo só) ·
`roda_lote_v6.py` · `grava_direto.py` · `motor_bonus.py` · `fecha_a_rodada.py` ·
`monta_fila.py` / `alimenta_fila.py` / `por_os_novos_na_frente.py` (a fila) ·
`excecao_de_hoje.py` (exceção que se desfaz sozinha) · `so_o_que_muda_a_conta.py`.

### A4.5 Apresentar (geram a tela e sobem)
`gera_encaixe.py` (troca o `const D` do HTML pelos resultados) · `telas.py` +
`moldes_design.py` (as telas no molde da designer) · `gera_painel.py` (painel
offline com tudo dentro) · `sobe_a_tela.py` / `subir_a_tela.py` /
`subir_as_linhas_agora.py` (upsert na tela_encaixe por (card_id,funcao) —
⚠️ foi este caminho que criou as 6.824 cópias quando os rótulos mudaram;
a subida automática depende do arquivo-sinal `SOBE-A-TELA.txt`) ·
`atualiza_previa_telas.py` · `testar_a_tela.py`.

### A4.6 Conferir (medem, não mudam)
`conferir_fontes.py` (o placar diário fonte×banco) · `contradicoes.py` (o dado
que não pode ser verdade) · `completude_base.py` · `o_que_falta_de_verdade.py` ·
`quem_veio_pela_metade.py` (carta incompleta tem relógio) · `conferir_a_reforma.py` ·
`conferir_no_efootballdb.py` · `o_que_o_banco_tem.py` · `estados.py`
(161.725 campos com estado gravado) · `fila_de_coleta.py` (o que perguntar, a quem,
em que ordem) · `repergunta_impeto.py` / `repergunta_tudo.py` ("não tem" é resposta).

### A4.7 Orquestrar
`rodada_diaria.py` (o ciclo completo 1×/dia à meia-noite — **estrutura pronta,
ligada só quando o Luis mandar**; etapa 8 é a subida da tela) ·
`a_volta_automatica.py` · `montar_a_pasta.py` (copia só o que o sistema usa) ·
`limpar_a_chave_velha.py` · `SUBIR-PRO-GITHUB.bat` (o registro no repositório).

---

## A5 · O SITE (a pasta `1-SISTEMA`, 11 arquivos)

Estático, publicado por **Netlify Drop** (arrastar a PASTA inteira; o HTML
principal deve chamar-se `index.html`). Lê o banco com a chave publicável.

| arquivo | papel |
|---|---|
| `index.html` (26 KB) | a casca: cabeçalho, filtros, abas — carrega os JS abaixo NA ORDEM |
| `dados-e-catalogos.js` (1,5 MB) | blocos 1-7: catálogos + ⚠️ 1,5 MB de dado congelado (BONUS_PRONTO = cópia da tabela bonus; CORPO_*; PIMP) — pendência F |
| `user-state-repository.js` (19 KB) | contrato V2 do estado do usuário (migra MT_v1 → CLUBEFOOTBALL_USER_STATE_V2, com journal transacional) |
| `motor-e-ficha-base.js` (751 KB) | blocos 8-20: a CARGA do banco (síncrona: 2.000 mais fortes + 2×1.000, resto em segundo plano), constantes (ATTRS/FAM/ROT/MED/FUNCOES), espelho do motor na tela, ficha legada (morta por ordem de carga) |
| `elenco.js` (242 KB) | blocos 21-28: Meu time/Elenco, salvar build (`bldSalvaDireto` → `salvaBuildDireta`, caminho único) |
| `ficha-ajustes.js` (339 KB) | blocos 29-31: o controlador da FICHA (`abreCard`→`transita` — `abrir`/`reabrir`/`t6DesenhaFicha` são a MESMA função), moldes da designer, chamadas REST |
| `modulos-elenco-paginas.js` (87 KB) | as 6 páginas novas do Elenco (melhor função, time fraco, técnico, formação, ideal, comparar) + MODO A/B comercial |
| `como-funciona.js/.css` | a página Como calculamos (⚠️ tem o 2º listener de popstate — pendência) |
| `paginas-e-navegacao.js` (30 KB) | blocos 32-38: **RouteState** — dono único de rota/history/render |
| `clubefut.css` (272 KB) | todo o visual |

Estado medido em 25/08: carrega sem erro de JS; 0 setTimeout vazando; `abrir` com
0 camadas; 13 globais ainda duplicadas (2ª definição ganha); falha de rede na carga
inicial apaga o body inteiro (pendência H).

---

## A6 · OS FLUXOS

### A6.1 O ciclo diário (desenho aprovado; automação desligada)
```
1 vigia detecta box/carta nova (Railway, 4h)          [automático]
2 coletas efHub (Console) + efootballdb + efscout      [manual/semiauto]
3 entrar_com_* põe na base, com recibo e contraprova   [bat]
4 unificar + subir_base → cards_base                   [bat]
5 monta_fila → fila carta×função                       [bat]
6 MOTOR roda a fila → grava_direto → builds            [SÓ COM ORDEM DO LUIS]
7 motor_bonus → bonus                                  [idem]
8 gera_encaixe + sobe_a_tela → tela_encaixe            [bat]
9 triggers/cron recalculam topos_funcao                [automático]
10 site (Netlify) lê tela_encaixe + bonus ao vivo      [automático]
```

### A6.2 Publicação
- SITE: Netlify Drop → arrastar a pasta `1-SISTEMA` (HTML = index.html).
  Endereço oficial: https://truefootballapp.netlify.app
- VIGIA: Railway (Redeploy manual; esperar "successful"; testar 2-3×; a variável
  ORIGENS controla o CORS).
- CÓDIGO: GitHub `truefootball-api` (privado) — o registro do que está publicado
  + o cofre (`encaixe_B_v159.html.gz` — NUNCA publicar o monolito).

### A6.3 O modelo comercial (DECISOES-COMERCIAIS, aprovado até 24/08)
Ranking e análise de box: grátis. **Builds otimizadas: o produto pago** — vendidas
por CARD + POSIÇÃO (nunca por função; comprar a posição entrega todas as funções
dela). 1 crédito = 1 build = R$ 1 (provisório). Cada card tem UMA posição grátis
(regra da mediana, a validar). Créditos pré-pagos via Stripe, sem assinatura;
desbloqueio vale 1 ano; build aplicada nunca é removida. Login só quando há algo
a persistir. O que fica escondido: distribuição de pontos, ímpetos, detalhes da
construção (o molde é segredo industrial — a tela nunca expõe a régua).

---

## A7 · COMO RECONSTRUIR O SISTEMA DE HOJE, DO ZERO

1. **Supabase**: criar projeto; rodar os SQLs de `sql/` (23→32) + criar as tabelas
   da Parte 3 (o backup do banco em `backup_do_banco.py` documenta os formatos);
   RLS ligada em tudo; chave publicável só-leitura.
2. **Coletar**: efootballdb em massa (script de Console, lotes de 1.000) para
   ímpetos/boxes; efHub (Console) para fichas; efscout para campanha.
3. **Entrar/Subir**: `entrar_com_*` → `unificar_base` → `subir_base` +
   `subir_os_impetos` + `subir_tradutor` + `subir_versoes`.
4. **Molde**: montar pelos métodos das skills truefootball-molde/peso (ou carregar
   o `insumo_molde` existente). Sem molde não há nota.
5. **Motor**: `monta_fila` → `roda_lote_v6` (com `config.txt` contendo a chave
   secreta) → builds; depois `motor_bonus` → bonus.
6. **Tela**: `gera_encaixe` → `sobe_a_tela` → tela_encaixe; triggers de topos
   (funções `private_topos.*` + pg_cron horário).
7. **Site**: a pasta `1-SISTEMA` no Netlify Drop.
8. **Vigia**: deploy no Railway com a chave secreta e ORIGENS.

---

## A8 · DEFEITOS ABERTOS E DÍVIDAS (fotografia 25/08)

1. **870 cartas com ímpeto divergente** no legado (lista pronta em
   `3-TRANSFERENCIA-GPT/01-IMPETOS/`): 699 prontas p/ reconstrução, 127 ambíguas,
   44 incompletas. Correção só no canônico v2; legado e notas NÃO corrigidos.
2. **6.824 cópias com rótulo** na tela_encaixe (sem `forca`); 3.574 encaixes fora
   do alcance do site; % do topo das 8 funções sem âncora.
3. **294 pares** builds→tela sem espelho (120 GO def, 44 GO of…).
4. **MED duplicada** (Falso nove = Centroavante móvel) + FILA/ESTV idem — régua
   errada numa das duas; origem desconhecida.
5. **1,5 MB de dado congelado** no dados-e-catalogos.js.
6. **2º popstate** (como-funciona.js) e 13 globais duplicadas no site.
7. **Estilo de jogo da IA**: 93% das cartas sem o dado (6.034 de 6.469) — não
   existe fonte de coleta; só resgate de HTML antigo.
8. **Ímpeto condicional +3 < +2** (relato 16/08, não conferido — pode ser a régua
   funcionando; teste descrito no CONSERTOS-PENDENTES item 1).
9. **Armazenamento**: schemas v2 de staging ~950 MB; a projeção estourou o disco.
10. **Chaves vazadas em chat (05/08) ainda não rotacionadas** (secret + publishable
    + ADMIN_TOKEN).
11. Login/RLS de usuário, Stripe e entitlement real: não existem ainda.
12. Elenco estreito/mobile com regressões conhecidas.


---

# ═══════════ PARTE B · COMO O SISTEMA VAI FICAR (o alvo aprovado) ═══════════

O que está aqui é o estado APÓS os itens do CADERNO-DE-IMPLEMENTACOES. Nada disto
existe ainda. Conforme cada item vira FEITO, sua descrição migra para a Parte A.

## B1 · O banco-alvo: as seis camadas
(desenho completo em `DESENHO-2508-O-BANCO-SE-NASCESSE-HOJE`)

```
0 COLETA       toda carga com assinatura (fonte, arquivo, sha, quando)
1 DICIONÁRIOS  função/ímpeto/habilidade/técnico/estilo/box/atributo —
               CÓDIGO estável é a chave; nome é etiqueta trocável
2 A CARTA      cadastro único + ligações (carta_impeto, carta_habilidade)
3 A RECEITA    molde/régua/bloqueios VERSIONADOS (mudou = versão nova)
4 O RESULTADO  UMA tabela build (builds+bonus fundidas), nota_final gerada
               pelo próprio banco; zero coluna morta
5 APRESENTAÇÃO a tela é VIEW do resultado — sem depósito próprio, sem
               segundo cozinheiro (a ilha das 6.824 fica impossível)
6 O USUÁRIO    única mesa com escrita do navegador, login + RLS auth.uid()
```

Decisão pendente do Luis: aproveitar o modelo canônico v2 do GPT
(`clubef_read_v2`, 42.807 cartas) como fundação das camadas 0-2, ou migrar do
legado. Os dois caminhos estão na ROTA-2508 (as nove fases, com acerto de
diferença por ser banco vivo).

## B2 · Correções que estarão aplicadas
- Ímpetos: os 699 reconstruídos no legado, builds atingidas remarcadas e
  recalculadas pelo motor (sob ordem do Luis); os 127 ambíguos e 44 incompletos
  decididos um a um.
- Vocabulário: função chaveada por `codigo`; as 6.824 cópias apagadas;
  tela regenerada completa com `forca`; site pergunta por código e mostra rótulo.
- MED/FILA/ESTV: medianas medidas do banco por função (fim da duplicata
  Falso nove/Centroavante móvel).
- Site: um `popstate` só; zero global duplicada; carga assíncrona com erro
  recuperável (fim da tela preta); dado congelado (1,5 MB) virou consulta.

## B3 · O ALIMENTADOR (decisão do Luis, 25/08)
Software ÚNICO de entrada de dados que unifica os pedacinhos da Parte A4.1-A4.3.
⛔ **Roda SOMENTE na máquina do Luis. Nunca vai ficar online.** O código mora no
GitHub apenas como backup. Esteira: `coletar → conferir → subir com assinatura →
marcar o que precisa de motor` — e PARA na marcação (motor é ordem do Luis).
O vigia do Railway continua existindo à parte, só para DETECÇÃO de box nova.

## B4 · O produto no lançamento
Login (auth do Supabase + `usuario_estado` com RLS) · créditos Stripe pré-pagos ·
venda por card+posição (1 crédito/build, posição grátis pela regra da mediana
após estudo) · desbloqueio válido por 1 ano · entitlement REAL no banco
(MODO_ADM/flag local nunca autorizam conteúdo pago) · ranking e boxes grátis.

## B5 · Reconstrução do zero — versão alvo
A ordem da Parte A7 muda pouco; o que muda: (1) criar as seis camadas com os
dicionários por código; (2) carga com assinatura desde o primeiro arquivo;
(3) motor lê a receita versionada; (4) tela é view — não há passo "subir tela";
(5) usuário nasce com RLS. O passo a passo definitivo será escrito QUANDO o
alvo existir, medido — não antes.

---

# PARTE C · REGISTRO DE ATUALIZAÇÕES DO MANUAL

| versão | data | o que mudou |
|---|---|---|
| 1.0 | 25/08/2026 | primeira fotografia completa (A) + alvo aprovado (B) |
