# PLANO DE AÇÃO — podar as arestas e lançar (25/08/2026)

Integra: o caderno de implementações + as respostas do GPT (transferência de 25/08)
+ as medições no banco + a ordem do Luis (rota das nove fases POR ÚLTIMO; marco zero
antes do alimentador virar só-incremental). Cada etapa diz o que é, a prova de que
fechou, e o que TRAVA o lançamento (🔴) ou não (🟡).

---

## ETAPA 0 🔴 · SEGURANÇA — antes de qualquer publicação
Rotacionar as chaves vazadas em chat em 05/08 (sb_secret, sb_publishable,
ADMIN_TOKEN): Supabase → Settings → API keys → rotate; atualizar config.txt do
motor, vigia no Railway e o site. Pendente desde 05/08.
**Prova:** chave velha devolve 401 em qualquer chamada.

## ETAPA 1 🔴 · ÍMPETOS — a lista dos 870 (item A do caderno)
A lista está PRONTA (`3-TRANSFERENCIA-GPT/01-IMPETOS/LISTA-...V1.csv`): 699
prontos, 127 ambíguos, 44 incompletos. A correção existe só no canônico
(`clubef_read_v2.card_impulses_v2`).
1. Aplicar os 699 no legado (`cards_base`/`card_impeto`) — SQL aditivo com backup.
2. Marcar as builds atingidas (`na_fila`/coluna de suspeita).
3. **Luis roda o motor** nas marcadas; motor_bonus na sequência.
4. Os 127+44: relatório um a um pro Luis decidir.
**Prova:** zero divergência entre legado e canônico nos 699; notas recalculadas.

## ETAPA 2 🔴 · VOCABULÁRIO — o furo dos nomes (item B)
Com os fatos do GPT: as cópias nasceram do upsert do gerador com rótulos (17/08),
`forca` só existe desde 18/08, nada recria sozinho (sem cron/trigger), MAS rodar o
gerador de novo pode reinserir — então o conserto inclui o gerador.
1. Apagar as 6.824 cópias (backup antes).
2. Regerar a tela completa da `builds` (com `forca`; os 294 pares entram).
3. `gera_encaixe`/`sobe_a_tela` passam a escrever por CÓDIGO (nunca mais por rótulo).
4. Site: carrega por código, mostra rótulo.
**Prova:** tela_encaixe = espelho exato da builds (0 órfãos, 0 sem forca);
teste do Neymar 87 (melhor função = 441,4 visível); % topo ≤ 100 nas 19.

## ETAPA 3 🔴 · MARCO ZERO DA COLETA (ordem do Luis, 25/08)
O jogo tem 42.806 cartas (medido no efootballdb). Ímpetos/boxes: já temos TODAS
(29.807 coletadas + regra da vaga). Fichas do efHub: temos ~10.218 — **faltam
~29.222** (é a Tarefa 7 do GPT: 30 lotes, só o 1º saiu). Sem isso o sistema não
retrata o jogo de hoje.
1. Retomar a coleta T7 (Console do efHub, lotes) até fechar os 30.
2. Entrar/subir com recibo e contraprova (esteira existente).
3. Fila → motor (ordem do Luis) para as cartas novas ranqueáveis.
**Prova:** contagem de cartas com ficha ≥ universo do jogo na data; manifesto por lote.
*(O ALIMENTADOR, item I — só na máquina do Luis, GitHub apenas backup — nasce
depois do marco zero e cuida SÓ do incremental.)*

## ETAPA 4 🟡 · SITE — poda fina (itens D, H + pendências 8-10 do GPT)
MED/FILA/ESTV medidas do banco (mata a duplicata FN/CM) · um popstate só ·
13 globais duplicadas limpas · carga sem tela preta (erro recuperável) ·
1,5 MB congelado vira consulta (item F) · homologação visual: abrir Elenco,
Ficha, Ranking, voltar, trocar posição, salvar build, celular.
**Prova:** roteiro de homologação executado 2× sem defeito novo.

## ETAPA 5 🔴 · LOGIN + COMERCIAL DE VERDADE (itens G + decisões comerciais)
Auth Supabase + `usuario_estado` (RLS auth.uid()) · SupabaseAdapter no
user-state-repository (a metade que falta) · créditos/Stripe · entitlement no
banco (posição grátis pela mediana APÓS estudo de impacto) · migração MT_v1
homologada com estado real (hoje só passou em fixtures).
**Prova:** comprar → desbloquear → expirar em conta de teste; flag local não
libera nada.

## ETAPA 6 🟡 · DECISÃO SOBRE O CANÔNICO V2 + ARMAZENAMENTO
O GPT deixou um banco paralelo pronto pela metade (42.807 cartas; projeção
estourou o disco; `clubef_stage_v2` ≈ 950 MB). Decidir: (a) vira a fundação da
rota das nove fases, ou (b) arquiva. Nas duas: liberar o armazenamento
(lineage 781 MB) com critério do GPT (pergunta enviada).
**Prova:** disco < 60% e decisão registrada no caderno.

## ETAPA 7 · LANÇAR
Netlify (pasta 1-SISTEMA, index.html) · Railway conferido · gates: etapas
0,1,2,3,5 fechadas. Pós-lançamento: rota das nove fases (item Z) no ritmo do Luis.

---

## O QUE AINDA PERGUNTAR AO GPT (antes de fechar o escopo)
Arquivo pronto: `PERGUNTAS-PARA-O-GPT-RODADA-2.md` — 8 perguntas: estado real da
Tarefa 7 (29 lotes faltantes), o arquivo-sinal SOBE-A-TELA.txt, o que é seguro
apagar no clubef_stage_v2, o contrato da projeção/cards_completos, os 44
incompletos, por que 0 elegíveis nas flags, FILA/ESTV, artefatos fora do ZIP.
