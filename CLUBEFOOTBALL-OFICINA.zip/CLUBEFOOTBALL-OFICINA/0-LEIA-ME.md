# A OFICINA ORGANIZADA — 25/08/2026

| pasta | o que é | o que fazer com ela |
|---|---|---|
| `1-SISTEMA` | o site (única cópia; o HTML já se chama index.html) | Netlify Drop: arrastar ESTA pasta inteira |
| `2-REPOSITORIO-GITHUB` | o código (programas, sql, bats, encaixe-web) | no fim da obra, sobe substituindo o GitHub |
| `3-TRANSFERENCIA-GPT` | a herança do GPT: lista dos 870 ímpetos, cadernos, SQLs v2 | consulta; a lista dos ímpetos é insumo da Etapa 1 |
| `4-DOCUMENTOS` | MANUAL TÉCNICO · PLANO DE AÇÃO · CADERNO · perguntas p/ GPT | os documentos vivos da obra |

## Por que os nomes de código NÃO foram renomeados
O index.html chama os .js pelo nome; os .bat chamam os .py pelo nome.
Renomear quebraria o sistema. A organização foi por PASTA, não por renome.

## O que ficou DE FORA de propósito (estava duplicado ou é lixo/backup)
- as cópias soltas do site na raiz e a SITE-ATUALIZADO-2026-08-24 (duplicatas exatas)
- TELA-CLUBEFOOTBALL-UNICA.html (versão velha, 23/08)
- checkpoints/ e encaixe-web/arquivo/ (fotos antigas — você já tem backup)
- __pycache__/, graphify-out/, Tranferencia/, *.ANTES-DO-VIGIA*, arquivo de 1 byte
- os chunks de 39 MB do 04-SUPABASE (já aplicados no banco; o zip original fica em Downloads)

## Para trocar a pasta velha por esta (2 minutos)
1. Extraia o ZIP dentro de `Downloads\Clubefootball 2026-08-25`
2. Confira que existem as pastas 0-4 e abra `1-SISTEMA\index.html` (deve carregar o site)
3. Apague da pasta antiga: os 12 arquivos soltos do site, `SITE-ATUALIZADO-2026-08-24`,
   `ClubEfootball-V3-main` e `TELA-CLUBEFOOTBALL-UNICA.html`
