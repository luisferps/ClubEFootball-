begin;
select pg_advisory_xact_lock(hashtextextended('clubef:t4:full-canonical-load:v4',0));

do $preflight$
begin
  if (select count(*) from clubef_stage_v2.card_snapshots_v2 where batch_id=14) <> 42806 then
    raise exception 'batch 14 count drift';
  end if;
  if (select count(*) from clubef_stage_v2.ingestion_readbacks_v2 where batch_id=14 and readback_run_key='full-load-v4' and status='passed') <> 172 then
    raise exception 'batch 14 checkpoint drift';
  end if;
  if (select count(*) from clubef_stage_v2.card_snapshots_v2 where batch_id=15) <> 2080 then
    raise exception 'batch 15 count drift';
  end if;
  if (select count(*) from clubef_stage_v2.ingestion_readbacks_v2 where batch_id=15 and readback_run_key='image-links-v4' and status='passed') <> 9 then
    raise exception 'batch 15 checkpoint drift';
  end if;
  if exists (
    select card_id from clubef_stage_v2.card_snapshots_v2 where batch_id in (3,14)
    group by card_id having count(*) filter(where batch_id=3)>1 or count(*) filter(where batch_id=14)>1
  ) then raise exception 'non-unique source card_id'; end if;
end
$preflight$;

with universe as (
  select card_id,source_record_sha256,'efootballDB' source_domain
  from clubef_stage_v2.card_snapshots_v2 where batch_id=14
  union all
  select b.card_id,b.source_record_sha256,'internal_native_base'
  from clubef_stage_v2.card_snapshots_v2 b
  where b.batch_id=3 and not exists (
    select 1 from clubef_stage_v2.card_snapshots_v2 e where e.batch_id=14 and e.card_id=b.card_id
  )
)
insert into clubef_read_v2.cards_v2(
  card_id,provenance,data_status,validation_status,fields_missing,divergences,
  source_record_sha256,missing_sources,quarantine_reason,input_presence
)
select card_id,jsonb_build_object(
    'load_batch_key','t4.full_canonical_downloaded.2026-08-24.v4',
    'source_domain',source_domain,'source_record_sha256',source_record_sha256,
    'native_authority_pending',true,'impulse_box_authority','eFootballDB'
  ),'pending','parcial',array[]::text[],'[]'::jsonb,source_record_sha256,
  case when source_domain='efootballDB' then jsonb_build_array('internal_native_base') else jsonb_build_array('eFootballDB impulses/boxes') end,
  case when source_domain='efootballDB' then 'native_base_source_absent' else 'efootballdb_domain_source_absent' end,
  '{}'::jsonb
from universe
on conflict(card_id) do nothing;

with base as (
  select s.card_id,s.normalized_payload p,s.source_record_sha256,s.validation_status,
         cb.maximo,cb.estilo_ia,cb.visto_na_casca
  from clubef_stage_v2.card_snapshots_v2 s
  left join public.cards_base cb on cb.card_id=s.card_id
  where s.batch_id=3
)
update clubef_read_v2.cards_v2 c set
  nome=nullif(btrim(b.p->>'nome'),''),
  search_name_normalized=lower(coalesce(b.p->>'nome','')),
  ovr=(b.p->>'ovr')::smallint,max_ovr=(b.p->>'max_ovr')::numeric,
  tier=nullif(b.p->>'tier',''),votos=(b.p->>'votos')::integer,
  posicao_nativa=nullif(b.p->>'posicao_nativa',''),position_id=nullif(b.p->>'position_id',''),
  posicoes_secundarias=case when nullif(b.p->>'posicoes_secundarias','') is null then '{}'::text[]
    else regexp_split_to_array(b.p->>'posicoes_secundarias','/') end,
  estilo_jogo=nullif(b.p->>'estilo_jogo',''),playstyle_id=nullif(b.p->>'playstyle_id',''),
  orcamento=(b.p->>'orcamento')::smallint,level_cap=(b.p->>'level_cap')::smallint,
  atr_ofensividade=(b.p->>'atr_ofensividade')::smallint,
  atr_controle_de_bola=(b.p->>'atr_controle_de_bola')::smallint,
  atr_drible=(b.p->>'atr_drible')::smallint,atr_posse_de_bola=(b.p->>'atr_posse_de_bola')::smallint,
  atr_passe_rasteiro=(b.p->>'atr_passe_rasteiro')::smallint,atr_passe_alto=(b.p->>'atr_passe_alto')::smallint,
  atr_finalizacao=(b.p->>'atr_finalizacao')::smallint,atr_cabeceio=(b.p->>'atr_cabeceio')::smallint,
  atr_cobranca_de_falta=(b.p->>'atr_cobranca_de_falta')::smallint,atr_efeito=(b.p->>'atr_efeito')::smallint,
  atr_velocidade=(b.p->>'atr_velocidade')::smallint,atr_aceleracao=(b.p->>'atr_aceleracao')::smallint,
  atr_potencia_de_chute=(b.p->>'atr_potencia_de_chute')::smallint,atr_salto=(b.p->>'atr_salto')::smallint,
  atr_contato_fisico=(b.p->>'atr_contato_fisico')::smallint,atr_equilibrio=(b.p->>'atr_equilibrio')::smallint,
  atr_resistencia=(b.p->>'atr_resistencia')::smallint,atr_talento_defensivo=(b.p->>'atr_talento_defensivo')::smallint,
  atr_desarme=(b.p->>'atr_desarme')::smallint,atr_envolvimento_defensivo=(b.p->>'atr_envolvimento_defensivo')::smallint,
  atr_agressividade=(b.p->>'atr_agressividade')::smallint,atr_talento_de_goleiro=(b.p->>'atr_talento_de_goleiro')::smallint,
  atr_encaixe=(b.p->>'atr_encaixe')::smallint,atr_defesa_goleiro=(b.p->>'atr_defesa_goleiro')::smallint,
  atr_reflexos=(b.p->>'atr_reflexos')::smallint,atr_alcance=(b.p->>'atr_alcance')::smallint,
  pe_forte=nullif(b.p->>'pe_forte',''),altura=(b.p->>'altura')::smallint,peso=(b.p->>'peso')::smallint,
  idade=(b.p->>'idade')::smallint,pe_ruim_uso=(b.p->>'pe_ruim_uso')::smallint,
  pe_ruim_precisao=(b.p->>'pe_ruim_precisao')::smallint,resistencia_lesao=(b.p->>'resistencia_lesao')::smallint,
  forma=(b.p->>'forma')::smallint,condicao=(b.p->>'condicao')::smallint,
  cap_desbloqueado=(b.p->>'cap_desbloqueado')::boolean,
  corpo_altura=(b.p->'corpo_raw'->>0)::smallint,corpo_coxa=(b.p->'corpo_raw'->>1)::smallint,
  corpo_panturrilha=(b.p->'corpo_raw'->>2)::smallint,corpo_cintura=(b.p->'corpo_raw'->>3)::smallint,
  corpo_peito=(b.p->'corpo_raw'->>4)::smallint,corpo_tamanho_braco=(b.p->'corpo_raw'->>5)::smallint,
  corpo_tamanho_pescoco=(b.p->'corpo_raw'->>6)::smallint,corpo_comprimento_perna=(b.p->'corpo_raw'->>7)::smallint,
  corpo_comprimento_braco=(b.p->'corpo_raw'->>8)::smallint,corpo_comprimento_pescoco=(b.p->'corpo_raw'->>9)::smallint,
  corpo_largura_ombro=(b.p->'corpo_raw'->>10)::smallint,corpo_altura_ombro=(b.p->'corpo_raw'->>11)::smallint,
  atributos_maximos=case when jsonb_typeof(b.maximo)='array' and jsonb_array_length(b.maximo)=26 then b.maximo else null end,
  mestre=nullif(b.p->>'mestre',''),
  provenance=c.provenance||jsonb_build_object('native_base',jsonb_build_object(
    'batch_id',3,'batch_key','t4.existing_base.2026-08-24.v1','record_sha256',b.source_record_sha256,
    'authority','verified internal field consolidation','validation_status',b.validation_status)),
  data_status=case when b.validation_status='valid' then 'ready' else 'pending' end,
  validation_status=case when b.validation_status='valid' then 'validado' else 'parcial' end,
  quarantine_reason=case when b.validation_status='valid' then null else 'native_base_validation_incomplete' end,
  input_presence=jsonb_build_object(
    'native_common_skills','known','native_special_skills','known','remaining_skill_pool','known',
    'ai_playstyles',case when jsonb_typeof(b.estilo_ia)='array' or b.visto_na_casca is true then 'known' else 'unknown' end),
  normalized_at=clock_timestamp()
from base b where c.card_id=b.card_id;

-- Data de lancamento somente quando a lineage consolidada marcou o campo como validado.
with release_valid as (
  select s.card_id,(s.normalized_payload->>'data_lancamento')::date data_lancamento,s.source_record_sha256
  from clubef_stage_v2.card_snapshots_v2 s
  join clubef_stage_v2.card_field_lineage_v2 l on l.batch_id=s.batch_id and l.card_id=s.card_id
    and l.target_field='data_lancamento' and l.lineage_status='validated'
  where s.batch_id=12 and s.normalized_payload->>'data_lancamento' is not null
)
update clubef_read_v2.cards_v2 c set data_lancamento=r.data_lancamento,
  provenance=c.provenance||jsonb_build_object('release_date',jsonb_build_object(
    'batch_id',12,'record_sha256',r.source_record_sha256,'lineage_status','validated'))
from release_valid r where c.card_id=r.card_id;

-- Imagem acessoria: dois links separados, jamais usados pelos tres gates.
with images as (
  select s.card_id,s.normalized_payload p,s.source_record_sha256,s.source_evidence
  from clubef_stage_v2.card_snapshots_v2 s where s.batch_id=15
)
update clubef_read_v2.cards_v2 c set
  image_url=i.p->>'image_cloudinary_url',image_cloudinary_url=i.p->>'image_cloudinary_url',
  image_efhub_source_url=i.p->>'image_efhub_source_url',image_validation_status='validated',
  image_provenance=jsonb_build_object('batch_id',15,
    'batch_key','t4.confirmed_image_links.2026-08-24.v4','primary','Cloudinary',
    'fallback_origin','eFootballHub','source_record_sha256',i.source_record_sha256,
    'source_evidence',i.source_evidence,'accessory_not_completeness_gate',true),
  provenance=c.provenance||jsonb_build_object('images',jsonb_build_object(
    'batch_id',15,'primary','Cloudinary','fallback_origin','eFootballHub')),
  normalized_at=clock_timestamp()
from images i where c.card_id=i.card_id;

delete from clubef_read_v2.card_habilidades_v2 h
using clubef_stage_v2.card_snapshots_v2 s where s.batch_id=3 and h.card_id=s.card_id;

with base as (
  select s.card_id,s.normalized_payload p,s.source_record_sha256,s.validation_status,
         cb.estilo_ia,cb.visto_na_casca
  from clubef_stage_v2.card_snapshots_v2 s left join public.cards_base cb on cb.card_id=s.card_id
  where s.batch_id=3
), expanded as (
  select b.card_id,'native_common'::text tipo,x.nome,x.ord,b.source_record_sha256,b.validation_status from base b
  cross join lateral jsonb_array_elements_text(case when jsonb_typeof(b.p->'habilidades_native_common')='array' then b.p->'habilidades_native_common' else '[]'::jsonb end) with ordinality x(nome,ord)
  union all
  select b.card_id,'native_special',x.nome,x.ord,b.source_record_sha256,b.validation_status from base b
  cross join lateral jsonb_array_elements_text(case when jsonb_typeof(b.p->'habilidades_native_special')='array' then b.p->'habilidades_native_special' else '[]'::jsonb end) with ordinality x(nome,ord)
  union all
  select b.card_id,'remaining_pool',x.nome,x.ord,b.source_record_sha256,b.validation_status from base b
  cross join lateral jsonb_array_elements_text(case when jsonb_typeof(b.p->'habilidades_remaining_pool')='array' then b.p->'habilidades_remaining_pool' else '[]'::jsonb end) with ordinality x(nome,ord)
  union all
  select b.card_id,'ai_playstyle',x.nome,x.ord,b.source_record_sha256,b.validation_status from base b
  cross join lateral jsonb_array_elements_text(case when jsonb_typeof(b.estilo_ia)='array' then b.estilo_ia else '[]'::jsonb end) with ordinality x(nome,ord)
), dedup as (
  select card_id,tipo,btrim(nome) nome,min(ord)::smallint ordem,min(source_record_sha256) source_record_sha256,
         case when bool_and(validation_status='valid') then 'valid' else 'incomplete' end validation_status
  from expanded where nullif(btrim(nome),'') is not null group by card_id,tipo,btrim(nome)
)
insert into clubef_read_v2.card_habilidades_v2(
  card_id,tipo,habilidade_codigo,habilidade_nome,ordem,provenance,data_status,
  validation_status,source_updated_at,normalized_at
)
select card_id,tipo,'name-sha256:'||pg_catalog.encode(extensions.digest(convert_to(lower(nome),'UTF8'),'sha256'),'hex'),
  nome,ordem,jsonb_build_object('source','verified internal native skill arrays','batch_id',3,
    'source_record_sha256',source_record_sha256,'transformation','trim+case-insensitive-name-hash'),
  case when validation_status='valid' then 'ready' else 'pending' end,
  case when validation_status='valid' then 'validado' else 'parcial' end,null,clock_timestamp()
from dedup;

-- Hash final de dominio para a linha; nao usa outputs de motor nem valores legados de impeto/box.
with hashes as (
  select u.card_id,
    pg_catalog.encode(extensions.digest(convert_to(
      coalesce(b.source_record_sha256,'')||'|'||coalesce(e.source_record_sha256,'')||'|'||coalesce(i.source_record_sha256,''),'UTF8'),'sha256'),'hex') combined
  from (select card_id from clubef_stage_v2.card_snapshots_v2 where batch_id=14
        union select card_id from clubef_stage_v2.card_snapshots_v2 where batch_id=3) u
  left join clubef_stage_v2.card_snapshots_v2 b on b.batch_id=3 and b.card_id=u.card_id
  left join clubef_stage_v2.card_snapshots_v2 e on e.batch_id=14 and e.card_id=u.card_id
  left join clubef_stage_v2.card_snapshots_v2 i on i.batch_id=15 and i.card_id=u.card_id
)
update clubef_read_v2.cards_v2 c set source_record_sha256=h.combined from hashes h where c.card_id=h.card_id;

insert into clubef_stage_v2.ingestion_readbacks_v2(
  batch_id,readback_run_key,check_code,check_version,status,expected_payload,actual_payload,
  evidence_sha256,checked_at,checked_by,notes
)
select 14,'canonical-load-v4','phase_1_cards_skills_images','4.0.0','passed',
  jsonb_build_object('canonical_union_cards',42807,'confirmed_images',2080),
  jsonb_build_object('cards',(select count(*) from clubef_read_v2.cards_v2),
    'base_linked',(select count(*) from clubef_read_v2.cards_v2 where provenance ? 'native_base'),
    'image_links_validated',(select count(*) from clubef_read_v2.cards_v2 where image_validation_status='validated'),
    'skills',(select count(*) from clubef_read_v2.card_habilidades_v2)),
  pg_catalog.encode(extensions.digest(convert_to('phase1:42807:2080:'||(select count(*) from clubef_read_v2.card_habilidades_v2)::text,'UTF8'),'sha256'),'hex'),
  clock_timestamp(),'codex-t4','Set-based canonical phase 1; no motor and no public promotion'
on conflict(batch_id,readback_run_key,check_code) do update set
  status=excluded.status,actual_payload=excluded.actual_payload,evidence_sha256=excluded.evidence_sha256,
  checked_at=excluded.checked_at,notes=excluded.notes;

commit;

select count(*) cards,count(*) filter(where provenance ? 'native_base') base_linked,
count(*) filter(where image_validation_status='validated') images_validated,
(select count(*) from clubef_read_v2.card_habilidades_v2) skills
from clubef_read_v2.cards_v2;
