-- Correcao formal de regex: um escape de ponto, nao dois.
insert into clubef_stage_v2.rollback_architecture_objects_v4(object_key,object_definition)
select 'function:clubef_stage_v2.ingest_confirmed_image_links_chunk_v4.pre_regex_fix',
       pg_get_functiondef('clubef_stage_v2.ingest_confirmed_image_links_chunk_v4(text,integer,text,jsonb)'::regprocedure)
on conflict (object_key) do nothing;

do $fix$
declare v_definition text;
begin
  select pg_get_functiondef(
    'clubef_stage_v2.ingest_confirmed_image_links_chunk_v4(text,integer,text,jsonb)'::regprocedure
  ) into strict v_definition;
  if position($old$\\.$old$ in v_definition)=0 then
    raise exception 'expected double-escaped regex not found; refusing drifted patch';
  end if;
  execute replace(v_definition,$old$\\.$old$,$new$\.$new$);
end
$fix$;

alter table clubef_read_v2.cards_v2
  drop constraint if exists cards_v2_cloudinary_card_id_v4_ck;
alter table clubef_read_v2.cards_v2
  add constraint cards_v2_cloudinary_card_id_v4_ck
  check (image_cloudinary_url is null or image_cloudinary_url ~
    ('^https://res\.cloudinary\.com/demsusjwf/image/upload/(v[0-9]+/)?'||card_id||'\.png$'));

revoke all on function clubef_stage_v2.ingest_confirmed_image_links_chunk_v4(text,integer,text,jsonb)
  from public,anon,authenticated;
grant execute on function clubef_stage_v2.ingest_confirmed_image_links_chunk_v4(text,integer,text,jsonb)
  to service_role;
