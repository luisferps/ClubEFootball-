-- Correcao formal para security-definer com search_path vazio.
insert into clubef_stage_v2.rollback_architecture_objects_v4(object_key,object_definition)
select 'function:clubef_stage_v2.ingest_efootballdb_full_chunk_v4.pre_pgcrypto_qualification',
       pg_get_functiondef('clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)'::regprocedure)
on conflict (object_key) do nothing;

do $fix$
declare
  v_definition text;
  v_old text := 'digest(convert_to';
  v_new text := 'extensions.digest(convert_to';
begin
  select pg_get_functiondef(
    'clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)'::regprocedure
  ) into strict v_definition;
  if position(v_old in v_definition)=0 then
    raise exception 'expected unqualified digest call not found; refusing drifted patch';
  end if;
  execute replace(v_definition,v_old,v_new);
end
$fix$;

revoke all on function clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)
  from public,anon,authenticated;
grant execute on function clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)
  to service_role;
