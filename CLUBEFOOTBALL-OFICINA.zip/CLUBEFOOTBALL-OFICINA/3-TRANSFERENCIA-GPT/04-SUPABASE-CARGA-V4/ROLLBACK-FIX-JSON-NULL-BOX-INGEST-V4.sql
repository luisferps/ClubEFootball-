do $rollback$
declare v_definition text;
begin
  select object_definition into strict v_definition
  from clubef_stage_v2.rollback_architecture_objects_v4
  where object_key='function:clubef_stage_v2.ingest_efootballdb_full_chunk_v4.pre_json_null_fix';
  execute v_definition;
end
$rollback$;

revoke all on function clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)
  from public,anon,authenticated;
grant execute on function clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)
  to service_role;
