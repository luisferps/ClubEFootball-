-- Dois links de imagem rastreaveis na linha canonica. Imagem e acessorio.
alter table clubef_read_v2.cards_v2
  add column if not exists image_cloudinary_url text,
  add column if not exists image_efhub_source_url text,
  add column if not exists image_validation_status text not null default 'missing',
  add column if not exists image_provenance jsonb not null default '{}'::jsonb;

do $ddl$
begin
  if not exists (select 1 from pg_constraint where conrelid='clubef_read_v2.cards_v2'::regclass and conname='cards_v2_image_validation_status_v4_ck') then
    alter table clubef_read_v2.cards_v2 add constraint cards_v2_image_validation_status_v4_ck
      check (image_validation_status in ('missing','validated','conflict'));
  end if;
  if not exists (select 1 from pg_constraint where conrelid='clubef_read_v2.cards_v2'::regclass and conname='cards_v2_image_provenance_v4_ck') then
    alter table clubef_read_v2.cards_v2 add constraint cards_v2_image_provenance_v4_ck
      check (jsonb_typeof(image_provenance)='object');
  end if;
  if not exists (select 1 from pg_constraint where conrelid='clubef_read_v2.cards_v2'::regclass and conname='cards_v2_cloudinary_card_id_v4_ck') then
    alter table clubef_read_v2.cards_v2 add constraint cards_v2_cloudinary_card_id_v4_ck
      check (image_cloudinary_url is null or image_cloudinary_url ~
        ('^https://res\.cloudinary\.com/demsusjwf/image/upload/(v[0-9]+/)?'||card_id||'\.png$'));
  end if;
  if not exists (select 1 from pg_constraint where conrelid='clubef_read_v2.cards_v2'::regclass and conname='cards_v2_efhub_card_id_v4_ck') then
    alter table clubef_read_v2.cards_v2 add constraint cards_v2_efhub_card_id_v4_ck
      check (image_efhub_source_url is null or image_efhub_source_url =
        ('https://efimg.com/efootballhub22/images/player_cards/'||card_id||'_l.png'));
  end if;
end
$ddl$;

create or replace function clubef_stage_v2.ingest_confirmed_image_links_chunk_v4(
  p_batch_key text,p_chunk_no integer,p_chunk_sha256 text,p_rows jsonb
) returns jsonb
language plpgsql security definer set search_path=''
as $function$
declare v_batch_id bigint; v_rows integer; v_existing jsonb; v_received integer;
begin
  if p_batch_key <> 't4.confirmed_image_links.2026-08-24.v4'
     or p_chunk_no < 1 or p_chunk_sha256 !~ '^[0-9a-f]{64}$'
     or jsonb_typeof(p_rows) <> 'array' then raise exception 'invalid image chunk envelope'; end if;
  v_rows:=jsonb_array_length(p_rows);
  if v_rows < 1 or v_rows > 250 then raise exception 'invalid image chunk size: %',v_rows; end if;
  if (select count(*) from jsonb_array_elements(p_rows)) <>
     (select count(distinct x->>'card_id') from jsonb_array_elements(p_rows) x)
  then raise exception 'duplicate card_id inside image chunk %',p_chunk_no; end if;
  if exists (
    select 1 from jsonb_array_elements(p_rows) x
    where coalesce(x->>'card_id','') !~ '^[0-9]+$'
       or coalesce(x->>'source_sha256','') !~ '^[0-9a-f]{64}$'
       or (x->>'source_bytes')::bigint <= 0
       or x->>'asset_folder' <> 'clubefutebol/cards/efootballhub'
       or x->>'public_id' <> x->>'card_id'
       or x->>'cloudinary_url' !~ ('^https://res\.cloudinary\.com/demsusjwf/image/upload/(v[0-9]+/)?'||(x->>'card_id')||'\.png$')
       or x->>'efhub_source_url' <> ('https://efimg.com/efootballhub22/images/player_cards/'||(x->>'card_id')||'_l.png')
  ) then raise exception 'invalid image record in chunk %',p_chunk_no; end if;

  select batch_id into strict v_batch_id from clubef_stage_v2.ingestion_batches_v2
  where batch_key=p_batch_key and status='loading';
  select expected_payload into v_existing from clubef_stage_v2.ingestion_readbacks_v2
  where batch_id=v_batch_id and readback_run_key='image-links-v4'
    and check_code=('chunk_'||lpad(p_chunk_no::text,3,'0'));
  if v_existing is not null then
    if v_existing <> jsonb_build_object('chunk_no',p_chunk_no,'rows',v_rows,'payload_sha256',p_chunk_sha256)
    then raise exception 'image chunk % replay conflict',p_chunk_no; end if;
    return jsonb_build_object('chunk_no',p_chunk_no,'rows',v_rows,'status','already_committed');
  end if;

  insert into clubef_stage_v2.card_snapshots_v2(
    batch_id,card_id,source_record_key,source_payload,source_evidence,normalized_payload,
    source_record_sha256,normalized_record_sha256,captured_at,validation_status,
    completeness_status,complete,calculation_ready,publication_ready,
    duplicate_candidate_count,missing_critical_fields,missing_publication_fields,
    missing_optional_fields,conflicts,validation_rule_version,validation_message,validated_at
  )
  select v_batch_id,x->>'card_id','image-links:'||(x->>'card_id'),x,
    jsonb_build_array(jsonb_build_object('manifest_file',x->>'manifest_file',
      'manifest_line',(x->>'manifest_line')::integer,'source_sha256',x->>'source_sha256',
      'source_bytes',(x->>'source_bytes')::bigint,'upload_batch_id',x->>'upload_batch_id')),
    jsonb_build_object('card_id',x->>'card_id','image_cloudinary_url',x->>'cloudinary_url',
      'image_efhub_source_url',x->>'efhub_source_url','image_url',x->>'cloudinary_url',
      'authority',jsonb_build_object('primary','Cloudinary','fallback_origin','eFootballHub')),
    x->>'source_sha256',pg_catalog.encode(extensions.digest(convert_to(x::text,'UTF8'),'sha256'),'hex'),
    clock_timestamp(),'valid','incomplete',false,false,false,1,array[]::text[],array[]::text[],
    array['image_is_accessory_not_publication_gate']::text[],'[]'::jsonb,
    't4-confirmed-image-links-v4.0.0','Two exact links validated by original card_id',clock_timestamp()
  from jsonb_array_elements(p_rows) x on conflict(batch_id,card_id) do nothing;

  if exists (select 1 from jsonb_array_elements(p_rows) x left join clubef_stage_v2.card_snapshots_v2 s
    on s.batch_id=v_batch_id and s.card_id=x->>'card_id'
    where s.card_id is null or s.source_record_sha256<>x->>'source_sha256')
  then raise exception 'existing image snapshot hash mismatch in chunk %',p_chunk_no; end if;

  insert into clubef_stage_v2.ingestion_readbacks_v2(
    batch_id,readback_run_key,check_code,check_version,status,expected_payload,actual_payload,
    evidence_sha256,checked_at,checked_by,notes
  ) values (v_batch_id,'image-links-v4','chunk_'||lpad(p_chunk_no::text,3,'0'),'4.0.0','passed',
    jsonb_build_object('chunk_no',p_chunk_no,'rows',v_rows,'payload_sha256',p_chunk_sha256),
    jsonb_build_object('chunk_no',p_chunk_no,'rows_present',v_rows,'status','committed'),
    pg_catalog.encode(extensions.digest(convert_to(p_chunk_no::text||':'||p_chunk_sha256||':'||v_rows::text,'UTF8'),'sha256'),'hex'),
    clock_timestamp(),'codex-t4','atomic image-link checkpoint; no promotion');
  select count(*) into v_received from clubef_stage_v2.card_snapshots_v2 where batch_id=v_batch_id;
  update clubef_stage_v2.ingestion_batches_v2 set received_count=v_received,
    checkpoint=jsonb_build_object('phase','loading','last_chunk',p_chunk_no,'received',v_received),
    updated_at=clock_timestamp() where batch_id=v_batch_id;
  return jsonb_build_object('chunk_no',p_chunk_no,'rows',v_rows,'received',v_received,'status','committed');
end
$function$;

revoke all on function clubef_stage_v2.ingest_confirmed_image_links_chunk_v4(text,integer,text,jsonb)
  from public,anon,authenticated;
grant execute on function clubef_stage_v2.ingest_confirmed_image_links_chunk_v4(text,integer,text,jsonb)
  to service_role;
