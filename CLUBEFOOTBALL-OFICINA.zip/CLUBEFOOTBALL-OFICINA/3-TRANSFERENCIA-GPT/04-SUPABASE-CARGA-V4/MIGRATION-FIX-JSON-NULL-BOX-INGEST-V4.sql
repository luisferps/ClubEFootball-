-- Correcao formal: JSON null significa ausencia de box e e valido.
insert into clubef_stage_v2.rollback_architecture_objects_v4(object_key,object_definition)
select 'function:clubef_stage_v2.ingest_efootballdb_full_chunk_v4.pre_json_null_fix',
       pg_get_functiondef('clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)'::regprocedure)
on conflict (object_key) do nothing;

do $fix$
declare
  v_definition text;
  v_old text := 'or (x->''box'' is not null and jsonb_typeof(x->''box'') <> ''object'')';
  v_new text := 'or coalesce(jsonb_typeof(x->''box''),''null'') not in (''object'',''null'')';
begin
  select pg_get_functiondef(
    'clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)'::regprocedure
  ) into strict v_definition;
  if position(v_old in v_definition)=0 then
    raise exception 'expected pre-fix predicate not found; refusing drifted patch';
  end if;
  execute replace(v_definition,v_old,v_new);
end
$fix$;

revoke all on function clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)
  from public,anon,authenticated;
grant execute on function clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb)
  to service_role;
