-- T4 / ClubEfootball: materializacao card-centrica e ingestao resumivel.
-- DDL formal. Nao executa motores, nao altera legado nem frontend.

create table if not exists clubef_stage_v2.rollback_architecture_objects_v4 (
  object_key text primary key,
  object_definition text not null,
  captured_at timestamptz not null default clock_timestamp()
);
alter table clubef_stage_v2.rollback_architecture_objects_v4 enable row level security;
alter table clubef_stage_v2.rollback_architecture_objects_v4 force row level security;
revoke all on clubef_stage_v2.rollback_architecture_objects_v4 from public, anon, authenticated;

insert into clubef_stage_v2.rollback_architecture_objects_v4(object_key,object_definition)
select 'function:clubef_read_v2.cards_completos_public_source_v3',pg_get_functiondef('clubef_read_v2.cards_completos_public_source_v3()'::regprocedure)
on conflict (object_key) do nothing;

insert into clubef_stage_v2.rollback_architecture_objects_v4(object_key,object_definition)
select 'view:public.cards_completos',pg_get_viewdef('public.cards_completos'::regclass,true)
on conflict (object_key) do nothing;

insert into clubef_stage_v2.rollback_architecture_objects_v4(object_key,object_definition)
select 'policy:clubef_read_v2.card_projection_v2.card_projection_v2_public_complete_reader_v3',
       jsonb_build_object(
         'policyname',policyname,'permissive',permissive,'roles',roles,'cmd',cmd,
         'qual',qual,'with_check',with_check
       )::text
from pg_policies
where schemaname='clubef_read_v2' and tablename='card_projection_v2'
  and policyname='card_projection_v2_public_complete_reader_v3'
on conflict (object_key) do nothing;

create table if not exists clubef_stage_v2.rollback_card_projection_pre_v4
as table clubef_read_v2.card_projection_v2 with data;
alter table clubef_stage_v2.rollback_card_projection_pre_v4 enable row level security;
alter table clubef_stage_v2.rollback_card_projection_pre_v4 force row level security;
revoke all on clubef_stage_v2.rollback_card_projection_pre_v4 from public, anon, authenticated;

alter table clubef_read_v2.card_projection_v2
  add column if not exists cadastro_nativo_completo boolean not null default false,
  add column if not exists motor_otimizacao_completo boolean not null default false,
  add column if not exists motor_bonus_completo boolean not null default false,
  add column if not exists completo boolean not null default false,
  add column if not exists calculation_ready boolean not null default false,
  add column if not exists publication_ready boolean not null default false,
  add column if not exists completeness_status text not null default 'pendente_validacao',
  add column if not exists quarantine_reason text,
  add column if not exists input_flags_rule_version text not null default 'card-input-flags-v3.0.0',
  add column if not exists input_flags_updated_at timestamptz;

do $ddl$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid='clubef_read_v2.card_projection_v2'::regclass
      and conname='card_projection_v2_three_flags_v4_ck'
  ) then
    alter table clubef_read_v2.card_projection_v2
      add constraint card_projection_v2_three_flags_v4_ck
      check (not publication_ready or
        (cadastro_nativo_completo and motor_otimizacao_completo and motor_bonus_completo));
  end if;
  if not exists (
    select 1 from pg_constraint
    where conrelid='clubef_read_v2.card_projection_v2'::regclass
      and conname='card_projection_v2_completeness_status_v4_ck'
  ) then
    alter table clubef_read_v2.card_projection_v2
      add constraint card_projection_v2_completeness_status_v4_ck
      check (completeness_status in ('completo','incompleto','pendente_validacao'));
  end if;
end
$ddl$;

-- Completa o catalogo fixo das 19 funcoes, sem importar resultados antigos.
insert into clubef_read_v2.function_catalog_v2
  (funcao_codigo,funcao_nome,rotulo,rotulo_curto,familia,grupo,posicoes,legacy_aliases,provenance)
values
  ('goleiro_defensivo','Goleiro defensivo','Goleiro defensivo','defensivo','GOLEIRO','GOLEIRO',array['GK'],array[]::text[],jsonb_build_object('source','motor molde.json + frontend FUNC_POS','purpose','stable input catalog only')),
  ('goleiro_ofensivo','Goleiro ofensivo','Goleiro ofensivo','ofensivo','GOLEIRO','GOLEIRO',array['GK'],array[]::text[],jsonb_build_object('source','motor molde.json + frontend FUNC_POS','purpose','stable input catalog only')),
  ('lateral_defensivo','Lateral defensivo','Lateral defensivo','defensivo','DEFESA','LATERAL',array['LD','LE'],array[]::text[],jsonb_build_object('source','motor molde.json + frontend FUNC_POS','purpose','stable input catalog only')),
  ('lateral_ofensivo','Lateral ofensivo','Lateral ofensivo','ofensivo','DEFESA','LATERAL',array['LD','LE'],array[]::text[],jsonb_build_object('source','motor molde.json + frontend FUNC_POS','purpose','stable input catalog only')),
  ('ponta_criadora','Ponta criadora','Ponta criadora','criadora','ATAQUE','PONTA',array['PD','PE'],array[]::text[],jsonb_build_object('source','motor molde.json + frontend FUNC_POS','purpose','stable input catalog only')),
  ('ponta_finalizadora','Ponta finalizadora','Ponta finalizadora','finalizadora','ATAQUE','PONTA',array['PD','PE'],array[]::text[],jsonb_build_object('source','motor molde.json + frontend FUNC_POS','purpose','stable input catalog only')),
  ('zagueiro_de_combate','Zagueiro de combate','Zagueiro de combate','combate','DEFESA','ZAGUEIRO',array['ZC'],array[]::text[],jsonb_build_object('source','motor molde.json + frontend FUNC_POS','purpose','stable input catalog only')),
  ('zagueiro_de_saida','Zagueiro de saída','Zagueiro de saída','saída','DEFESA','ZAGUEIRO',array['ZC'],array[]::text[],jsonb_build_object('source','motor molde.json + frontend FUNC_POS','purpose','stable input catalog only'))
on conflict (funcao_codigo) do nothing;

create or replace function clubef_stage_v2.ingest_efootballdb_full_chunk_v4(
  p_batch_key text,
  p_chunk_no integer,
  p_chunk_sha256 text,
  p_rows jsonb
) returns jsonb
language plpgsql
security definer
set search_path=''
as $function$
declare
  v_batch_id bigint;
  v_rows integer;
  v_existing jsonb;
  v_received integer;
begin
  if p_batch_key <> 't4.full_canonical_downloaded.2026-08-24.v4'
     or p_chunk_no < 1
     or p_chunk_sha256 !~ '^[0-9a-f]{64}$'
     or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'invalid v4 chunk envelope';
  end if;
  v_rows := jsonb_array_length(p_rows);
  if v_rows < 1 or v_rows > 250 then
    raise exception 'invalid chunk size: %',v_rows;
  end if;
  if (select count(*) from jsonb_array_elements(p_rows)) <>
     (select count(distinct x->>'card_id') from jsonb_array_elements(p_rows) x) then
    raise exception 'duplicate card_id inside chunk %',p_chunk_no;
  end if;
  if exists (
    select 1 from jsonb_array_elements(p_rows) x
    where coalesce(x->>'card_id','') !~ '^[0-9]+$'
       or coalesce(x->>'record_sha256','') !~ '^[0-9a-f]{64}$'
       or jsonb_typeof(x->'slots') <> 'array'
       or jsonb_array_length(x->'slots') <> 2
       or coalesce(jsonb_typeof(x->'box'),'null') not in ('object','null')
  ) then
    raise exception 'invalid record in chunk %',p_chunk_no;
  end if;

  select batch_id into strict v_batch_id
  from clubef_stage_v2.ingestion_batches_v2
  where batch_key=p_batch_key and status='loading';

  select expected_payload into v_existing
  from clubef_stage_v2.ingestion_readbacks_v2
  where batch_id=v_batch_id and readback_run_key='full-load-v4'
    and check_code=('chunk_'||lpad(p_chunk_no::text,3,'0'));
  if v_existing is not null then
    if v_existing <> jsonb_build_object('chunk_no',p_chunk_no,'rows',v_rows,'payload_sha256',p_chunk_sha256) then
      raise exception 'chunk % replay conflict',p_chunk_no;
    end if;
    return jsonb_build_object('chunk_no',p_chunk_no,'rows',v_rows,'status','already_committed');
  end if;

  insert into clubef_stage_v2.card_snapshots_v2(
    batch_id,card_id,source_record_key,source_payload,source_evidence,normalized_payload,
    source_record_sha256,normalized_record_sha256,captured_at,validation_status,
    completeness_status,complete,calculation_ready,publication_ready,
    duplicate_candidate_count,missing_critical_fields,missing_publication_fields,
    missing_optional_fields,conflicts,validation_rule_version,validation_message,validated_at
  )
  select v_batch_id,x->>'card_id','efootballdb:'||(x->>'card_id'),x,
    jsonb_build_array(jsonb_build_object(
      'source_dataset','normalizacao-canonica-42806',
      'source_manifest_sha256','6d289fd0c6bb5ca85c8242b9885f8a112ea95402f0ca62dd5fcec92b56106fd2',
      'source_shard',x->>'source_shard','source_line',(x->>'source_line')::integer,
      'record_sha256',x->>'record_sha256')),
    jsonb_build_object('card_id',x->>'card_id','impulses',x->'slots','box',x->'box',
      'authority',jsonb_build_object('impulses','eFootballDB','boxes','eFootballDB')),
    x->>'record_sha256',
    encode(extensions.digest(convert_to((jsonb_build_object('card_id',x->>'card_id','impulses',x->'slots','box',x->'box'))::text,'UTF8'),'sha256'),'hex'),
    clock_timestamp(),'valid','incomplete',false,false,false,1,
    array['native_card_data_outside_efootballdb_domain']::text[],array[]::text[],array[]::text[],
    '[]'::jsonb,'t4-full-canonical-load-v4.0.0','eFootballDB domains validated; cross-domain flags pending',clock_timestamp()
  from jsonb_array_elements(p_rows) x
  on conflict (batch_id,card_id) do nothing;

  if exists (
    select 1
    from jsonb_array_elements(p_rows) x
    left join clubef_stage_v2.card_snapshots_v2 s
      on s.batch_id=v_batch_id and s.card_id=x->>'card_id'
    where s.card_id is null or s.source_record_sha256 <> x->>'record_sha256'
  ) then
    raise exception 'existing snapshot hash mismatch in chunk %',p_chunk_no;
  end if;

  insert into clubef_stage_v2.ingestion_readbacks_v2(
    batch_id,readback_run_key,check_code,check_version,status,
    expected_payload,actual_payload,evidence_sha256,checked_at,checked_by,notes
  ) values (
    v_batch_id,'full-load-v4','chunk_'||lpad(p_chunk_no::text,3,'0'),'4.0.0','passed',
    jsonb_build_object('chunk_no',p_chunk_no,'rows',v_rows,'payload_sha256',p_chunk_sha256),
    jsonb_build_object('chunk_no',p_chunk_no,'rows_present',v_rows,'status','committed'),
    encode(extensions.digest(convert_to(p_chunk_no::text||':'||p_chunk_sha256||':'||v_rows::text,'UTF8'),'sha256'),'hex'),
    clock_timestamp(),'codex-t4','atomic resumable checkpoint; no promotion in this call'
  );
  select count(*) into v_received from clubef_stage_v2.card_snapshots_v2 where batch_id=v_batch_id;
  update clubef_stage_v2.ingestion_batches_v2
     set received_count=v_received,
         checkpoint=jsonb_build_object('phase','loading','last_chunk',p_chunk_no,'received',v_received),
         updated_at=clock_timestamp()
   where batch_id=v_batch_id;
  return jsonb_build_object('chunk_no',p_chunk_no,'rows',v_rows,'received',v_received,'status','committed');
end
$function$;

revoke all on function clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb) from public,anon,authenticated;
grant execute on function clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb) to service_role;

create or replace function clubef_read_v2.rebuild_all_card_projections_v4()
returns bigint
language plpgsql
security definer
set search_path=''
as $function$
declare v_count bigint;
begin
  with skills as (
    select h.card_id,jsonb_agg(jsonb_build_object(
      'payload_version','card-skill-v2.1.0','tipo',h.tipo,'codigo',h.habilidade_codigo,
      'nome',h.habilidade_nome,'ordem',h.ordem,'data_status',h.data_status,
      'proveniencia',h.provenance,'validacao',h.validation_status
    ) order by h.tipo,h.ordem nulls last,h.habilidade_codigo) payload
    from clubef_read_v2.card_habilidades_v2 h group by h.card_id
  ), impulses as (
    select i.card_id,jsonb_agg(jsonb_build_object(
      'payload_version','card-impulse-v2.1.0','slot',i.slot_no,'campo_fonte',i.source_field,
      'source_role',i.source_role,'estado',i.state,'impeto_id',i.impeto_id,
      'nome',ic.nome,'nome_en',ic.nome_en,'nivel',ic.nivel,'slot_catalogo',ic.slot_catalogo,
      'is_conditional',i.is_conditional,'condition_rule_id',i.condition_rule_id,
      'booster_type',i.booster_type,'booster_sub_type',i.booster_sub_type,
      'booster_category',i.booster_category,'up_point',i.up_point,'deltas',i.deltas,
      'condicoes',i.conditions,'data_status',i.data_status,'proveniencia',i.provenance,
      'validacao',i.validation_status,'campos_ausentes',i.fields_missing,'divergencias',i.divergences
    ) order by i.slot_no) payload
    from clubef_read_v2.card_impulses_v2 i
    left join clubef_read_v2.impulse_catalog_v2 ic on ic.impeto_id=i.impeto_id
    where i.slot_no in (1,2)
    group by i.card_id
  ), positions as (
    select p.card_id,p.funcao_codigo,jsonb_agg(jsonb_build_object(
      'payload_version','card-function-position-v2.1.0','position_id',p.position_id,
      'name',p.position_name,'compatible',p.compatible,'score',p.score,
      'style_active',p.style_active,'style_bonus',p.style_bonus,'total_bonus',p.total_bonus,
      'data_status',p.data_status,'validacao',p.validation_status
    ) order by p.position_id) payload
    from clubef_read_v2.card_function_positions_v2 p group by p.card_id,p.funcao_codigo
  ), functions as (
    select t.card_id,jsonb_agg(jsonb_build_object(
      'payload_version',coalesce(f.payload_version,'card-function-v2.1.0'),
      'function_id',t.funcao_codigo,'funcao_codigo',t.funcao_codigo,'funcao_nome',fc.funcao_nome,
      'legacy_aliases',fc.legacy_aliases,'compativel',t.compativel,'origem_funcao',t.origem_funcao,
      'optimization_result_id',f.optimization_result_id,'bonus_result_id',f.bonus_result_id,
      'global_build_id',f.global_build_id,'data_status',coalesce(f.data_status,t.data_status,'pending'),
      'score_status',coalesce(f.score_status,'pending'),'score',f.forca_apresentacao,
      'forca_bruta',f.forca_bruta,'forca_apresentacao',f.forca_apresentacao,
      'percentual_topo',f.percentual_topo,'top_score',f.topo_funcao,'topo_funcao',f.topo_funcao,
      'top_score_version',f.top_score_version,'top_score_execution_id',f.top_score_execution_id,
      'top_score_complete',coalesce(f.top_score_complete,false),'etiqueta_codigo',f.etiqueta_codigo,
      'barras',f.barras,'atributos_calculados',f.atributos_calculados,
      'habilidades',coalesce(f.habilidades_resultado,'[]'::jsonb),
      'positions',coalesce(p.payload,'[]'::jsonb),
      'tecnico',jsonb_build_object('id',f.tecnico_id,'nome',f.tecnico_nome),
      'optimized_result',jsonb_build_object(
        'result_id',o.result_id,'global_build_id',gb.global_build_id,'input_hash',o.input_hash,
        'input_version',o.input_version,'motor_version',o.motor_version,'status',o.status,
        'computed_at',o.executed_at,'photo',f.resultado_motor,
        'build',case when gb.global_build_id is null then null else jsonb_build_object(
          'version_no',gb.version_no,'points_distribution',gb.points_distribution,
          'total_score',gb.total_score,'technician',gb.technician,'conditions',gb.conditions,
          'skills_used',gb.skills_used,'impulses_used',gb.impulses_used,'status',gb.status) end),
      'bonus_result',jsonb_build_object(
        'result_id',br.result_id,'optimization_result_id',br.optimization_result_id,
        'input_hash',br.input_hash,'motor_version',br.motor_version,'status',br.status,
        'computed_at',br.executed_at,'payload',f.resultado_bonus),
      'bonus_posicoes',f.bonus_posicoes,'impeto_slot_1',f.impeto_slot_1,
      'impeto_slot_2',f.impeto_slot_2,
      'versoes',jsonb_build_object('motor_principal',f.motor_principal_versao,'motor_bonus',f.motor_bonus_versao),
      'execucoes',jsonb_build_object('motor_principal',f.motor_principal_rodado_em,'motor_bonus',f.motor_bonus_rodado_em),
      'proveniencia',jsonb_build_object('target',t.provenance,'resultado',f.provenance),
      'validacao',coalesce(f.validation_status,t.validation_status),
      'campos_ausentes',coalesce(f.fields_missing,'{}'::text[]),
      'divergencias',coalesce(f.divergences,'[]'::jsonb)
    ) order by t.funcao_codigo) payload
    from clubef_read_v2.card_function_targets_v2 t
    join clubef_read_v2.function_catalog_v2 fc on fc.funcao_codigo=t.funcao_codigo
    left join clubef_read_v2.card_functions_v2 f on f.card_id=t.card_id and f.funcao_codigo=t.funcao_codigo
    left join clubef_read_v2.motor_optimization_results_v2 o on o.result_id=f.optimization_result_id
    left join clubef_read_v2.motor_bonus_results_v2 br on br.result_id=f.bonus_result_id
    left join clubef_read_v2.global_optimized_builds_v2 gb on gb.global_build_id=f.global_build_id
    left join positions p on p.card_id=t.card_id and p.funcao_codigo=t.funcao_codigo
    group by t.card_id
  ), boxes as (
    select cb.card_id,jsonb_agg(jsonb_build_object(
      'box_id',b.box_id,'nome',b.nome,'status',b.status,'data_lancamento',b.data_lancamento,
      'data_coleta',b.data_coleta,'payload_version',cb.payload_version,
      'association_state',cb.association_state,'snapshot_historico',cb.snapshot_historico,
      'proveniencia_box',b.provenance,'proveniencia_relacao',cb.provenance,
      'data_status',cb.data_status,'validacao',cb.validation_status,'divergencias',b.divergences||cb.divergences
    ) order by b.data_lancamento desc nulls last,b.box_id) payload
    from clubef_read_v2.card_boxes_v2 cb join clubef_read_v2.boxes_v2 b on b.box_id=cb.box_id
    group by cb.card_id
  ), assembled as (
    select c.*,
      to_jsonb(c) - array['provenance','validation_status','fields_missing','divergences',
        'source_record_sha256','source_updated_at','normalized_at'] as card_payload,
      coalesce(s.payload,'[]'::jsonb) skill_payload,
      coalesce(i.payload,'[]'::jsonb) impulse_payload,
      coalesce(f.payload,'[]'::jsonb) function_payload,
      coalesce(b.payload,'[]'::jsonb) box_payload,
      jsonb_build_object(
        'contract_version','2.1.0','schema_version','cards-completos-schema-2.1.0',
        'payload_version','cards-completos-payload-2.1.0','data_status',c.data_status,
        'proveniencia_card',c.provenance,'source_record_sha256',c.source_record_sha256,
        'source_updated_at',c.source_updated_at,'validation_status',c.validation_status,
        'completude',jsonb_build_object(
          'cadastro_nativo_completo',c.cadastro_nativo_completo,
          'motor_otimizacao_completo',c.motor_otimizacao_completo,
          'motor_bonus_completo',c.motor_bonus_completo,
          'regra_versao',c.input_flags_rule_version,'validado_em',c.input_flags_updated_at),
        'campos_ausentes',c.fields_missing,'divergencias',c.divergences
      ) metadata_payload
    from clubef_read_v2.cards_v2 c
    left join skills s using(card_id) left join impulses i using(card_id)
    left join functions f using(card_id) left join boxes b using(card_id)
  ), contented as (
    select a.*,md5(jsonb_build_object('card',card_payload,'habilidades',skill_payload,
      'impetos',impulse_payload,'funcoes',function_payload,'boxes_resolvidas',box_payload,
      'metadata',metadata_payload)::text) content_hash
    from assembled a
  ), upserted as (
    insert into clubef_read_v2.card_projection_v2(
      card_id,player_id,nome,search_name_normalized,ovr,tier,votos,posicao_nativa,position_id,
      estilo_jogo,playstyle_id,image_url,card_data,habilidades,impetos,funcoes,boxes_resolvidas,
      metadata,data_status,validation_status,contract_version,schema_version,payload_version,
      content_md5,projected_at,cadastro_nativo_completo,motor_otimizacao_completo,
      motor_bonus_completo,completo,calculation_ready,publication_ready,completeness_status,
      quarantine_reason,input_flags_rule_version,input_flags_updated_at)
    select card_id,player_id,nome,search_name_normalized,ovr,tier,votos,posicao_nativa,position_id,
      estilo_jogo,playstyle_id,image_url,card_payload,skill_payload,impulse_payload,function_payload,
      box_payload,metadata_payload,data_status,validation_status,'2.1.0',
      'cards-completos-schema-2.1.0','cards-completos-payload-2.1.0',content_hash,
      clock_timestamp(),cadastro_nativo_completo,motor_otimizacao_completo,motor_bonus_completo,
      completo,calculation_ready,publication_ready,completeness_status,quarantine_reason,
      input_flags_rule_version,input_flags_updated_at
    from contented
    on conflict(card_id) do update set
      player_id=excluded.player_id,nome=excluded.nome,search_name_normalized=excluded.search_name_normalized,
      ovr=excluded.ovr,tier=excluded.tier,votos=excluded.votos,posicao_nativa=excluded.posicao_nativa,
      position_id=excluded.position_id,estilo_jogo=excluded.estilo_jogo,playstyle_id=excluded.playstyle_id,
      image_url=excluded.image_url,card_data=excluded.card_data,habilidades=excluded.habilidades,
      impetos=excluded.impetos,funcoes=excluded.funcoes,boxes_resolvidas=excluded.boxes_resolvidas,
      metadata=excluded.metadata,data_status=excluded.data_status,validation_status=excluded.validation_status,
      contract_version=excluded.contract_version,schema_version=excluded.schema_version,
      payload_version=excluded.payload_version,content_md5=excluded.content_md5,projected_at=excluded.projected_at,
      cadastro_nativo_completo=excluded.cadastro_nativo_completo,
      motor_otimizacao_completo=excluded.motor_otimizacao_completo,
      motor_bonus_completo=excluded.motor_bonus_completo,completo=excluded.completo,
      calculation_ready=excluded.calculation_ready,publication_ready=excluded.publication_ready,
      completeness_status=excluded.completeness_status,quarantine_reason=excluded.quarantine_reason,
      input_flags_rule_version=excluded.input_flags_rule_version,
      input_flags_updated_at=excluded.input_flags_updated_at
    returning 1
  ) select count(*) into v_count from upserted;
  return v_count;
end
$function$;

revoke all on function clubef_read_v2.rebuild_all_card_projections_v4() from public,anon,authenticated;
grant execute on function clubef_read_v2.rebuild_all_card_projections_v4() to service_role;

create or replace function clubef_read_v2.cards_completos_public_source_v3()
returns table(
  card_id text,nome text,posicao_nativa text,estilo_jogo text,image_url text,
  card_data jsonb,habilidades jsonb,impetos jsonb,funcoes jsonb,boxes_resolvidas jsonb,metadata jsonb,
  player_id bigint,search_name_normalized text,ovr smallint,tier text,votos integer,
  position_id text,playstyle_id text,data_status text,validation_status text,
  contract_version text,schema_version text,payload_version text,content_md5 text,projected_at timestamptz,
  completo boolean,completeness_status text,apto_para_calculo boolean,apto_para_publicacao boolean,
  campos_criticos_ausentes text[],campos_publicacao_ausentes text[],campos_opcionais_ausentes text[],
  fontes_ausentes_ou_parciais jsonb,completeness_rule_version text,completeness_validated_at timestamptz,
  complete boolean,cadastro_nativo_completo boolean,motor_otimizacao_completo boolean,motor_bonus_completo boolean
)
language sql stable security definer set search_path=''
as $function$
  select p.card_id,p.nome,p.posicao_nativa,p.estilo_jogo,p.image_url,p.card_data,
    p.habilidades,p.impetos,p.funcoes,p.boxes_resolvidas,p.metadata,p.player_id,
    p.search_name_normalized,p.ovr,p.tier,p.votos,p.position_id,p.playstyle_id,
    p.data_status,p.validation_status,p.contract_version,p.schema_version,p.payload_version,
    p.content_md5,p.projected_at,p.completo,p.completeness_status,p.calculation_ready,
    p.publication_ready,
    coalesce(array(select jsonb_array_elements_text(coalesce(p.card_data->'missing_critical_fields','[]'::jsonb))),'{}'::text[]),
    coalesce(array(select jsonb_array_elements_text(coalesce(p.card_data->'missing_publication_fields','[]'::jsonb))),'{}'::text[]),
    coalesce(array(select jsonb_array_elements_text(coalesce(p.card_data->'missing_optional_fields','[]'::jsonb))),'{}'::text[]),
    coalesce(p.card_data->'missing_sources','[]'::jsonb),p.input_flags_rule_version,
    p.input_flags_updated_at,p.completo,p.cadastro_nativo_completo,
    p.motor_otimizacao_completo,p.motor_bonus_completo
  from clubef_read_v2.card_projection_v2 p
  where p.cadastro_nativo_completo and p.motor_otimizacao_completo and p.motor_bonus_completo
    and p.completo and p.calculation_ready and p.publication_ready
    and p.completeness_status='completo' and p.data_status='ready'
    and p.validation_status in ('validado','aprovado','valid','parcial')
    and p.quarantine_reason is null;
$function$;

revoke all on function clubef_read_v2.cards_completos_public_source_v3() from public;
grant execute on function clubef_read_v2.cards_completos_public_source_v3() to anon,authenticated,service_role;
grant select on clubef_read_v2.card_projection_v2 to clubef_cards_public_reader_v3;
revoke select on clubef_read_v2.cards_v2 from clubef_cards_public_reader_v3;

-- A policy anterior consultava cards_v2. Agora o mesmo gate reside materializado
-- na linha da projecao, permitindo retirar do leitor publico todo acesso a cards_v2.
drop policy if exists card_projection_v2_public_complete_reader_v3
  on clubef_read_v2.card_projection_v2;
create policy card_projection_v2_public_complete_reader_v4
  on clubef_read_v2.card_projection_v2
  for select to clubef_cards_public_reader_v3
  using (
    cadastro_nativo_completo and motor_otimizacao_completo and motor_bonus_completo
    and completo and calculation_ready and publication_ready
    and completeness_status='completo' and data_status='ready'
    and validation_status in ('validado','aprovado','valid','parcial')
    and quarantine_reason is null
  );

create or replace view clubef_read_v2.motor_bonus_input_v2
with (security_invoker=true,security_barrier=true)
as
select x.card_id,x.funcao_codigo,'motor-bonus-input-v4.0.0'::text input_version,
  'sha256'::text input_hash_algorithm,
  encode(digest(convert_to(x.input_payload::text,'UTF8'),'sha256'),'hex') input_hash,
  x.input_payload
from (
  select t.card_id,t.funcao_codigo,jsonb_build_object(
    'card',jsonb_build_object(
      'card_id',c.card_id,'corpo',jsonb_build_array(c.corpo_altura,c.corpo_coxa,c.corpo_panturrilha,
        c.corpo_cintura,c.corpo_peito,c.corpo_tamanho_braco,c.corpo_tamanho_pescoco,
        c.corpo_comprimento_perna,c.corpo_comprimento_braco,c.corpo_comprimento_pescoco,
        c.corpo_largura_ombro,c.corpo_altura_ombro),
      'pe_ruim',jsonb_build_array(c.pe_ruim_uso,c.pe_ruim_precisao),
      'modelo',c.estilo_jogo,
      'com',coalesce((select jsonb_agg(h.habilidade_nome order by h.ordem,h.habilidade_codigo)
        from clubef_read_v2.card_habilidades_v2 h where h.card_id=c.card_id and h.tipo='ai_playstyle'),'[]'::jsonb),
      'visto_na_casca',c.input_presence->>'ai_playstyles'='known'),
    'funcao',jsonb_build_object('codigo',fc.funcao_codigo,'nome',fc.funcao_nome,
      'familia',fc.familia,'grupo',fc.grupo,'posicoes',fc.posicoes),
    'completude',jsonb_build_object('motor_bonus_completo',c.motor_bonus_completo,
      'rule_version',c.input_flags_rule_version),
    'execution_policy',jsonb_build_object('production','external_user_system_only',
      'codex_real_test_max_entries',20,'fail_closed_at',21,'chunking_to_bypass_limit',false),
    'proveniencia',jsonb_build_object('card',c.provenance,'funcao',t.provenance)
  ) input_payload
  from clubef_read_v2.card_function_targets_v2 t
  join clubef_read_v2.cards_v2 c on c.card_id=t.card_id
  join clubef_read_v2.function_catalog_v2 fc on fc.funcao_codigo=t.funcao_codigo
  where c.motor_bonus_completo and t.compativel
) x;

revoke all on clubef_read_v2.motor_bonus_input_v2 from public,anon,authenticated;
grant select on clubef_read_v2.motor_bonus_input_v2 to service_role;

comment on table clubef_read_v2.card_projection_v2 is
  'Materialized one-row-per-card frontend read model. Native card payload, skill roles, two final impulse slots, function projections, accessory boxes and the three persisted input-completeness flags live in the same row.';
