-- Execute apos remover o lote de imagens e antes de remover as colunas.
begin;
drop function if exists clubef_stage_v2.ingest_confirmed_image_links_chunk_v4(text,integer,text,jsonb);
alter table clubef_read_v2.cards_v2
  drop constraint if exists cards_v2_image_validation_status_v4_ck,
  drop constraint if exists cards_v2_image_provenance_v4_ck,
  drop constraint if exists cards_v2_cloudinary_card_id_v4_ck,
  drop constraint if exists cards_v2_efhub_card_id_v4_ck,
  drop column if exists image_cloudinary_url,
  drop column if exists image_efhub_source_url,
  drop column if exists image_validation_status,
  drop column if exists image_provenance;
commit;
