-- Rollback idempotente da migration materialize_canonical_contract_v4.
-- Execute somente apos o rollback do lote de dados v4, se ele tiver sido carregado.

begin;

drop view if exists clubef_read_v2.motor_bonus_input_v2;
drop function if exists clubef_read_v2.rebuild_all_card_projections_v4();
drop function if exists clubef_stage_v2.ingest_efootballdb_full_chunk_v4(text,integer,text,jsonb);

drop policy if exists card_projection_v2_public_complete_reader_v4
  on clubef_read_v2.card_projection_v2;

grant select on clubef_read_v2.cards_v2 to clubef_cards_public_reader_v3;
grant select on clubef_read_v2.card_projection_v2 to clubef_cards_public_reader_v3;

do $rollback$
declare v_definition text;
begin
  select object_definition into strict v_definition
  from clubef_stage_v2.rollback_architecture_objects_v4
  where object_key='function:clubef_read_v2.cards_completos_public_source_v3';
  execute v_definition;
end
$rollback$;

alter function clubef_read_v2.cards_completos_public_source_v3()
  owner to clubef_cards_public_reader_v3;
revoke all on function clubef_read_v2.cards_completos_public_source_v3() from public;
grant execute on function clubef_read_v2.cards_completos_public_source_v3()
  to anon,authenticated,service_role;

drop policy if exists card_projection_v2_public_complete_reader_v3
  on clubef_read_v2.card_projection_v2;
create policy card_projection_v2_public_complete_reader_v3
  on clubef_read_v2.card_projection_v2
  for select to clubef_cards_public_reader_v3
  using (exists (
    select 1 from clubef_read_v2.cards_v2 c
    where c.card_id=card_projection_v2.card_id
      and c.cadastro_nativo_completo and c.motor_otimizacao_completo and c.motor_bonus_completo
      and c.completo and c.calculation_ready and c.publication_ready
      and c.completeness_status='completo' and c.data_status='ready'
      and c.validation_status in ('validado','aprovado','valid','parcial')
      and c.quarantine_reason is null
  ));

delete from clubef_read_v2.card_projection_v2;
insert into clubef_read_v2.card_projection_v2(
  card_id,player_id,nome,search_name_normalized,ovr,tier,votos,posicao_nativa,
  position_id,estilo_jogo,playstyle_id,image_url,card_data,habilidades,impetos,
  funcoes,boxes_resolvidas,metadata,data_status,validation_status,contract_version,
  schema_version,payload_version,content_md5,projected_at
)
select card_id,player_id,nome,search_name_normalized,ovr,tier,votos,posicao_nativa,
  position_id,estilo_jogo,playstyle_id,image_url,card_data,habilidades,impetos,
  funcoes,boxes_resolvidas,metadata,data_status,validation_status,contract_version,
  schema_version,payload_version,content_md5,projected_at
from clubef_stage_v2.rollback_card_projection_pre_v4;

alter table clubef_read_v2.card_projection_v2
  drop constraint if exists card_projection_v2_three_flags_v4_ck,
  drop constraint if exists card_projection_v2_completeness_status_v4_ck,
  drop column if exists cadastro_nativo_completo,
  drop column if exists motor_otimizacao_completo,
  drop column if exists motor_bonus_completo,
  drop column if exists completo,
  drop column if exists calculation_ready,
  drop column if exists publication_ready,
  drop column if exists completeness_status,
  drop column if exists quarantine_reason,
  drop column if exists input_flags_rule_version,
  drop column if exists input_flags_updated_at;

delete from clubef_read_v2.function_catalog_v2
where funcao_codigo in (
  'goleiro_defensivo','goleiro_ofensivo','lateral_defensivo','lateral_ofensivo',
  'ponta_criadora','ponta_finalizadora','zagueiro_de_combate','zagueiro_de_saida'
)
and provenance @> '{"source":"motor molde.json + frontend FUNC_POS","purpose":"stable input catalog only"}'::jsonb;

commit;
