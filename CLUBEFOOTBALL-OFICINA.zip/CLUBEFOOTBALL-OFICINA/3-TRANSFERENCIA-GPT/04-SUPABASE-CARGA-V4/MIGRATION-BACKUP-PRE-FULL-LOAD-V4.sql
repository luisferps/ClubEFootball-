-- Backup verificavel apenas dos objetos paralelos que o lote v4 pode atualizar.
create table if not exists clubef_stage_v2.rollback_cards_pre_full_load_v4
as table clubef_read_v2.cards_v2 with data;
create table if not exists clubef_stage_v2.rollback_skills_pre_full_load_v4
as table clubef_read_v2.card_habilidades_v2 with data;
create table if not exists clubef_stage_v2.rollback_impulses_pre_full_load_v4
as table clubef_read_v2.card_impulses_v2 with data;
create table if not exists clubef_stage_v2.rollback_targets_pre_full_load_v4
as table clubef_read_v2.card_function_targets_v2 with data;
create table if not exists clubef_stage_v2.rollback_card_boxes_pre_full_load_v4
as table clubef_read_v2.card_boxes_v2 with data;
create table if not exists clubef_stage_v2.rollback_boxes_pre_full_load_v4
as table clubef_read_v2.boxes_v2 with data;
create table if not exists clubef_stage_v2.rollback_impulse_catalog_pre_full_load_v4
as table clubef_read_v2.impulse_catalog_v2 with data;
create table if not exists clubef_stage_v2.rollback_projection_pre_full_load_v4
as table clubef_read_v2.card_projection_v2 with data;

do $secure$
declare r record;
begin
  for r in select unnest(array[
    'rollback_cards_pre_full_load_v4','rollback_skills_pre_full_load_v4',
    'rollback_impulses_pre_full_load_v4','rollback_targets_pre_full_load_v4',
    'rollback_card_boxes_pre_full_load_v4','rollback_boxes_pre_full_load_v4',
    'rollback_impulse_catalog_pre_full_load_v4','rollback_projection_pre_full_load_v4'
  ]) rel loop
    execute format('alter table clubef_stage_v2.%I enable row level security',r.rel);
    execute format('alter table clubef_stage_v2.%I force row level security',r.rel);
    execute format('revoke all on clubef_stage_v2.%I from public,anon,authenticated',r.rel);
  end loop;
end
$secure$;

create table if not exists clubef_stage_v2.rollback_full_load_counts_v4 as
select clock_timestamp() captured_at,
  (select count(*) from clubef_read_v2.cards_v2) cards,
  (select count(*) from clubef_read_v2.card_habilidades_v2) skills,
  (select count(*) from clubef_read_v2.card_impulses_v2) impulses,
  (select count(*) from clubef_read_v2.card_function_targets_v2) targets,
  (select count(*) from clubef_read_v2.card_boxes_v2) card_boxes,
  (select count(*) from clubef_read_v2.boxes_v2) boxes,
  (select count(*) from clubef_read_v2.impulse_catalog_v2) impulse_catalog,
  (select count(*) from clubef_read_v2.card_projection_v2) projection;
alter table clubef_stage_v2.rollback_full_load_counts_v4 enable row level security;
alter table clubef_stage_v2.rollback_full_load_counts_v4 force row level security;
revoke all on clubef_stage_v2.rollback_full_load_counts_v4 from public,anon,authenticated;
