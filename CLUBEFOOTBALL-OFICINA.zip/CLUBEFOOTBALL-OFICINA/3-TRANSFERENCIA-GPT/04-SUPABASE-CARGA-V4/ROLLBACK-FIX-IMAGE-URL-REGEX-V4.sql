do $rollback$
declare v_definition text;
begin
  select object_definition into strict v_definition
  from clubef_stage_v2.rollback_architecture_objects_v4
  where object_key='function:clubef_stage_v2.ingest_confirmed_image_links_chunk_v4.pre_regex_fix';
  execute v_definition;
end
$rollback$;

alter table clubef_read_v2.cards_v2 drop constraint if exists cards_v2_cloudinary_card_id_v4_ck;
alter table clubef_read_v2.cards_v2 add constraint cards_v2_cloudinary_card_id_v4_ck
  check (image_cloudinary_url is null or image_cloudinary_url ~
    ('^https://res\\.cloudinary\\.com/demsusjwf/image/upload/(v[0-9]+/)?'||card_id||'\\.png$'));
