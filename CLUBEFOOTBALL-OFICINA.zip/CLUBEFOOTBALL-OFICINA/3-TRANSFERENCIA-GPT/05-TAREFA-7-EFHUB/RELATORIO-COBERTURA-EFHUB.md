# Cobertura real para completar cards no eFootballHub

Gerado em: 2026-08-24T18:24:14.222Z

## Resultado

- Universo de origem com impetos: **37.743 card_id unicos**.
- Ja completos/coletados e excluidos antes de qualquer chamada: **8.521**.
- Universo real faltante: **29.222**.
- Lotes necessarios, com maximo de 1.000: **30**.
- Duplicatas na origem: **0**; IDs invalidos: **0**; ambiguos antes da coleta: **0**.

Relacao de cobertura: **22.58% ja excluidos como existentes** e **77.42% realmente pendentes**.

## Regra de deduplicacao

A chave e somente o **card_id original da Konami**. O conjunto faltante e calculado por diferenca exata entre os IDs com impeto e a uniao de tres provas locais de existencia: CSV completo estritamente validado, cards_base com nucleo conhecido e linhas historicamente coletadas no cards_efhub. Estas ultimas sao excluidas preventivamente mesmo quando o snapshot reduzido nao traz as 72 colunas, para impedir coleta redundante.

Particao conferida: SIM; intersecao faltante/completo: zero.

## Estado inicial do manifesto

| Campo | Quantidade |
|---|---:|
| expected_missing | 29222 |
| already_complete_excluded | 8521 |
| collected | 0 |
| failed | 0 |
| pending | 29222 |
| ambiguous_excluded | 0 |
| inactive_excluded | 0 |

Nenhuma coleta do eFootballHub, upload de imagem ou escrita no Supabase foi executada nesta tarefa.
