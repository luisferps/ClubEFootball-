# Dois caminhos públicos do eFootballHub

## Resultado

Há dois endpoints públicos de jogadores no código atual da página, mas somente um entrega a ficha completa. Não foi encontrado feed oficial/documentado de detalhe completo em lote ou endpoint multi-ID.

| Caminho | Resposta observada | Serve para completar o card? |
|---|---|---|
| `GET /api/public/players?page=N` | 24 resumos por página; paginação | Não |
| `GET /api/public/players/{card_id}` | Uma ficha estruturada completa | Sim |

O coletor V4 permanece no caminho individual. Migrar para a listagem paginada acrescentaria chamadas e ainda exigiria uma ficha individual para cada card.

## Evidência da página pública

A página oficial [Players](https://efhub.com/players?page=1) carrega seu grid com:

`fetch('/api/public/players?' + searchParams)`

O bundle declara a resposta inicial como `{players: [], total: 0, page: 1, limit: 24, totalPages: 0}`. Em uma única abertura normal da página, a resposta observada foi:

- HTTP 200;
- 8.845 bytes;
- 24 players;
- total 47.237;
- limite 24;
- 1.969 páginas.

Não foram percorridas outras páginas e nenhuma ficha individual foi pedida nessa inspeção.

Cada item paginado trouxe 12 chaves: `id`, `imageUrl`, `name`, `nameJa`, `nameZh`, `nationality`, `nationalityCode`, `overallRating`, `playerType`, `position`, `slug` e `team`.

O componente público de card usa esses resumos para link, foto, nome, overall, posição e tipo. Ele não recebe a ficha completa.

## Diferença de cobertura

O contrato desta tarefa exige 34 campos de primeiro nível, além de 26 atributos em `stats` e 16 medidas em `playerModel`.

A listagem omite 22 campos obrigatórios:

`countryId`, `teamId`, `league`, `leagueId`, `additionalPositions`, `age`, `height`, `weight`, `preferredFoot`, `weakFootUsage`, `weakFootAccuracy`, `form`, `condition`, `injuryResistance`, `skills`, `comSkills`, `stats`, `playerModel`, `playerId`, `gpValue`, `datapackId` e `levelCap`.

Já o código público de comparação usa:

`fetch('/api/public/players/' + card_id)`

e só então lê o JSON. As 179 respostas cruas locais desse caminho cobrem o contrato completo e ligam `payload.id` ao `card_id` original da Konami.

## Outros caminhos

`GET /api/public/packs?page=N` é paginado, mas fornece metadados de packs. As páginas de pack permitem identificar cards ligados ao pack, não fornecem `stats`, `playerModel` e demais campos completos.

As páginas HTML `/players/{card_id}` mostram a ficha ao usuário, porém continuam sendo uma página por card. Trocar o JSON pela extração de HTML não reduziria o número de requisições e tornaria o contrato mais frágil. Imagens permanecem proibidas como fonte de atributos.

## Documentação e limites

Não foi localizada documentação pública versionada do eFootballHub para uma API bulk completa, feed de exportação ou endpoint multi-ID. Por isso não foram testados parâmetros não documentados para aumentar `limit`, nem tentativas de evitar 429 usando outra rota, autenticação ou cabeçalhos especiais.

A [página pública de jogadores](https://efhub.com/players?page=29) confirma a paginação do catálogo. A [ficha pública de um jogador](https://efhub.com/pt-BR/players/170522) confirma que o produto disponibiliza o detalhe individual. A [política de privacidade](https://efhub.com/privacy) informa que o serviço monitora uso e busca detectar abuso; isso reforça a decisão de respeitar ritmo, cooldown e `Retry-After`.

## Decisão segura

- Manter `GET /api/public/players/{card_id}`.
- Consultar somente os 29.222 IDs previamente deduplicados.
- Manter execução serial, sonda única, cooldown persistente e 429/rede não terminais.
- Não usar a paginação de resumo antes da ficha individual, pois seria redundante.
- Não testar limites ou feeds não documentados.
- Não alterar checkpoint, `card_id`, exclusão de `boost*`/`box*`, contrato de fotos, Supabase ou Cloudinary.

O arquivo estruturado da auditoria é `AUDITORIA-DOIS-CAMINHOS-EFHUB.json`.
