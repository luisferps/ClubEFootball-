# Correção do HTTP 429 antes da retomada

O coletor autocontido foi atualizado para `t7-efhub-structured-data-and-photos-rate-safe-v4`. Além do tratamento de 429, a V4 corrige o defeito da V3 que classificava HTTP 200 como falha antes do parsing. Não retome com a versão anterior.

## O que acontecerá com o checkpoint existente

Ao carregar a versão corrigida, `await ClubEFT7.diagnosticar()` repara sem rede os registros antigos: 429 volta para `throttled_pending`; os 36 falsos `failed/HTTP 200` da V3 voltam para `transient_pending`. O histórico é preservado.

A migração grava primeiro um cooldown conservador persistente. Portanto, a primeira chamada a `retomar()` pode apenas informar o horário de espera e exportar o estado corrigido, sem enviar rede. Depois do horário indicado, execute novamente a mesma linha; o coletor fará somente uma sonda.

## Passo a passo

1. Cole novamente no Console o arquivo atualizado `COLETAR-CARDS-FALTANTES-EFHUB-CONSOLE.js`.
2. Confirme que aparece `Coletor T7 carregado`.
3. Primeiro execute, sem rede:

   `await ClubEFT7.diagnosticar()`

4. Depois de confirmar o diagnóstico, retome com:

   `await ClubEFT7.retomar()`

5. Se o painel informar cooldown ativo, aguarde até o horário mostrado e repita exatamente a mesma linha.

## Proteções novas

- Limitador estritamente serial: mínimo de 5 segundos mais jitter de até 1,5 segundo.
- Uma única sonda antes da sequência do lote.
- Pausa de 15 segundos depois de uma sonda bem-sucedida.
- HTTP 429 nunca é falha terminal e não consome o `card_id`.
- `Retry-After` em segundos ou data HTTP nunca é encurtado.
- Cooldown exponencial com jitter salvo no IndexedDB e respeitado após recarregar/colar novamente.
- Rede/408/425/5xx usam backoff exponencial com jitter; 429 não recebe retry imediato.
- Os 29 `failed` antigos com evidência de 429 são recuperados automaticamente.
- Checkpoint, hash, partição `37.743 = 8.521 + 29.222`, máximo de 1.000 e não reprocessamento permanecem intactos.
- Se os dados já estiverem salvos e a foto faltar, o estado vira `photo_pending`: a retomada baixa só a imagem, sem repetir a API de dados.
- 429 no servidor de imagens também é não terminal e preserva o JSON já coletado.

## Validação

A variante passou em 27 testes locais e um teste integrado em Chrome com rede interceptada. O teste migrou os 36 registros reais, salvou um HTTP 200 sintético e manteve o 429 seguinte não terminal. Nenhuma coleta real foi executada nesta correção.
