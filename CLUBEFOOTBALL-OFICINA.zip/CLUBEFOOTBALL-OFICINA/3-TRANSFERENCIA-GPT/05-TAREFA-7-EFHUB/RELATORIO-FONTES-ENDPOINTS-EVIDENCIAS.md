# Fontes, endpoint e evidências da Tarefa 7

## Endpoint estruturado confirmado

- Página pública para executar o console: `https://efhub.com/pt-BR/players`.
- JSON por card: `GET https://efhub.com/api/public/players/{card_id}` com credenciais da aba.
- Endpoint auxiliar observado no coletor histórico de pacotes: `GET https://efhub.com/api/public/packs?page={n}`.

Não foi localizada documentação pública versionada da API. O contrato foi confirmado com evidência operacional local: um coletor anterior registrou que a rota de player devolve HTTP 403 fora de uma aba do domínio e HTTP 200 dentro dela; o arquivo local `efhub_fichas.json` conserva 179 respostas cruas, com a fonte `/api/public/players/<id>` e data de coleta. Uma consulta somente leitura desta tarefa também confirmou que a página pública responde e que a chamada direta fora do navegador recebe 403. Nenhuma coleta de card foi executada aqui.

## Estrutura real observada

O contrato observado contém até 37 chaves de primeiro nível, incluindo `id`, identidade e nomes, clube/liga/posição, estilo, overall, idade, altura, peso, pé, condição, habilidades, tipos de card, boosts, limite de nível, URL de imagem, `stats` e `playerModel`. Em 23 das 179 respostas locais o campo opcional `playingStyle` foi omitido; essa ausência legítima não invalida o card.

O objeto `stats` tem 26 atributos numéricos. `playerModel` tem 16 medidas numéricas. As listas `additionalPositions`, `skills` e `comSkills` permanecem estruturadas. O contrato exato e as nulabilidades aceitas estão em `CONTRATO-CAMPOS-EFHUB.json`.

## Cobertura calculada sem rede

| Conjunto | Quantidade |
|---|---:|
| IDs únicos com ímpetos | 37.743 |
| Já completos/coletados, excluídos | 8.521 |
| Faltantes reais (`expected_missing`) | 29.222 |
| Lotes de até 1.000 | 30 |

A exclusão é a união por `card_id` de:

1. 9.719 linhas do CSV eFootballHub completo que passam por identidade, núcleo, 26 atributos, 16 medidas, arrays e timestamp; 8.146 delas pertencem ao universo com ímpetos.
2. 2.471 cards numéricos de `cards_base` cujo mapa de proveniência declara conhecido todo o núcleo exigido; 1.797 pertencem ao universo.
3. 9.881 linhas de `cards_efhub` com `card_id`, nome, posição e timestamp de coleta válidos; 8.296 pertencem ao universo. Destas, 26 só foram provadas pelo snapshot de coleta e foram excluídas preventivamente para não baixar novamente.

A união dentro do universo é 8.521; portanto, 37.743 − 8.521 = 29.222. Os arquivos faltante/excluído não têm interseção, não há duplicatas nem IDs inválidos na origem e a partição foi conferida automaticamente.

## Contrato de foto

O coletor só aceita como reserva/origem a URL observada em `imageUrl` quando ela coincide exatamente com:

`https://efimg.com/efootballhub22/images/player_cards/{card_id}_l.png`

Ele grava `cloudinary_url: null`, `efhub_source_url`, a URL observada, o estado da validação e a prioridade `cloudinary_url` → `efhub_source_url`. Não baixa a imagem, não deriva atributos dela e não faz upload.

## Evidência técnica

- A lista faltante tem SHA-256 `143955ff35d922f5d6ff10ee9045f7f970fe35fe814e3781058a78aae4b66821`.
- O snapshot somente leitura tem SHA-256 `8f5a056a65a78ad9aea0b5f37b2aaef5d36a712147e46ccbddfa37ba92104f87`.
- O CSV completo tem SHA-256 `e33e1a1d939b9ef2df21aacdc71aa6948bddbfaaa661b40fb25262f20cf8c2b5`.
- Vinte e um testes locais passaram. Além das 179 respostas estruturadas e das 179 URLs de foto salvas, a variante autocontida foi carregada em ambiente sintético com zero chamadas de rede; sua lista embutida reproduziu byte a byte os 29.222 IDs e não contém seletor de arquivo. Respostas 429 sintéticas, `Retry-After` numérico/data HTTP, cooldown exponencial, transformação do checkpoint antigo de `failed` para `throttled_pending` e sonda única serial também foram validados. Permanecem cobertos contrato, identidade divergente, payload incompleto, foto divergente, lotes, partição, hash, HTTP, estados terminais, manifesto, chaves da fixture e ausência de escrita/upload/OCR.
- `AMOSTRA-VALIDADA-LOCAL-EFHUB.json` conserva uma resposta crua previamente salva, sua validação, hash, proveniência e três casos negativos simulados, sem disparar nova coleta.

Estado desta entrega: script pronto para o usuário executar em batches; coleta real ainda não iniciada.
