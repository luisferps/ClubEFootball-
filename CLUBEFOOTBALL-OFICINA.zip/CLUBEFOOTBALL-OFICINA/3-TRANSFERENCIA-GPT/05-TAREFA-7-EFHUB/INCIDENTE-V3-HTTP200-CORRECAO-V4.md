# Incidente V3: HTTP 200 classificado como falha

## Evidência preservada

O arquivo exportado pelo Chrome foi preservado sem alteração como `EVIDENCIA-INCIDENTE-V3-36-FALHAS-HTTP200.jsonl`.

- Origem: `C:\Users\Luis Fernando\Downloads\T7-EFHUB-DADOS-E-FOTOS-143955ff-29222-IDS__LOTE-0001-DE-0030__DADOS__07-falhas.jsonl`
- SHA-256: `5c9d96f7f83e88cbc006a40367ebb55db0cb1624716954184b0bfda3979b75ea`
- 36 linhas, 36 `card_id` únicos.
- Todos têm `status: failed`, `attempts: 1`, `reason: HTTP 200` e `http_status: 200`.
- Nenhum tem `validation_details`, `raw_response_sha256` ou dados salvos.

## Causa

A V3 chamava `classifyHttp(response.status)` antes de `response.json()`. A função não tinha ramo de sucesso para 2xx; por isso HTTP 200 caía no retorno padrão `failed`. O corpo jamais era lido ou validado.

Logo, o incidente não foi causado por rate limit, foto, Content-Security Policy ou endpoint alternativo.

## Endpoint confirmado

O contrato correto por card continua sendo `GET https://efhub.com/api/public/players/{card_id}` dentro da aba do domínio.

Evidências locais, sem nova rede:

- `efhub_fichas.json` contém 179 respostas cruas válidas e registra a fonte `/api/public/players/<id>`.
- Os coletores anteriores `gerar_coleta_efhub.py` e `o_vigia.py` usam essa rota e fazem o parsing apenas depois de confirmar `response.ok`.
- Os próprios 36 registros do incidente confirmam HTTP 200 nessa rota.

A outra forma visual/de página não é usada como fonte de atributos. Imagens continuam sem responsabilidade por atributos.

## Correção V4

- Todo status 2xx é classificado como `success` e segue para `response.json()`.
- Os 36 falsos `failed/HTTP 200` voltam automaticamente para `transient_pending`, com tentativas zeradas e evidência anterior anexada em `recovery_history`.
- HTTP 429 continua `throttled_pending` e não terminal.
- Falha de rede, JSON transitório, 408/425/5xx e esgotamento transitório permanecem pendentes; não viram `failed`.
- Incompatibilidade real de schema interrompe o lote no primeiro card como `schema_pending`, evitando cascata de milhares de falhas.
- `await ClubEFT7.diagnosticar()` migra e mostra o estado sem fazer rede.

## Validação sem rede real

- 27 testes locais aprovados.
- Teste integrado em Chrome headless com todas as requisições interceptadas:
  - 36/36 registros reais migrados para pendentes;
  - um HTTP 200 sintético foi lido, validado e salvo;
  - o HTTP 429 seguinte interrompeu o lote sem falha terminal;
  - resultado sintético: `collected 1`, `failed 0`.
