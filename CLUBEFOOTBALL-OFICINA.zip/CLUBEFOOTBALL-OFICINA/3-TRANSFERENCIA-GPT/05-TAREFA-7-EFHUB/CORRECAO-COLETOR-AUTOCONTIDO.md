# Correção imediata: coletor autocontido

O arquivo principal `COLETAR-CARDS-FALTANTES-EFHUB-CONSOLE.js` foi substituído pela variante autocontida. Os 29.222 IDs estão embutidos e protegidos pelo mesmo SHA-256 `143955ff35d922f5d6ff10ee9045f7f970fe35fe814e3781058a78aae4b66821`.

## Para sair do bloqueio atual

1. Cancele o seletor que ficou aberto, usando **Cancelar** ou `Esc`.
2. Use a versão atualizada de `COLETAR-CARDS-FALTANTES-EFHUB-CONSOLE.js` e cole seu conteúdo inteiro no Console da aba `https://efhub.com/pt-BR/players`.
3. Confirme a mensagem: `Lista de IDs embutida; nenhum seletor de arquivo sera aberto.`
4. Somente quando quiser iniciar o primeiro lote, execute:

   `await ClubEFT7.iniciar()`

Colar o arquivo apenas carrega as funções e **não inicia coleta**. `iniciar()` valida internamente contagem, hash e a partição `37.743 = 8.521 excluídos + 29.222 faltantes` antes de qualquer chamada.

O script não possui seletor de arquivo nem seletor de pasta. Os artefatos irão para Downloads com prefixos legíveis de tarefa/lote; nenhuma pasta-base é solicitada.

Checkpoint, máximo de 1.000 por lote, não reprocessamento, retries, exclusões fail-closed e retomada por `await ClubEFT7.retomar()` foram preservados.

## Validação sem coleta real

- Sintaxe JavaScript válida.
- 29.222 IDs embutidos idênticos ao arquivo auditável.
- SHA-256 idêntico.
- Partição exata preservada.
- Nenhum seletor de arquivo no código.
- Zero chamadas de rede ao carregar a variante.
- Vinte e um testes sintéticos/locais aprovados após a correção de rate limit, incluindo HTTP 429, `Retry-After` e migração do checkpoint antigo.
- Nenhuma coleta real, escrita no Supabase ou upload executado.
