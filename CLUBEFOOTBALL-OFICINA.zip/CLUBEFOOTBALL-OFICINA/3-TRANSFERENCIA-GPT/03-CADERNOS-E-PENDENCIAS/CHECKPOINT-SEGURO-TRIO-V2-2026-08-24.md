# Checkpoint transacional seguro — Tarefa 4

**Capturado em:** 2026-08-24  
**Motivo:** janela curta antes do desligamento do computador  
**Estado:** seguro para encerrar e retomar; nenhuma transação aberta ou escrita pendente.

## Estado persistido no Supabase

- Projeto `trqqpsnafpbudtvvicch` saudável.
- Última migration aplicada e confirmada no histórico:
  - versão `20260824083039`;
  - nome `complete_pending_functions_sample_3_v2`.
- A transação foi encerrada com sucesso às `2026-08-24T08:30:40Z`.
- Execução de projeção `run_id=2`, `status=completo`, `trigger_kind=authorized-pending-completion`.
- Manifesto do run:
  - `added_pairs=17`;
  - `final_pairs=20`;
  - `projected_cards=3`;
  - `ready_functions=20`;
  - `pending_functions=0`;
  - `legacy_outputs_associated=false`;
  - `idempotence_verified=true`.
- Contagens atuais:
  - 3 cards canônicos;
  - 20 targets;
  - 20 resultados principais atuais;
  - 20 resultados de bônus atuais;
  - 20 builds globais atuais;
  - 20 `card_functions`;
  - 4 variantes de posição pendentes/parciais;
  - 3 linhas em `public.cards_completos`;
  - 0 builds de usuário para o trio.
- Hashes atuais da porta:
  - Luka: `eb4e4098d64b5f1448e24167b6299db5`;
  - Diego: `69e95fc002dafea8004bb6e3805531e1`;
  - Jude: `ae69bd1c2f6622999f30bffcdb907a72`.
- Os fingerprints das 12 relações legadas permanecem iguais ao baseline; detalhes no relatório do HTTP 500.
- Às `08:40:00Z` não havia sessão ativa externa, lock não concedido, lock nas relações legadas nem PID bloqueador.

## Arquivos de recuperação

- Migration aplicada: `MIGRATION-COMPLETAR-FUNCOES-TRIO-V2.sql`.
- Rollback incremental preparado e **não executado**: `ROLLBACK-COMPLETAR-FUNCOES-TRIO-V2-NAO-EXECUTADO.sql`.
- Evidência estruturada: `EVIDENCIA-VALIDACAO-COMPLETUDE-FUNCOES-TRIO-V2.json`.
- Relatório de completude: `RELATORIO-COMPLETUDE-FUNCOES-TRIO-V2.md`.
- Diagnóstico do timeout: `RELATORIO-DIAGNOSTICO-HTTP-500-57014.md`.

## Retomada idempotente

1. Consultar o histórico de migrations.
2. Se `20260824083039_complete_pending_functions_sample_3_v2` existir, **não reaplicar** a migration nem recarregar os 17 pares.
3. Confirmar `projection_runs_v2.run_id=2` e os três `content_md5` acima.
4. Confirmar 20 current results/bonus/builds e zero grupos current duplicados.
5. Continuar somente após homologação; qualquer nova fase deve usar uma nova migration versionada.

O script de carga também é protegido por preflight de contagens e hashes, mas o histórico de migration é o gate primário para impedir repetição.

## Operações ainda pendentes por decisão/gate

- homologação da amostra de três cards;
- produção de top scores/percentuais e scores completos por posição, se autorizada;
- ativação de adaptador/feature flag e migração página por página;
- ampliação para os outros 42.803 cards;
- qualquer execução em lote.

Nenhuma dessas operações foi iniciada. Não há tarefa de banco estimada acima de 30 minutos em execução. O ponto atual é transacionalmente seguro para desligar o computador.

