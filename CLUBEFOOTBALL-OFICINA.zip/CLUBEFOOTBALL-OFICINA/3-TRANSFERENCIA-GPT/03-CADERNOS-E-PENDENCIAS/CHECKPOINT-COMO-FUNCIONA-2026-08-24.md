# Checkpoint — aba Como funciona

Data: 2026-08-24

## Estado

- Implementação funcional presente; a Tarefa 6 permanece aberta para as homologações manuais restantes.
- Checkpoint de encerramento gravado antes do desligamento: nenhum processo, coleta, carga, migration ou motor foi iniciado nesta etapa final; o servidor local usado na verificação anterior foi encerrado normalmente.
- Reload real aprovado pelo usuário: `Elenco -> Ctrl+Shift+R -> Elenco`.
- A nova integração não regrediu o boot nem a restauração da rota do Elenco.
- O design e o layout da página foram aprovados diretamente pelo usuário e preservados integralmente na revisão de escopo.
- Gate visual do conteúdo revisado aprovado diretamente pelo usuário: aba marcada, título visível e nenhum texto cortado.
- Gate manual de retorno aprovado diretamente pelo usuário: partindo do Elenco, abriu `Como funciona`, clicou uma vez em `← Voltar ao início` e confirmou o retorno ao Início e a saída da rota/aba `Como funciona`.
- Gate real de abertura e reload aprovado diretamente pelo usuário: abriu `Como funciona` normalmente, recarregou a página e ela permaneceu correta. A origem anterior não foi presumida; pode ter sido `Melhor função de cada um`.
- Gate real de Back reprovado antes da correção: o conteúdo voltou para `Melhor função de cada um`, mas a aba global Ranking ficou marcada.
- Restauração aplicada no dono canônico de navegação: `melhorfuncao`, `timefraco`, `melhorformacao`, `tecnicotime` e `comparartime` passam a marcar Elenco depois de abertura, reload, Back e Forward; somente a rota `ranking` marca Ranking.
- Gate real pós-correção aprovado: após reload e abertura de `Melhor função de cada um`, a aba global Elenco ficou marcada e Ranking permaneceu desmarcada. Ações posteriores em Titulares/Calcular pertencem à Tarefa 5 e não integram esta validação.
- Gate real de Back pós-correção reprovado parcialmente: a rota voltou para `Melhor função de cada um`, porém os 7 resultados não foram restaurados, a tela retornou à escolha de grupo e as fotos apareceram duplicadas. A marcação da aba global não foi considerada confirmada neste gate.
- Correção integrada após a reprovação real: o `RouteState` agora mantém um payload JSON privado, limitado e clonado por entrada; o módulo `Melhor função de cada um` salva e restaura somente fase/grupo, IDs de ocorrência e a projeção sanitizada dos resultados já visíveis.
- Entradas antigas ou novas sem payload continuam válidas; reload em novo documento, Back e Forward recebem `opcoes.pageState` sem expor o payload na URL, `localStorage` ou `sessionStorage`.
- Lifecycle endurecido pela Tarefa 5: remount desmonta o host anterior, handlers permanecem únicos e miniaturas são identificadas/deduplicadas por ocorrência.
- Gate principal aprovado no Chrome real após `Ctrl+Shift+R`: foram reconstruídos 7 resultados com Modrić ausente; depois de abrir `Como funciona`, um único Back restaurou os mesmos 7 resultados, manteve Modrić ausente e não duplicou nenhuma foto.
- Gate Forward aprovado no Chrome real: a partir dos 7 resultados restaurados, um único Avançar reabriu `Como funciona` igual ao estado anterior, estável e sem transportar resultados ou fotos da subpágina.
- Gate inicial de teclado/foco aprovado no Chrome real: em `Como funciona`, um único `Tab` exibiu realce visível no campo de busca.
- Segundo gate de teclado/foco aprovado no Chrome real: o `Tab` saiu da busca, avançou para `← Voltar ao início` e manteve realce claramente visível.
- Auditoria de idioma do controle aprovada: fonte e DOM sintético exibem `← Voltar ao início`; não existe `aria-label` nem `title` em inglês, portanto o nome acessível também é português.
- Gate de ativação por teclado aprovado no Chrome real: com foco em `← Voltar ao início`, um único `Enter` retornou ao Início como esperado.
- Gate mobile restrito à página aprovado no Chrome real: com `Como funciona` aberta e a janela estreitada ao máximo possível, a página permaneceu bem renderizada e nada quebrou na área visível.
- Mobile global não aprovado: na mesma largura, o usuário relatou quebra no campo do Elenco. Esse defeito pertence ao owner do Elenco e impede continuar os gates mobile globais da T6 agora.
- Auditoria independente de contraste encontrou dois microtextos da própria página em aproximadamente 3,84:1 no tema escuro. Somente esses dois seletores passaram de `--txt3` para `--txt2`, elevando o pior caso para aproximadamente 5,93:1 sem alterar layout, tamanho ou conteúdo.
- Motores executados: 0.
- Entradas reais processadas: 0.

## Encerramento seguro e fila de retomada

Concluído antes da pausa:

- sintaxe do módulo revalidada;
- teste sintético existente reexecutado com sucesso;
- hashes dos arquivos da página, integração, roteador, motor, dados e módulo do Elenco reconfirmados sem divergência;
- auditoria pública de vazamento, contrato de rota, ausência de mutação, acessibilidade estrutural e responsividade estrutural permaneceram aprovados;
- layout e CSS aprovados permaneceram byte a byte inalterados.

Não iniciado por causa da janela de desligamento:

- nenhum teste adicional ou novo cenário automatizado;
- nenhuma inspeção visual, clique, reload ou redimensionamento;
- nenhuma edição funcional do produto;
- nenhum motor, dado real, banco, build, Elenco, migration, carga ou coleta.

Validações manuais ainda necessárias:

- preservação observável do Elenco após o ciclo de navegação;
- conteúdo mobile abaixo da dobra, rolagem horizontal e legibilidade restante;
- homologação visual do contraste corrigido;

Backup deste checkpoint antes do registro de encerramento:

- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-encerramento.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-gate-visual-aprovado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-retorno-inicio-aprovado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-abertura-reload-aprovados.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-correcao-popstate-subpaginas.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-reload-subpagina-aprovado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-gate-back-posicionado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-pausa-lifecycle-back.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-page-entry-state-integrado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-back-real-aprovado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-forward-real-aprovado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-teclado-foco-aprovado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-segundo-teclado-idioma-auditado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-teclado-enter-aprovado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-mobile-inicial-aprovado.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-correcao-gate-mobile-global.bak`
- `backup/CHECKPOINT-COMO-FUNCIONA-2026-08-24.pre-contraste-microtextos-corrigido.bak`
- `backup/como-funciona.css.pre-contraste-microtextos-2026-08-24.bak`
- `backup/paginas-e-navegacao.js.pre-subpaginas-elenco-aba-global-2026-08-24.bak`
- `backup/paginas-e-navegacao.js.pre-page-entry-state-2026-08-24.bak`
- `backup/modulos-elenco-paginas.js.pre-popstate-como-back-20260824.bak`

## Escopo da integração

Arquivos novos:

- `como-funciona.js`
- `como-funciona.css`

Arquivo compartilhado alterado:

- `ClubEfootball-DATA-BOXES-CORRIGIDA-CARDS-LARGOS.html`
  - um carregamento de CSS;
  - um carregamento de JavaScript antes de `paginas-e-navegacao.js`.

Backup pré-patch:

- `backup/ClubEfootball-DATA-BOXES-CORRIGIDA-CARDS-LARGOS.html.pre-como-funciona-2026-08-24-061625.bak`
- SHA-256 do backup: `D7C52B7BFBF7F20564EBD3E98DF3B77A925A274B932AA14DF24C9E1FD740922C`

Backups antes da revisão de conteúdo:

- `backup/como-funciona.js.pre-revisao-pontuacao-2026-08-24-063601.bak`
- `backup/como-funciona.css.pre-revisao-pontuacao-2026-08-24-063601.bak`
- Antes da correção posterior de contraste, o CSS revisado permanecia idêntico ao backup: SHA-256 `8B70A79D87B6DA9D18F3C10775F0E129EC97CB956EE6CE77F0DB3C3D37E744FE`.

Editados de forma coordenada para a correção de Back/reload:

- `paginas-e-navegacao.js`: porta genérica de estado privado por entrada, pertencente ao `RouteState`.
- `modulos-elenco-paginas.js`: projeção sanitizada e lifecycle idempotente, pertencentes à Tarefa 5.

Não foram editados por esta correção:

- `ficha-ajustes.js`
- `elenco.js`
- `motor-e-ficha-base.js`
- `dados-e-catalogos.js`
- `clubefut.css`

`ficha-ajustes.js`, `elenco.js` e `clubefut.css` receberam alterações concorrentes da Tarefa 1 durante esta janela. Essas alterações foram preservadas e não foram sobrescritas.

## Contrato

- Rota: `como-funciona`.
- Registro: descritor pré-carregado em `T6_ROUTE_DEFINITIONS`, consumido pelo `RouteState` canônico.
- Voltar: `RouteState.leavePage()` com retorno ao Início.
- Página somente de leitura.
- Sem chamadas de motor, Elenco, builds, banco ou persistência do usuário.
- Sem uso direto de `history`, `sessionStorage` ou `localStorage` no novo módulo.
- O módulo de `Melhor função` usa apenas `RouteState.savePageState(payload)`; o roteador aceita objeto JSON puro de até 65.536 caracteres, faz clone defensivo e substitui somente a entrada atual.

## Testes aprovados

Teste: `C:/Users/Luis Fernando/Documents/Codex/2026-08-24/tarefa-6-como-funciona/work/teste-como-funciona.js`

Resultado:

```json
{"ok":true,"rota":"como-funciona","reload":true,"voltar":true,"back":true,"forward":true,"zeroMutacao":true,"motoresExecutados":0,"entradasReais":0,"auditoriaVazamento":true,"acessibilidadeEstrutural":true,"botaoVoltarPtBR":true,"contrasteMicrotextos":true,"responsividadeEstrutural":true}
```

Auditoria pública aprovada contra fórmulas, equações, coeficientes, limiares, constantes, bancos, schemas, pipelines, nomes internos renderizados, fontes externas e URLs.

A estrutura renderizada também foi comparada com a versão visual aprovada: mesma sequência de elementos, classes, cartões, ícones e seções. A revisão mudou somente textos e rótulos de acessibilidade associados ao conteúdo.

Regressão de hierarquia das abas: `C:/Users/Luis Fernando/Documents/Codex/2026-08-24/tarefa-6-como-funciona/work/teste-abas-subpaginas-elenco.js`

```json
{"ok":true,"rotasFilhas":["melhorfuncao","timefraco","melhorformacao","tecnicotime","comparartime"],"reload":true,"back":true,"forward":true,"rankingIsolado":true,"rotasBase":true,"zeroMutacao":true,"motoresExecutados":0,"entradasReais":0}
```

Também passaram novamente os testes existentes de `Como funciona`, RouteState de `melhorfuncao` e lifecycle das páginas do Elenco. Nenhum motor, MT real, banco, Supabase ou `localStorage` real foi executado ou alterado.

Regressão cross-realm do estado por entrada: `C:/Users/Luis Fernando/Documents/Codex/2026-08-24/tarefa-6-como-funciona/work/teste-routestate-estado-por-entrada.js`

```json
{"ok":true,"novoDocumento":true,"reloadComoFunciona":true,"backComPayload":true,"forward":true,"cloneDefensivo":true,"jsonSeguro":true,"limiteCaracteres":65536,"semVazamentoNaUrl":true,"zeroMutacao":true,"motoresExecutados":0,"entradasReais":0}
```

A regressão integrada da Tarefa 5 também passou com a sequência exata: 7 resultados, Modrić ausente, 7 fotos, `Como funciona` → Back, double-pop, remount, Forward e reload em novo realm; Elenco marcado, Ranking desmarcado, handlers únicos e zero mutação.

## Hashes finais da Tarefa 6

- `como-funciona.js`: `EE2429124B3A6991B86497D32F4DD9B01473919984A0E6B02A0E0E95F6248D60`
- `como-funciona.css`: `7B32C1F6A698661F8C5E1FE09976D40744B6F5B8CCA4F3065AA0BA92035D2C6E`
- HTML integrado: `0CD947DCF9E73992BE1F5212D8DB3241F0CF6B61C51FAC490DF2916DD4BE6989`
- Roteador após payload privado por entrada: `0D282B01B001087674267859A3F82F9F5F8E236CF295B4F64738CA4928A27703`
- Backup imediatamente anterior ao payload por entrada: `B1D533B29F10D3AC2D02885EE5B73B9C79CCA4B3EA087FC13081F53266ECBF47`
- Motor não editado por esta correção; hash concorrente observado: `4B160CA9508121E8A866FBB6CD6F46C4E99B63269F1F40483BE41486FA23A3BF`
- Dados preservados: `DCF1B4D58E99A046A205E337A4E5FACE7D8D9E4F5AF9A8393570BC1CCD4B10A0`
- Módulo das páginas do Elenco após integração coordenada: `7A040898605D8833D8753B406DB58A7EC39C21D4323755B83ACC6CABD332C758`
- Backup pré-lifecycle do módulo: `F37D74CA0297FBDB74C40A89ABB857D11EB878EDE23F0C33AA09F50EE9E726BC`

## Gates manuais registrados

- Aparência inicial aprovada: a aba `Como funciona` ficou marcada, o título `Uma leitura de encaixe, não uma cópia da nota oficial.` apareceu corretamente e nenhum texto ficou cortado.
- Retorno aprovado: partindo do Elenco, o botão `← Voltar ao início` retornou ao Início e retirou a página/aba `Como funciona` do estado ativo.
- Abertura e reload direto aprovados: `Como funciona` abriu normalmente e permaneceu correta após o recarregamento. O ponto de origem anterior não foi confirmado e não integra este gate.
- Back anterior reprovado e corrigido localmente: o conteúdo de `Melhor função de cada um` voltou, mas Ranking ficou marcado.
- Reload/abertura pós-correção aprovado no Chrome real: `Melhor função de cada um` manteve Elenco marcado e Ranking desmarcado.
- A sequência pós-correção foi posicionada pelo usuário com 7 resultados e Modrić ausente antes de abrir `Como funciona`.
- Resultado do gate anterior: Back chegou à subpágina correta, mas perdeu os 7 resultados e duplicou fotos.
- A causa foi corrigida e coberta sinteticamente, inclusive após reload em novo documento.
- Gate principal pós-correção aprovado no Chrome real: um Back restaurou exatamente os 7 resultados, com Modrić ausente e uma foto por ocorrência. A Tarefa 6 permanece aberta.
- Gate Forward aprovado no Chrome real: um Avançar reabriu `Como funciona` no mesmo estado visual, sem vazamento de resultados ou fotos.
- Gate inicial de teclado/foco aprovado no Chrome real: um `Tab` destacou visivelmente o campo de busca.
- Segundo gate de teclado/foco aprovado no Chrome real: outro `Tab` avançou para `← Voltar ao início` com realce visível.
- O possível problema de idioma não se confirmou: texto visível e nome acessível do botão estão em português; nenhum rótulo alternativo em inglês foi encontrado no fonte ou DOM sintético. Nenhum arquivo do produto precisou ser alterado.
- Gate de ativação por teclado aprovado no Chrome real: `Enter` no botão focado retornou corretamente ao Início.
- Gate mobile restrito aprovado no Chrome real: `Como funciona` permaneceu íntegra na menor largura prática da janela.
- Correção de status: o mobile global não passou, porque o campo do Elenco quebrou na mesma largura. A T6 não assume esse arquivo/defeito e aguarda a correção pelo owner do Elenco.
- O gate de preservação observável do Elenco foi adiado enquanto a Tarefa 1 corrige Neuer/GK; não há reprovação da T6 nesse item.
- O pedido de rolar até o final foi cancelado antes da homologação; o gate mobile global não deve ser repetido até o handoff da T1.
- Contraste corrigido de forma isolada nos dois microtextos da página: pior razão estimada no tema escuro passou de 3,84:1 para 5,93:1. As três regressões T6 passaram, com zero motores e zero dados reais.
- Próxima ação manual única e independente: em `Como funciona`, executar somente `Ctrl+Shift+R` para carregar o CSS corrigido e parar. A inspeção de legibilidade será solicitada separadamente; não navegar para o Elenco.

## Checkpoint seguro atual

- Produto congelado depois da integração e dos testes sintéticos.
- `modulos-elenco-paginas.js`: `7A040898605D8833D8753B406DB58A7EC39C21D4323755B83ACC6CABD332C758`.
- `paginas-e-navegacao.js`: `0D282B01B001087674267859A3F82F9F5F8E236CF295B4F64738CA4928A27703`.
- `como-funciona.js`: `EE2429124B3A6991B86497D32F4DD9B01473919984A0E6B02A0E0E95F6248D60`.
- A Tarefa 5 confirmou a integração e devolveu os mesmos hashes.
- Nenhum processo, servidor, motor, banco, Supabase, MT ou `localStorage` real ficou em operação por esta tarefa.

Esses gates são parciais. A Tarefa 6 continua aberta até a homologação dos itens restantes listados acima.
