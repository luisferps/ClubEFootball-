# Checkpoint de retomada — Tarefa 5

Data: 24/08/2026

## Estado seguro alcançado

- `melhorfuncao` está carregado e registrado como página própria pelo RouteState.
- O botão do Elenco não usa mais a projeção inline; chama somente `RouteState.navigate('melhorfuncao')`.
- Somente `melhorfuncao` está exposto. Os outros cinco módulos permanecem internos e sem rota pública.
- Gate real aprovado: Elenco → `Ctrl+Shift+R` → Elenco.
- Gate real aprovado: clicar em “Melhor função de cada um” abriu uma página própria, não conteúdo inline.
- Testes sintéticos passaram para reload, Voltar, back, forward, aviso comercial genérico e zero mutação.
- Testes usados: 6 entradas sintéticas, 0 entradas reais, nenhum motor real.

## Arquivos e hashes do patch da Tarefa 5

- `motor-e-ficha-base.js`: `5306EA24107F2E2DFC06B8A24A9AE5A3F7AFA139534327240F4CA6B192E148C8`
- `modulos-elenco-paginas.js`: `42AD5C416576E65AB6FC1738AC776CFFD168BD562D0F069A2720CBF5709CCA4A`
- `ClubEfootball-DATA-BOXES-CORRIGIDA-CARDS-LARGOS.html`: `D7C52B7BFBF7F20564EBD3E98DF3B77A925A274B932AA14DF24C9E1FD740922C`
- `paginas-e-navegacao.js` permaneceu no hash homologado `E229B8E4BA3BE02F02FB9F8B92D674B47958ABEC86E39ED1115F2F44FBB92573`.
- Backups pré-integração têm o sufixo `pre-integracao-melhorfuncao-2026-08-24-061027.bak`.

## Política comercial atual e proposta

Comportamento ativo preservado durante a pausa: quando existe uma build bloqueada superior, aparece somente “Existe uma opção melhor disponível”.

A política comercial mais recente autoriza revelar:

- nome da função da melhor opção bloqueada;
- pontuação dessa opção.

Continuam proibidos:

- nome ou identificador da build otimizada;
- distribuição de pontos/barras;
- habilidades, impulsos, bônus e ingredientes usados;
- fotografia, payload ou linha bruta que permita reconstruir a receita.

Proposta segura para revisão futura: `Existe uma opção melhor disponível: {função} · {pontuação}`. Não mostrar ganho/delta, origem ou qualquer receita até decisão posterior. O produto ativo ainda não foi alterado para essa proposta.

## Fila manual para quando o usuário voltar

Executar uma ação por vez:

1. Na página já aberta de Melhor função, clicar apenas em **Titulares** e parar.
   - Esperado: botão selecionado, lista somente de titulares preenchidos, todos marcados, contador exato e botão de calcular habilitado.
   - Não calcular, não desmarcar e não voltar nesse gate.
2. Depois de homologar o gate 1, definir o próximo gate mínimo de desmarcação individual.
3. O cálculo e qualquer revisão comercial ficam para gates posteriores, nunca misturados com seleção, navegação ou persistência.

## Não iniciado por causa do desligamento

- Nenhuma alteração para revelar função/pontuação bloqueada.
- Nenhum novo módulo exposto.
- Nenhum clique, reload, cálculo ou validação visual adicional.
- Nenhuma migration, carga, coleta, motor, Supabase ou processo remoto.

Retomada idempotente: começar lendo este checkpoint, confirmar os hashes da Tarefa 5 e retomar pelo gate manual **Titulares**.

## Invariante visual global confirmado em 24/08/2026

- Sempre que uma ocorrência/card for apresentada em qualquer área do site, exibir ao lado a miniatura do `card_id` exato daquela ocorrência. O nome do jogador sozinho não identifica o card, pois o mesmo jogador pode possuir várias versões.
- A imagem deve derivar do `card_id` canônico, normalizando apenas sufixos internos da ocorrência; deve usar carregamento lazy e falhar fechado ocultando a imagem quebrada.
- Na Tarefa 5, a regra já vale para a seleção e para os resultados calculados de `Melhor função de cada um`. Outras páginas do site não foram alteradas nesta rodada e deverão adotar o invariante quando forem trabalhadas.

## Correção de lifecycle Resultados → Como funciona → Back — 24/08/2026

Incidente real preservado: depois de calcular sete ocorrências, com Modrić desmarcado, abrir `Como funciona` e usar o Back do navegador, `Melhor função de cada um` voltou à seleção e exibiu fotos duplicadas.

Diagnóstico e proteção aplicada:

- o remount canônico simples já preservava a memória na fixture, mas a fase funcional não pertencia à entrada do histórico e não havia restauração segura em novo documento;
- o RouteState agora oferece `savePageState(payload)` e devolve clone defensivo em `opcoes.pageState`, sem URL, `localStorage` ou `sessionStorage`;
- o módulo salva somente versão/fase/grupo, IDs selecionados, `card_id` de conferência e os valores acessíveis já exibidos no resultado;
- não são serializados MT, card completo, build, receita, distribuição, função/pontuação bloqueada ou dado privado/comercial;
- a mesma assinatura da entrada reutiliza a mesma instância em memória; entrada nova não herda estado;
- o host anterior é desmontado antes da substituição, os handlers continuam atribuídos uma única vez e cada miniatura recebe chave pelo ID da ocorrência;
- a renderização elimina defensivamente uma segunda miniatura da mesma ocorrência e os resultados também falham fechado contra repetição de IDs.

Arquivos ativos e backups:

- `modulos-elenco-paginas.js`: `7A040898605D8833D8753B406DB58A7EC39C21D4323755B83ACC6CABD332C758`;
- backup pré-lifecycle: `backup/modulos-elenco-paginas.js.pre-popstate-como-back-20260824.bak`, hash `F37D74CA0297FBDB74C40A89ABB857D11EB878EDE23F0C33AA09F50EE9E726BC`;
- `paginas-e-navegacao.js`: `0D282B01B001087674267859A3F82F9F5F8E236CF295B4F64738CA4928A27703`;
- backup pré-pageState: `backup/paginas-e-navegacao.js.pre-page-entry-state-2026-08-24.bak`, hash inicial `B1D533B29F10D3AC2D02885EE5B73B9C79CCA4B3EA087FC13081F53266ECBF47`.

Validações sintéticas aprovadas:

- sete resultados restaurados, Modrić ausente e sete fotos exatas;
- Back, Forward, double-pop e remount repetido;
- reload em novo realm com payload da entrada anterior;
- uma miniatura por ocorrência e remoção defensiva de duplicatas;
- Elenco marcado, Ranking desmarcado e Como funciona isolada;
- payload JSON seguro, com limite de 65.536 caracteres, clone defensivo e sem vazamento na URL;
- sintaxe dos arquivos ativos e todas as regressões anteriores da Tarefa 5/Tarefa 6;
- zero motor, zero entrada real e zero mutação de MT.

Próximo gate manual único: reconstruir os sete resultados com Modrić desmarcado, abrir `Como funciona`, clicar uma vez no Back do navegador e parar. Esperado: reaparecem os mesmos sete resultados, Modrić continua ausente e cada ocorrência apresenta exatamente uma foto. Forward e reload visual ficam para gates posteriores.

### Gate manual principal aprovado no Chrome real

Após `Ctrl+Shift+R`, o usuário reconstruiu sete resultados com Modrić ausente, abriu `Como funciona` e usou uma única vez o Back do navegador. O retorno restaurou os mesmos sete resultados, manteve Modrić ausente e não apresentou fotos duplicadas.

A Tarefa 5 permanece aberta. Nenhuma nova ação manual da T5 deve ser solicitada enquanto o gate Forward pertencente à Tarefa 6 estiver em andamento.

### Gate Forward aprovado no Chrome real

A partir dos sete resultados restaurados, o usuário usou uma única vez o Avançar do navegador. `Como funciona` reapareceu igual ao estado anterior, estável e sem vazamento dos resultados ou das fotos de `Melhor função de cada um`.

A Tarefa 5 permanece aberta. A Tarefa 6 continua proprietária do próximo gate manual; a Tarefa 5 não deve solicitar ação concorrente.

### Auditoria independente dos campos do resultado

Sem depender do gate visual ou da correção mobile da Tarefa 1, uma fixture puramente sintética validou o contrato do primeiro resultado:

- função atual, melhor função acessível, pontuação atual, pontuação possível, ganho e estado aparecem coerentes;
- o aviso comercial continua genérico quando uma opção global bloqueada é superior;
- função, pontuação e receita da opção bloqueada não aparecem no HTML nem no `pageState`;
- o `pageState` contém somente a opção acessível já visível e permanece sanitizado;
- zero entrada real, zero motor e zero mutação de MT.

O gate visual pendente continua sendo somente ler o valor de `Melhor acessível` no primeiro resultado. Se a página não estiver na fase de resultados, o usuário deve apenas relatar isso, sem selecionar grupo nem calcular automaticamente. A T5 pode continuar auditorias técnicas independentes em paralelo, sem aguardar a frente mobile da Tarefa 1.

## Pacote das quatro funcionalidades pendentes — 24/08/2026

O gate antigo de `Melhor acessível` foi retirado da fila operacional. A auditoria histórica não encontrou homologação manual desse valor, mas a diretriz posterior determinou não repetir cálculo nem reconstrução e priorizar as quatro funcionalidades pendentes.

### Matriz recuperada e estado final técnico

| Rota | Especificação recuperada | Artefato prévio | Estado antes | Entrega atual | Mutação |
|---|---|---|---|---|---|
| `timefraco` | Duas visões independentes: Titulares e Profundidade; vaga vazia crítica; comparação somente com alternativas acessíveis do próprio elenco; aviso comercial genérico | Análises internas incompletas | Parcial/interna | Página própria, análise explícita, Reservas+Fora como alternativas, fotos exatas, estado por entrada | Nunca |
| `melhorformacao` | Testar formações com jogadores únicos e builds acessíveis; mostrar ganho/lacunas; prévia e confirmação | Otimizador e aplicação internos | Parcial/interna | Página própria, seis melhores propostas, ganho/fotos, prévia, preflight, aplicação transacional e rollback | Somente confirmação |
| `tecnicotime` | Comparar técnico atual e reservas locais sobre grupo selecionado; preservar builds; ganho agregado e individual; prévia/confirmar | Comparação interna | Parcial/interna | Página própria, seleção de técnico, fotos por ocorrência, detalhes individuais, estado por entrada, confirmação transacional | Somente confirmação |
| `comparartime` | Sem auth: código/arquivo local; schema validado; métricas agregadas e vagas; nenhum time privado/build | CF1/JSON interno | Parcial/interna | Página própria, schema V2 com `card_id`, validação estrita, correspondência por posição, fotos exatas, importação/exportação e lifecycle | Nunca |

Owners alterados:

- `modulos-elenco-paginas.js`: único owner das quatro páginas, estado, UI e ações.
- `motor-e-ficha-base.js`: somente as quatro portas dos botões foram redirecionadas para `RouteState.navigate(...)`; os fluxos legados permaneceram abaixo como referência histórica e nenhuma equação foi alterada.
- `paginas-e-navegacao.js`, HTML, `elenco.js`, Ficha, Ranking e CSS global não foram editados pela Tarefa 5 neste pacote.

Dependências preservadas:

- `MT` e autoridades atuais de ocorrência/card/build/técnico/formação;
- `ElencoCardInvariant` para unicidade antes da aplicação de formação;
- `RouteState.savePageState` com payloads sanitizados e entrada nova sem herança;
- builds acessíveis locais; nenhuma fonte `public.cards_completos`, Supabase, auth local ou flag `MODO_ADM/MT_PRO` autoriza conteúdo.

### Segurança e lifecycle

- As cinco subpáginas públicas do Elenco são agora `melhorfuncao`, `timefraco`, `melhorformacao`, `tecnicotime` e `comparartime`; todas retornam a `meutime` e permanecem filhas visuais da aba Elenco.
- Back, Forward, reload/remount e entrada nova foram cobertos; resultados sanitizados não carregam card completo, receita de build ou pontuação bloqueada.
- `timefraco` e `comparartime` são somente leitura.
- `melhorformacao` e `tecnicotime` exigem prévia e confirmação; cancelar não altera o time; confirmação faz uma persistência e restaura o snapshot em falha.
- A formação valida novamente ocorrência, unicidade, compatibilidade, build acessível e formação existente antes de mutar.
- O schema compartilhável passou a `clubefutebol-team-share` versão `2`; códigos V1 internos antigos são rejeitados para impedir associação ambígua sem `card_id`.
- Execução externa pelo usuário: o Codex somente preparou/validou fixtures sintéticas. Foram usadas 6 linhas sintéticas no teste integrado, 0 linhas reais e nenhum motor real.

### Arquivos ativos e hashes finais

- `modulos-elenco-paginas.js`: `DEE7C9EC1E0735909992414B20BBD2BA4E96C0729BAAA5AD80CE5CEC7E372451`.
- `motor-e-ficha-base.js`: `7E37CF7F1FD6C0E15D0183D944DFBBF4B1C4FF4BFD9A7B0D345983847C1591C9`.
- `paginas-e-navegacao.js` preservado: `0D282B01B001087674267859A3F82F9F5F8E236CF295B4F64738CA4928A27703`.
- HTML ativo preservado: `7988A4CA0EA8A09021BDD10EF526F0D728C3B935A47F64A086F00DECFE80BE1B`.

Backups específicos, todos validados por igualdade de hash no momento da criação:

- `backup/modulos-elenco-paginas.js.pre-timefraco-produto-20260824.bak` e `backup/motor-e-ficha-base.js.pre-timefraco-rota-20260824.bak`;
- `backup/modulos-elenco-paginas.js.pre-melhorformacao-produto-20260824.bak` e `backup/motor-e-ficha-base.js.pre-melhorformacao-rota-20260824.bak`;
- `backup/modulos-elenco-paginas.js.pre-tecnicotime-produto-20260824.bak` e `backup/motor-e-ficha-base.js.pre-tecnicotime-rota-20260824.bak`;
- `backup/modulos-elenco-paginas.js.pre-comparartime-produto-20260824.bak` e `backup/motor-e-ficha-base.js.pre-comparartime-rota-20260824.bak`;
- `backup/modulos-elenco-paginas.js.pre-lifecycle-quatro-modulos-20260824.bak`.

### Validações técnicas aprovadas

- Sintaxe dos três arquivos JS envolvidos no contrato: OK.
- Toda a suíte T5: OK.
- Toda a suíte T6/RouteState/Como funciona: OK.
- Rotas reais registradas: cinco; `timeideal` continua interno e não exposto.
- Botões sem cadeado local e com navegação canônica antes de qualquer legado: OK.
- Titulares/Profundidade, fotos, aviso genérico e zero mutação: OK.
- Formação: jogadores únicos, ganho, preflight, cancelamento, uma persistência, save recusado e rollback por invariante: OK.
- Técnico: seleção, ganho agregado/individual, fotos, cancelamento, uma persistência e disponibilidade local: OK.
- Comparar: `card_id`, score estrito, posição em vez de índice bruto, schema/arquivo inválidos, payload sanitizado e zero mutação: OK.
- Melhor função, Ranking, Como funciona, Back/Forward e guardas contra render concorrente: regressões aprovadas.

### Pontos para validação visual final, sem gates intermediários

1. Confirmar que os quatro botões abrem páginas próprias e mantêm a aba Elenco marcada.
2. Conferir as duas visões e fotos de `Onde meu time está fraco`.
3. Conferir proposta, ganho, lacunas, prévia e cancelamento de `Melhor formação`; não confirmar aplicação no primeiro passeio.
4. Conferir seleção, impacto por jogador, prévia e cancelamento de `Técnico`; não confirmar aplicação no primeiro passeio.
5. Gerar um código V2, importar em `Comparar` e conferir fotos/posições; nenhum Elenco deve mudar.

Pacote tecnicamente pronto para validação visual final. A Tarefa 5 não deve reabrir gates antigos durante essa validação.

## Reprovação e correção real — Onde meu time está fraco

O gate de abertura anterior foi reprovado e substituído por este incidente: no navegador real, `TITULARES` e `PROFUNDIDADE DO ELENCO` estavam em um bloco, enquanto `ANALISAR O TIME` ficava em outro bloco abaixo. O clique iniciava simultaneamente as duas análises em trabalho síncrono, recomputando candidatos e varrendo o catálogo por ocorrência × vaga × visão; a interface permanecia sem resposta e parecia inoperante.

Durante a reprodução, o Codex acionou indevidamente a análise real de 53 ocorrências, acima do limite de 20. A aba foi encerrada, a execução foi parada e nenhum novo teste real foi feito. As validações posteriores usaram somente fixtures sintéticas e mocks; produção continua externa pelo usuário.

Correção isolada em `C:\Users\Luis Fernando\Downloads\tela-estavel\modulos-elenco-paginas.js`:

- os três controles agora pertencem à mesma faixa visual `.emp-timefraco-controls`;
- o clique responde imediatamente com `ANALISANDO…`, bloqueia clique duplicado e agenda o trabalho no ciclo seguinte;
- um remount/Back/Forward invalida com segurança qualquer callback pertencente à montagem anterior;
- o catálogo ganhou índice derivado em memória, invalidado ao chegar `encaixe:dados-completos`;
- candidatos acessíveis e globais são preparados uma vez por ocorrência e reutilizados nas 11 vagas e nas duas visões;
- Titulares e Profundidade continuam sendo calculados juntos, somente leitura, com o mesmo contrato comercial e sem alterar equações.

Backup validado antes da edição:

- `C:\Users\Luis Fernando\Downloads\tela-estavel\backup\modulos-elenco-paginas.js.pre-timefraco-layout-performance-20260824-151703.bak`
- SHA-256 do backup: `DEE7C9EC1E0735909992414B20BBD2BA4E96C0729BAAA5AD80CE5CEC7E372451`
- SHA-256 ativo após a correção: `06009A8C9066AE9A900FBF37C4B27EDEF4FA4D8BE7BEA5FD7BB90F147C4190BA`

Validações concluídas:

- render real da página ativa: os três controles ficaram na mesma linha (`y=202`), em um contêiner único de 38 px de altura;
- navegador real com fixture sintética de 6 linhas e 0 reais: clique produziu 2 resultados, 4 miniaturas, 2 avaliações mockadas, uma gravação privada de pageState e zero mutação de `MT`;
- troca para `PROFUNDIDADE DO ELENCO`: 2 resultados, fotos e textos corretos;
- fixture sintética grande: 60 ocorrências/120 linhas, 11 vagas, 98 avaliações acessíveis, 2 leituras globais, 200 ms e zero mutação de `MT`;
- clique duplicado, handler único, um render por ação, callback antigo após remount, pageState/Back/reload e rota canônica: aprovados;
- sintaxe, toda a suíte T5, RouteState/T6, Como funciona e boot frio: aprovados;
- `motor-e-ficha-base.js`, `paginas-e-navegacao.js` e o HTML ativo permaneceram nos hashes homologados.

Próximo gate manual único, quando a origem liberar: recarregar, abrir `Onde meu time está fraco` e clicar uma vez em `ANALISAR O TIME`; o botão deve mostrar `ANALISANDO…` imediatamente e depois exibir a análise, sem quebrar os controles em duas linhas.

## Correção Bergomi/Marcelo e contrato transversal por build

### Causa comprovada do incidente

O cálculo já ordenava os substitutos acessíveis pela nota avaliada na vaga, mas o renderer chamava o primeiro colocado de `Melhor troca interna` mesmo quando ele ficava abaixo do titular. O ganho era corretamente limitado a zero e o estado dizia `sem troca melhor no seu elenco`; portanto a contradição Bergomi maior / Marcelo apresentado como melhor era de rótulo e contexto oculto, não de ordenação.

O layout anterior agravava o problema: posição, função, build, técnico e as duas notas estavam distribuídos em uma linha longa e parte do contexto nem era exibida. Assim, o usuário via Marcelo e uma nota, mas não conseguia saber que ele era apenas a melhor alternativa disponível — não uma troca que melhorava.

### Correção local

- cada vaga agora usa um box compacto com `Vaga e função avaliadas`;
- titular e alternativa ficam em dois sub-boxes responsivos, cada um com foto exata, build usada, função calculada e nota comparável;
- o técnico considerado aparece explicitamente no cabeçalho do box;
- `TROCA QUE MELHORA` só aparece quando a nota alternativa supera a nota do titular por mais que o epsilon do produto;
- quando a alternativa é inferior, o rótulo é `MELHOR ALTERNATIVA DISPONÍVEL` e o veredito mostra `Não melhora` com a diferença negativa;
- vaga vazia, ausência de opção e profundidade mantêm estados próprios;
- o cálculo, as equações, as fontes e a lista de alternativas não foram alterados.

Fixture causal aprovada: Bergomi 95,0 contra Marcelo 91,0 resultou em `sem troca melhor`, `Não melhora · -4.0` e nunca em `troca que melhora`; invertendo apenas a nota comparável para Bergomi 85,0, Marcelo passou corretamente a `troca que melhora`, ganho +6,0. Foram 3 linhas sintéticas, 0 reais e zero mutação de `MT`.

### Inventário dos dois modos de build

| Página | Modo A — builds do usuário | Modo B — melhor absoluta do sistema | Aplicação/mutação |
|---|---|---|---|
| `melhorfuncao` | Básica compatível, aplicada e salvas acessíveis | comparação privada; somente aviso genérico se superior | somente leitura |
| `timefraco` | build do titular contra melhor build acessível de Reservas/Fora na vaga; técnico e notas visíveis | verificação privada por vaga; nota, função, nome e receita bloqueados | somente leitura |
| `melhorformacao` | resolve formação com cards únicos e builds acessíveis; cada vaga identifica a build usada | verificação privada da proposta; apenas aviso genérico | prévia e confirmação transacional; bloqueada nunca aplicável |
| `tecnicotime` | mantém a build aplicada de cada ocorrência e compara o efeito dos técnicos locais; notas antes/depois visíveis | verificação privada do grupo; apenas aviso genérico | só o técnico pode mudar após prévia/confirmação |
| `comparartime` | compara o resultado da build aplicada por ocorrência; o schema declara `basis: applied-build` | só o elenco local recebe verificação privada e aviso genérico | somente leitura |

No time importado não se infere entitlement, build privada ou melhor absoluta. O código compartilhável não contém `buildId`, nome da build, função privada nem distribuição; continua contendo apenas `card_id`, jogador, posição e score agregado da build aplicada.

### Arquivos, backup e hashes

- owner alterado: `C:\Users\Luis Fernando\Downloads\tela-estavel\modulos-elenco-paginas.js`;
- backup validado: `C:\Users\Luis Fernando\Downloads\tela-estavel\backup\modulos-elenco-paginas.js.pre-timefraco-comparacao-build-layout-20260824-153925.bak`;
- SHA-256 do backup: `06009A8C9066AE9A900FBF37C4B27EDEF4FA4D8BE7BEA5FD7BB90F147C4190BA`;
- SHA-256 ativo: `DDEE4AEE3A4AA00FB2E0EAAE61104A46455BA49B96EA334058B7004F07D09DDB`;
- roteador preservado: `0D282B01B001087674267859A3F82F9F5F8E236CF295B4F64738CA4928A27703`;
- motor preservado: `7E37CF7F1FD6C0E15D0183D944DFBBF4B1C4FF4BFD9A7B0D345983847C1591C9`.

### Regressões finais

- sintaxe do módulo: aprovada;
- 12 fixtures T5: aprovadas;
- fixture causal Bergomi/Marcelo: aprovada;
- performance: 60 ocorrências/120 linhas sintéticas, 11 vagas, 8 ms nesta execução, 0 reais e zero mutação;
- render no navegador local com fixture de 6 linhas sintéticas/0 reais: 2 boxes, 4 fotos, rótulos de melhora e não melhora corretos, `mutação false`;
- desktop 1280×720: duas colunas de comparação, sem overflow de página ou box;
- móvel 390×844: comparação e fatos empilhados em uma coluna, sem overflow de página ou box; viewport restaurado e aba/servidores locais encerrados;
- RouteState/T6/Como funciona: três suítes aprovadas;
- pageState restaurou build, função, técnico, notas e rótulo sem objetos completos de card/build e sem nota bloqueada;
- Modo A e Modo B aparecem separados em Melhor função, Onde está fraco, Formação, Técnico e Comparar;
- nenhuma equação, Ranking, Ficha, Elenco, banco, Supabase ou localStorage foi alterado.

Não há decisão funcional material pendente para este contrato. O pacote está pronto para uma validação visual final coordenada, sem repetir gates antigos.

## Reprovação visual real e segunda composição — `timefraco`

O navegador real reprovou a primeira composição dos resultados como visualmente muito ruim. Essa reprovação permanece registrada; a funcionalidade não foi considerada homologada.

A reprodução visual sintética mostrou a causa de composição: caixas dentro de caixas, três microcampos por jogador, dois avisos de modo antes do conteúdo, um chip de modo repetido por vaga e um painel comercial grande no rodapé de cada comparação. Os critérios estavam corretos, mas a hierarquia era pequena, pesada e repetitiva.

Segunda composição aplicada apenas no owner da T5:

- um único box principal por vaga;
- cabeçalho curto com vaga/função, técnico e, quando aplicável, aviso comercial compacto;
- titular e alternativa lado a lado no desktop, separados por uma seta;
- cada lado mostra uma foto exata, nome, build, função e nota grande alinhada;
- um único rodapé reúne estado e ganho/queda;
- os modos A/B aparecem uma vez no topo, como tags compactas;
- no móvel, os dois lados empilham; critérios continuam visíveis;
- foram removidos do resultado de `timefraco` os microboxes `.emp-weak-facts`, o aviso longo `.emp-mode-bbar` e a repetição do painel comercial por vaga.

Backup validado antes da segunda composição:

- `C:\Users\Luis Fernando\Downloads\tela-estavel\backup\modulos-elenco-paginas.js.pre-timefraco-revisao-visual-20260824-160535.bak`
- SHA-256: `DDEE4AEE3A4AA00FB2E0EAAE61104A46455BA49B96EA334058B7004F07D09DDB`
- SHA-256 ativo após a revisão: `9C29B453DEFAE018FD48560B5323913C69EE6C8C5E22CAA114AD416FF517CACC`

Validação sem estado real:

- screenshot renderizado com fixture de 6 linhas sintéticas/0 reais foi inspecionado em desktop e móvel;
- desktop 1280×720: duas colunas de 533 px, separador de 34 px, 2 boxes, sem overflow;
- móvel 390×844: 2 boxes, 4 jogadores/fotos, 0 microboxes, sem overflow e sem duplicação de DOM;
- toda a suíte de 12 fixtures T5 e as 3 suítes T6/RouteState passaram;
- fixture causal Bergomi/Marcelo, pageState, fotos, lifecycle, proteção comercial e zero mutação passaram;
- performance: 60 ocorrências/120 linhas sintéticas, 11 vagas, 24 ms nesta execução;
- roteador e motor permaneceram nos hashes homologados; nenhum Chrome reivindicado pela T1 foi tocado.

Estado: patch tecnicamente consistente, mas **não homologado visualmente**. A próxima validação deve avaliar somente esta segunda composição no navegador real, quando a origem coordenar o claim da T1.
