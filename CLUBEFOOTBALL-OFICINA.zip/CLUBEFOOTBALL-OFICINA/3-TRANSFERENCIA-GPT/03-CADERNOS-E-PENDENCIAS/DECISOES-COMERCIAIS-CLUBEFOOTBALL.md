# Decisões comerciais — ClubEfootball

Registro das decisões tomadas até 24 de agosto de 2026. Este documento define o produto e a experiência aprovada; o estado de implementação e homologação é acompanhado separadamente.

## Produtos e função do gratuito

- Ranking completo: gratuito, como gerador de tráfego.
- Análise geral das Boxes: gratuita, respondendo se vale a pena investir na Box.
- Builds otimizadas: principal produto pago inicial.
- Otimização do Elenco: produto futuro, a ser definido somente depois que seus módulos existirem e estiverem estabilizados.
- A build Básica não tem valor comercial e não deve ser apresentada como benefício relevante ao usuário.

## Venda das builds

- A linguagem de venda é **card + posição**. As funções são a inteligência interna do sistema.
- Ao comprar uma posição, o usuário recebe obrigatoriamente todas as builds das funções/perfis ligados àquela posição.
- Funções da mesma posição não serão vendidas separadamente, pois o usuário poderia aplicar um perfil inadequado sem compreender a diferença tática.
- A unidade de preço é uma build otimizada: **1 crédito por função/build**.
- Preço da posição = quantidade de funções ligadas à posição × 1 crédito.
- Valor-base provisório: **1 crédito = R$ 1**.

## Posição gratuita do card

- Cada card terá uma posição completa gratuita, igual para todos os usuários.
- Todas as funções ligadas à posição gratuita ficam visíveis.
- O usuário não escolhe qual posição será gratuita, evitando que pessoas diferentes liberem posições diferentes e compartilhem o conjunto completo.
- Regra provisória: para cada posição, considerar a maior pontuação total entre suas funções; ordenar as posições e liberar a mediana. Se o total for par, usar a mediana inferior.
- A regra da mediana exige estudo de impacto antes da implementação definitiva.

## O que aparece antes da compra

- Mostrar a posição bloqueada, as funções incluídas, a pontuação total otimizada de cada função, o preço total em créditos e a ação de desbloqueio.
- A pontuação total é mostrada para provar o valor e evitar compra às cegas.
- A pontuação total deve informar de forma curta que pode variar no Elenco conforme o técnico.
- Permanecem bloqueados os verdadeiros insumos do produto: distribuição dos pontos, ímpetos e demais detalhes da construção.

## Créditos e pagamento

- Pagamento por saldo pré-pago via Stripe; não é assinatura.
- O saldo de créditos não vence.
- Pacotes provisórios, com custo unitário decrescente por bônus:
  - R$ 5 = 5 créditos;
  - R$ 10 = 11 créditos;
  - R$ 20 = 24 créditos;
  - R$ 50 = 65 créditos.
- Os pacotes ainda precisam de validação financeira antes do lançamento.

## Validade do desbloqueio

- Uma posição desbloqueada fica acessível por **um ano**, contado a partir do desbloqueio da posição — não da compra dos créditos.
- Não há renovação automática.
- Ao vencer, nunca remover, substituir ou reotimizar silenciosamente uma build já salva ou aplicada no Elenco.
- A fotografia já aplicada permanece intacta.
- Vencem o acesso aos detalhes, novas cópias, comparações e reaplicações daquela posição.
- A Ficha passa a indicar acesso expirado e oferece renovação por mais um ano.

## Fluxo de compra

- Ao clicar numa posição bloqueada, abrir uma janela curta com funções, pontuações totais, preço em créditos, validade de um ano e ação “Desbloquear posição”.
- Com saldo suficiente, liberar imediatamente.
- Sem saldo suficiente, oferecer os pacotes da Stripe e, após o pagamento, retornar exatamente ao mesmo card e posição.
- A compra de builds é concluída na Ficha.

## Autenticação

- Ranking, Boxes e conteúdo gratuito devem permanecer acessíveis sem login.
- Exigir autenticação quando houver algo a persistir: salvar build, montar Elenco, comprar créditos ou desbloquear posição.

## Chamadas para compra

- Página inicial: nenhuma chamada de compra.
- Ficha: ação direta nas posições bloqueadas.
- Ranking e análise de Box: chamada contextual “Ver builds”, levando à Ficha.
- Elenco, card no campo: usar a coluna direita para dois avisos distintos:
  - “Você tem uma build melhor”: solução que o usuário já possui;
  - “Build otimizada disponível”: solução máxima do motor ainda não possuída, com ação “Ver na Ficha”.
- Se a build aplicada já alcança o máximo do motor, não mostrar oferta.
- Se o usuário possui uma build ótima, mas não a aplicou, mostrar somente o aviso da build que ele já tem.
- Se o usuário descobriu por conta própria outra construção que alcança o mesmo máximo, não mostrar oferta.
- Evitar banners globais ou chamadas repetidas em todos os cards.

## Módulos futuros do Elenco

- Não definir agora pacote, preço ou validade de módulos ainda não implementados, como time ideal, melhor função, pontos fracos, melhor formação e técnico ideal.
- Ordem aprovada:
  1. concluir as pendências atuais do site;
  2. implementar os módulos do Elenco;
  3. estabilizar e testar o conjunto completo;
  4. voltar à definição comercial desses módulos com o produto concreto.

## Princípio de UX

- Informações explicativas devem ser mínimas, diretas e contextuais.
- Não poluir telas que já carregam muitos dados do jogo.
- Nunca alterar silenciosamente os insumos escolhidos pelo usuário.

## Abertura da Ficha

- A origem do clique não muda a regra: Ranking, Elenco, busca e Boxes usam o mesmo resolvedor.
- Se o card está no Elenco, abrir a build atualmente aplicada nele.
- Se não está no Elenco, mas possui builds salvas, abrir a última build salva válida.
- Sem build aplicada ou salva, abrir “Máximo possível” na função nativa.
- Prioridade: build aplicada no Elenco → última build salva → Máximo possível.
- F5 na Ficha continua abrindo o Máximo possível da função nativa.

## Unicidade do card no Elenco

- Um card pode ter várias builds salvas.
- O mesmo card não pode ocupar mais de uma ocorrência no conjunto Campo + Reservas + Fora do banco.
- Movimentar transfere a ocorrência existente; nunca cria uma cópia.
- Identidade é determinada pelo card_id canônico, não por nome, arte, posição ou build.

## Adicionar ao Elenco

- A Ficha terá o botão textual “＋ Adicionar ao Elenco” depois de “Builds salvas”.
- Se o card já pertence ao Elenco, a ação muda para o estado “✓ No Elenco” e não cria segunda ocorrência.
- O fluxo de destino oferece Titular, Reservas e Fora do banco em uma janela escura intermediária.
- Titular e Reservas lotados aparecem apagados e bloqueados antes do clique.
- Reservas e Fora do banco recebem o card no fim da lista, preservando a organização do usuário.
- Titular mostra somente vagas vazias e compatíveis para escolha.
- Uma build salva visível na Ficha entra aplicada no card.
- Uma build construída e ainda não salva exige salvamento; após o sucesso, o fluxo de destino é retomado.
- Se não houver nenhuma build do usuário carregada, o card entra com a Básica.

## Janela única de seleção de jogador

- Todas as entradas genéricas de adição usam a mesma janela e o mesmo controlador: botão flutuante, vaga vazia e botões legados.
- A Ficha é a exceção: o jogador já é conhecido e a busca é pulada.
- Pelo botão flutuante, a busca consulta o catálogo inteiro pelo nome e abre sem sugestões iniciais.
- Pela vaga vazia, a janela consulta somente jogadores que já pertencem ao Elenco e podem ser transferidos para aquela vaga.
- O contexto da vaga mostra filtros apenas pelas posições aceitas; não exibe a lista global de funções.
- Um candidato incompatível, com pontuação total zero em todas as posições aceitas, não aparece.

## Vagas, posições e controles do Elenco

- A moldura vazia deve ter o mesmo footprint da moldura quando há um card, sem invadir vagas vizinhas.
- A vaga mostra posições aceitas, nunca uma função fixa. Exemplo aprovado: VOL, MLD, MLG e MAT.
- No card inserido: posição selecionada em destaque; posições possíveis não selecionadas mais apagadas; posição impossível permanece visível em vermelho apagado, sem mostrar zero.
- Movimentação ocorre por degraus: Campo ↓ Reservas; Reservas ↑ Campo ou ↓ Fora; Fora ↑ Reservas.
- Não existem saltos diretos entre Campo e Fora do banco.
- O botão X de remover existe somente em Fora do banco.
- Nos cards compactos, posição fica no canto superior esquerdo e pontuação total no canto superior direito.
- Em Fora do banco, cada linha de cards é centralizada como bloco, com sobra simétrica nas laterais e sem esticar os cards.
