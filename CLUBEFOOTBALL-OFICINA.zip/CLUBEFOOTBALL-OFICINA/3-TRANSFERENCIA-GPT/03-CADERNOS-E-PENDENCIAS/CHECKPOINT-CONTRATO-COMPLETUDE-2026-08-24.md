# Checkpoint seguro — contrato de completude

**Capturado em:** 24/08/2026, `09:18:28Z`  
**Estado:** transações encerradas; zero lock aguardando; zero transação ativa acima de cinco minutos.

## Persistido no Supabase

- migrations `20260824090848` e `20260824091034` concluídas;
- 3 cards no staging, todos `incompleto` e em quarentena;
- 6 avaliações históricas, 3 atuais;
- 0 linhas no gate de publicação;
- 0 linhas em `public.cards_completos`;
- 0 linhas em `motor_input_v2`;
- 20 resultados principais, 20 bônus e 20 builds históricos preservados;
- 0 builds de usuário v2.

## Classificação local concluída

- 42.806 esperados/recebidos/classificados;
- 0 completos/publicáveis;
- 42.806 incompletos;
- 0 pendentes;
- 0 falhos;
- 9 shards válidos, zero divergência de hash;
- nenhuma carga ampla no Supabase foi iniciada.

## Retomada idempotente

1. Não repetir a classificação enquanto os hashes/fontes forem iguais; o CSV e o manifesto já congelam o resultado.
2. Após corrigir fontes, executar novamente a mesma regra versionada; hashes iguais não multiplicam avaliações.
3. Não carregar o universo no Supabase sem novo planejamento temporal e checkpoint por lote.
4. Não iniciar motor para card incompleto.
5. Produção de motor é externa; testes Codex exigem contagem 1–20 e falham fechado em 21+.

## Operações pendentes

- enriquecer/resolver as autoridades ausentes;
- reclassificar após a correção;
- somente se houver cards completos, planejar staging amplo e processamento externo;
- frontend permanece sem migração/feature flag.

Nenhuma operação está rodando. O computador pode ser desligado sem deixar transação ou carga pela metade.
