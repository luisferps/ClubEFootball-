# Fila de decisões para a retomada — 42.806 cards

**Estado:** preparada durante a pausa, sem pedir decisão e sem executar qualquer alternativa.  
**Regra vigente preservada:** nenhum card incompleto foi promovido; nenhuma autoridade ou criticidade foi alterada.

## 1. Autoridade dos dados-base

**Problema:** `cards_base` só encontra 3.268 dos 42.806 cards. O raw congelado eFootballDB contém dados-base aparentes para todos, mas hoje ele só está aprovado como autoridade de ímpetos e Boxes.

| Alternativa | Impacto | Risco |
|---|---|---|
| A. Manter Vigia como única autoridade e localizar/obter snapshot completo por `card_id` | Preserva integralmente a arquitetura aprovada | Pode exigir nova coleta e adiar a publicação ampla |
| B. Autorizar eFootballDB também para base, após normalização e comparação próprias | Pode cobrir tecnicamente 42.806 sem nova coleta | Muda a autoridade e exige validação campo a campo ainda não realizada |
| C. Manter Vigia como autoridade e usar eFootballDB apenas em staging comparativo | Permite detectar e preparar lacunas sem promover valor não homologado | Ainda depende de Vigia para decisão final |

**Recomendação:** C como próximo passo seguro; só migrar para A ou B após evidência e decisão explícita.

## 2. Autoridade da arte do card

**Problema:** há URL explícita do eFootballHub para 9.718 cards canônicos; faltam 33.088. O Supabase Storage está vazio.

| Alternativa | Impacto | Risco |
|---|---|---|
| A. Aprovar eFootballHub apenas para arte e buscar outra fonte para os restantes | Aproveita imediatamente 22,70% | Exige validação de licença/estabilidade e mantém cobertura parcial |
| B. Definir uma nova autoridade única de arte para todos | Contrato uniforme | Exige nova coleta/fonte |
| C. Tornar arte opcional e exibir placeholder explícito | Não bloqueia catálogo nem cálculo | Produto fica visualmente incompleto até enriquecimento |

**Recomendação:** C no contrato técnico; A somente após validação da fonte. Nenhuma dessas opções foi aplicada.

## 3. Criticidade e completude

**Problema:** a regra atual transforma ausências de apresentação ou de módulos específicos em bloqueio global, produzindo 0/42.806 publicáveis.

| Alternativa | Impacto | Risco |
|---|---|---|
| A. Manter completude global rígida | Máxima cautela | Nenhum card amplo entra enquanto toda arte/data/Box/resultado não estiver preenchido |
| B. Separar `catalog_ready`, `calculation_ready`, `boxes_ready` e `ranking_ready` | Cada tela recebe apenas cards aptos ao seu contrato; ausência opcional não bloqueia cálculo | Exige atualização versionada da regra e testes de contrato |
| C. Núcleo obrigatório único mais lista de pendências opcionais | Modelo mais simples | Menos precisão entre módulos |

**Recomendação:** B, com promoção fail-closed em cada estado. A regra atual permanece intacta até decisão.

## 4. `player_id` autoritativo

**Evidência:** `base_pes_id` existe nos 42.806; forma 27.095 jogadores-base. Em 20.850 cards ele difere do `card_id`; 5.596 jogadores têm várias versões.

- Alternativa segura: formalizar `player_id = base_pes_id`, preservando `card_id` como identidade da versão.
- Alternativa rejeitada tecnicamente: derivar por módulo, nome ou aritmética do `card_id`.
- **Recomendação:** aprovar o mapeamento direto após três testes de contrato no frontend shadow.

## 5. Data do card versus data da Box

**Problema:** `cards_lancamento`/PESMaster e `variation_details`/eFootballDB têm semânticas e valores divergentes.

- Alternativa A: data do card opcional, com data da Box sempre vinda do catálogo de Boxes.
- Alternativa B: escolher uma autoridade específica de lançamento do card após auditoria.
- **Recomendação:** A; nunca preencher uma com a outra.

## 6. Corpo/modelo físico detalhado

**Problema:** a fonte eFootballHub cobre aproximadamente 9.718 cards, sem fonte local ampla homologada para o restante.

- Primeiro decidir quais medidas são realmente usadas pelo motor/visual.
- Se obrigatórias: escolher autoridade e obter cobertura restante.
- Se não usadas: mantê-las como enriquecimento, não como bloqueador.
- **Recomendação:** provar o consumo real antes de qualquer coleta.

## 7. Próximo passo agrupado quando o usuário voltar

1. Homologar autoridades de base e arte.
2. Homologar a matriz de criticidade por módulo.
3. Confirmar `base_pes_id` como `player_id`.
4. Reexecutar a classificação **somente local/read-only** com a regra escolhida e comparar as contagens.
5. Somente depois decidir se haverá staging amplo; promoção, motores e frontend continuam com gates próprios.

Nenhum gate manual deve ser executado durante a ausência.

