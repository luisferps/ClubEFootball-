# Auditoria local e plano pendente

Estado: preservado para cruzamento com os relatórios do Cloud. Não implementar antes da leitura integral de todos os arquivos enviados pelo usuário.

## Escopo e decisão de arquitetura

- Durante o desenvolvimento, os dados continuam persistidos no navegador.
- A estrutura local deve espelhar desde já a futura persistência no Supabase, sem acoplar as regras da Ficha e do Elenco ao mecanismo de armazenamento.
- A migração futura deve abranger todos os dados necessários ao produto, inclusive catálogo/Ficha e dados próprios do usuário.
- Dados próprios do usuário incluem cards possuídos, builds criadas, times, vagas do time, posição de cada card, função escolhida e build aplicada.
- A build aplicada pertence à vaga do time, não globalmente ao jogador.
- Cada usuário autenticado deverá acessar somente os próprios registros.

## Três defeitos confirmados no caso do Modric

### 1. A mesma build abre com fotografias diferentes na Ficha

Exemplo observado: `Meia Armador 3` abriu uma vez com nota 108,13 e zero habilidades adicionadas e outra vez com nota 110,42 e cinco habilidades, mantendo Roberto Martinez.

Causa encontrada: a restauração não é atômica. O caminho correto é `bldEdita -> fotoDaBuild -> aplicaNaTela`, mas dentro de `aplicaNaTela` ainda existem etapas que recalculam ou redesenham o card antes do estado final:

- `editImp -> _grava/reabrir`;
- `_grava(c,b.lvl) -> render`;
- `_trocaHabs(b.habs) -> render/reabrir`.

Solução proposta: aplicar função, barras, habilidades, ímpeto, grau e técnico sem renderizações intermediárias; ao final, recalcular uma única vez e fazer uma única renderização.

### 2. O aviso de build melhor não aparece corretamente

Causa encontrada: o comparador recalcula as builds candidatas usando o técnico atual do time, em vez de comparar as notas finais persistidas de cada build.

Regra definida pelo usuário:

- A nota final é calculada e gravada ao salvar ou alterar uma build.
- No Elenco, ler a nota atual aplicada na vaga.
- Filtrar as builds salvas do mesmo card e da mesma função.
- Comparar diretamente as notas finais persistidas, sem recalcular técnico, barras, habilidades ou ímpeto.
- Se houver nota maior, mostrar: `Você tem uma build melhor para esta função.`

### 3. Alterar uma vaga contamina outra, especialmente as vagas 6 e 7

Causa encontrada: a seleção atual grava a build por `card_id`, de forma global por jogador, e depois redesenha/normaliza o Elenco inteiro. Rotinas como `saneiaSlots` e `refazVaga` percorrem outras vagas e podem recalcular ou salvar campos que não foram clicados. Não foi encontrado erro no índice do clique; o problema é a falta de isolamento por vaga.

Solução proposta:

- Cada vaga deve ter identidade própria e guardar sua referência de build.
- A seleção deve receber explicitamente o índice da vaga.
- Atualizar e persistir somente a vaga clicada.
- Não normalizar nem salvar as vagas 6 e 7 juntas.
- Preservar a geometria e o estado das outras vagas durante qualquer renderização necessária.
- Validar especificamente que uma alteração na vaga 6 não muda nenhum campo da vaga 7.

## Estrutura de persistência planejada

### Build

Cada build deve ter identidade própria e guardar, no mínimo:

- usuário proprietário no futuro banco;
- identificador da build;
- card/jogador;
- nome;
- função;
- barras;
- habilidades adicionadas;
- ímpeto e seus dados aplicáveis;
- técnico;
- grau base persistível conforme regra vigente;
- demais insumos necessários para reconstrução;
- nota final já calculada;
- versão da fórmula/motor, se adotada no cruzamento final.

### Time e vagas

Separar:

- time do usuário;
- cards possuídos pelo usuário;
- vagas do time;
- card colocado em cada vaga;
- coordenadas/posição visual;
- função naquela vaga;
- referência da build aplicada naquela vaga.

### Camada de armazenamento

- Agora: navegador.
- Futuro: Supabase com autenticação e isolamento dos dados por usuário.
- Ficha e Elenco devem usar uma camada única de leitura/gravação, para que a troca do navegador pelo banco não altere as regras de negócio.

## Ordem de implementação proposta, ainda não autorizada para execução

1. Ler integralmente todos os relatórios do Cloud, linha por linha.
2. Confrontar cada achado externo com o código e com esta auditoria local.
3. Incorporar somente achados comprovados e resolver contradições antes de editar.
4. Fechar o modelo local que espelha a persistência futura.
5. Tornar a restauração da Ficha atômica e com uma única renderização final.
6. Isolar seleção e persistência por vaga do Elenco, com teste obrigatório das vagas 6 e 7.
7. Corrigir o aviso para comparar notas finais persistidas da mesma função.
8. Executar o teste completo com `Meia Armador 2` e `Meia Armador 3`: salvar, reabrir, alternar, atualizar a página, comparar aviso e verificar todas as vagas afetadas.
9. Só depois decidir, com o usuário, entre consolidar a camada atual ou reconstruir a camada de estado/renderização aproveitando layout, motor e fontes de dados.

## Pendências paralelas já conhecidas

- Propagação da identidade do ímpeto até a Ficha para distinguir de forma autoritativa variantes fixas e condicionais; não inferir pelo nome ou nível.
- Revisão da quantidade real de vagas adicionais de ímpeto usando os dados autoritativos do card, sem inferir pelo número de ímpetos nativos.
- Verificação do recarregamento no Ranking que pode reabrir uma Ficha anterior.
- Lógica dinâmica do grau condicional no Elenco foi explicitamente adiada para uma etapa futura.

