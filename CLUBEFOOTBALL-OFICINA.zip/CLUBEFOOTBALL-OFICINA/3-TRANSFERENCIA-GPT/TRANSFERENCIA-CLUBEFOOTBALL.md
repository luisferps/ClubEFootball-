# Transferência do projeto ClubEfootball

Data do fechamento: 25/08/2026. Este documento separa fato comprovado de lacuna. Onde não há prova, está escrito **não sei**. A montagem deste pacote não fez nenhuma escrita no Supabase.

## 0 · O CADERNO DE PENDÊNCIAS

Não existia um único caderno central. Os documentos de controle encontrados foram copiados integralmente, sem resumo, para `03-CADERNOS-E-PENDENCIAS/`:

1. `CHECKPOINT-RETOMADA-TAREFA-5-2026-08-24.md` — estado das páginas novas do Elenco.
2. `CHECKPOINT-COMO-FUNCIONA-2026-08-24.md` — estado da página Como funciona.
3. `FILA-DECISOES-RETOMADA-42806.md` — fila da reconstrução/carga; algumas linhas ficaram superadas pelos relatórios finais, mas o original foi preservado.
4. `auditoria-local-e-plano-pendente.md` — auditoria e plano anterior.
5. `DECISOES-COMERCIAIS-CLUBEFOOTBALL.md` — decisões comerciais registradas.
6. `CHECKPOINT-CONTRATO-COMPLETUDE-2026-08-24.md`.
7. `CHECKPOINT-PAUSA-ENRIQUECIMENTO-2026-08-24.md`.
8. `CHECKPOINT-SEGURO-TRIO-V2-2026-08-24.md`.
9. `TAREFAS-QUE-FALTAM.html` e `CONSERTOS-PENDENTES.html` — documentos antigos do projeto, preservados como histórico.
10. A pasta `05-TAREFA-7-EFHUB/` contém o estado integral disponível do coletor e seus relatórios.

Não conheço outro caderno privado fora desses arquivos.

## 1 · OS ÍMPETOS ERRADOS

### a) Quantidade e lista

O universo final comprovado foi de **870 card_ids únicos com divergência de ímpeto no legado**, não apenas 600–700. A divisão foi:

- **699** prontos para reconstrução;
- **127** excluídos por ambiguidade;
- **44** pendentes por fonte incompleta;
- 2 IDs apareciam em mais de uma condição e receberam precedência de exclusão ambígua.

A lista integral está em `01-IMPETOS/LISTA-RECONSTRUCAO-IMPETOS-LEGADOS-V1.csv` e `.jsonl`. O resumo, manifesto, validação e gerador estão na mesma pasta.

Existiram auditorias anteriores com escopos menores, inclusive 161 IDs de base que afetavam 1.015 builds e 1.387 linhas da tela, e um conjunto histórico de 261 cards marcados como vaga livre. Esses números não são a lista final; a relação final desta entrega é a de 870.

### b) O que estava errado e causa

Não era um único defeito. A lista registra divergências de identidade/estado do ímpeto, slot, efeito e metadados. Um erro comprovado foi interpretar ausência de booster como vaga livre. A regra correta da fonte é: vaga somente quando `booster_type=4`, `booster_sub_type=4` e `up_point=1`. Campos todos nulos significam sem ímpeto/sem vaga, não vaga livre. Também havia IDs de catálogo ambíguos e reconstruções antigas que não podiam ser promovidas com segurança.

### c) Onde foi corrigido

A correção segura foi carregada apenas no modelo canônico novo, ligado pelo `card_id` original, em `clubef_read_v2.card_impulses_v2`. **Não foi aplicada** sobre o legado `public.cards_base`, `public.card_impeto`, `public.builds`, `public.tela_encaixe` nem nos arquivos do site. A proposta de reconstrução do legado ficou explicitamente **sem execução**.

### d) Notas recalculadas

Não. O motor não foi executado nessa tarefa. Portanto `builds.b1` e as linhas/valores já gravados em `tela_encaixe` não foram recalculados depois da correção canônica.

### e) Como foi detectado

Comparação por `card_id` entre a fonte normalizada do eFootballDB e as relações legadas de `cards_base`/`card_impeto`/catálogo de ímpetos, com exclusão fail-closed de casos ambíguos e incompletos. O script reproduzível é `01-IMPETOS/GERAR-LISTA-RECONSTRUCAO-IMPETOS.ps1`.

## 2 · AS 6.824 LINHAS COPIADAS NA `tela_encaixe`

### a) Quem/processo

O fluxo compatível encontrado é o gerador antigo `gera_encaixe.py`, seguido de `sobe_a_tela.py` ou do acionador manual `subir_as_linhas_agora.py`. Ele faz upsert por `(card_id, funcao)`. **Não sei quem executou o comando específico** que inseriu as 6.824 linhas; não encontrei log de execução nominal. As linhas de rótulo foram geradas em 17/08/2026, entre 19:19:46 e 19:19:47 UTC.

### b) Processo ativo/recriação

No banco não foi encontrado cron que escreva em `tela_encaixe`, nem trigger que recrie essas cópias. Os três triggers atuais só atualizam `public.topos_funcao` após INSERT/UPDATE/DELETE. No código local, a subida automática só ocorre quando existe o arquivo-sinal `SOBE-A-TELA.txt`; não confirmei que esse sinal esteja ativo em outra máquina. Se o gerador for rodado de novo com os rótulos novos, ele pode voltar a fazer upsert dessas chaves.

### c) Por que incompleta

O uploader não faz uma sincronização integral nem apaga os nomes antigos: ele envia apenas o conjunto `D` produzido naquela execução. A troca de `funcoes.nome` por `funcoes.rotulo` transformou a mesma função em outra chave textual, deixando os nomes velhos e inserindo somente os rótulos presentes em `D`. Não encontrei log que prove o filtro exato aplicado naquela execução; portanto **não sei** o critério final que limitou as cópias a 6.824.

### d) Por que `forca` ficou NULL

As linhas foram inseridas em 17/08. O envio com `forca` é a versão posterior `v2-forca`, introduzida em 18/08. Isso explica por que todas as 6.824 linhas antigas têm `forca` nula.

## 3 · QUEM ESCREVE NA `tela_encaixe`

### a) Cozinheiro

- Gerador: `ClubEfootball-V3/programas/gera_encaixe.py`.
- Uploader: `ClubEfootball-V3/programas/sobe_a_tela.py`.
- Acionador manual: `ClubEfootball-V3/programas/subir_as_linhas_agora.py`.
- Orquestrador diário: `ClubEfootball-V3/programas/rodada_diaria.py`, etapa 8.
- O uploader grava `card_id`, `funcao`, `linha`, `forca` e `gerado_em`, com conflito em `(card_id,funcao)`.

### b) Triggers/funções/rotinas encontradas

Triggers em `public.tela_encaixe`:

- `tela_encaixe_atualiza_topos_insert`;
- `tela_encaixe_atualiza_topos_update`;
- `tela_encaixe_atualiza_topos_delete`.

Funções chamadas: `private_topos.atualizar_topos_apos_insert`, `..._update` e `..._delete`; elas recalculam `public.topos_funcao`. Também existem funções antigas que leem builds/tela (`private.atualizar_ficha_final_base_v1`, `v3`, `private_topos.recalcular_topo_funcao`, `recalcular_topos_funcao` e `public.congelar_boxes_atuais`). Nenhuma delas foi identificada como recriadora automática das 6.824 cópias. Não havia trigger de usuário em `builds` nem cron referenciando `builds`/`tela_encaixe`.

### c) Tabela ou view

`public.tela_encaixe` é **tabela física**. A arquitetura antiga cozinhava o resultado fora do banco e o persistia como projeção pronta para o site. Não achei um documento que atribua nominalmente essa decisão; **não sei** quem a tomou.

## 4 · A COLUNA `builds.funcao_codigo`

Situação confirmada: 10.644 preenchidas em 17.798. Não encontrei backfill, trigger ou cron ativo para completar a coluna. **Não sei quem iniciou o preenchimento nem qual execução o interrompeu.** O padrão é compatível com resultados mais novos do motor que já levavam o código, enquanto linhas antigas ficaram sem ele. O plano registrado era usar `funcao_codigo` como identificador estável, sem depender dos nomes/rótulos mutáveis; documentos antigos ainda mandavam usar `funcao` porque o preenchimento era parcial.

## 5 · A CONSTANTE `MED`

Confirmado em `motor-e-ficha-base.js`: `Falso nove` e `Centroavante móvel` têm exatamente `b1n 99.2`, `b2 88.6`, `b3 68.3`, `b4 83.2`, `n 709`. Os perfis `ESTV` e pesos `FILA` dessas duas funções também estão duplicados. **Não sei a origem dos números nem encontrei prova de que a cópia foi intencional.**

Existem duplicidades intencionais entre nomes antigos e seus rótulos novos (por exemplo `Ponta criadora`/`Atacante criador`), pois são aliases da mesma função. Não sei apontar outra linha MED desatualizada com prova. Fragilidade conhecida: em tempo de execução o site recalcula `b1n`/contagem com os cards carregados, mas os demais valores da linha MED continuam constantes.

## 6 · MODO B / CADEADO COMERCIAL

A política comercial de esconder a build otimizada e vender o resultado por card+posição foi pedida/aprovada e está documentada em `03-CADERNOS-E-PENDENCIAS/DECISOES-COMERCIAIS-CLUBEFOOTBALL.md`. Porém, a apresentação específica como **MODO A/MODO B**, com aviso embutido em todas as páginas novas, foi decisão de implementação; não encontrei pedido textual do Luis com esses nomes.

O arquivo possui cinco rotas públicas novas (`melhorfuncao`, `timefraco`, `melhorformacao`, `tecnicotime`, `comparartime`) e `timeideal` interno. Não conheço outra decisão de produto não documentada além de escolhas de texto/layout feitas na implementação.

## 7 · `user-state-repository.js`

### a) Teste e rollback

A migração foi testada com fixtures sintéticas, **não com o estado real existente no Chrome do Luis**. Há journal transacional: estado `prepared` restaura a versão anterior; `committed` conclui na próxima abertura; falha de escrita tenta rollback imediato. O repositório mantém cópia compatível `MT_v1`, possui conversão reversa para V1 e os passos previam backups. Portanto não é estritamente de mão única, mas o rollback real em produção não foi homologado.

### b) O que falta em login/Supabase

Faltam autenticação real, um `SupabaseAdapter` com a mesma interface do adaptador local, modelo de dados de usuário/time/build/slots, RLS por `user_id`, importação inicial, regras de conflito/offline/merge e testes reais de migração/rollback. Nenhuma dessas partes foi concluída nesta fase.

## 8 · DIVERGÊNCIAS

### a) `Goleiro defensivo`

Há 168 linhas em `builds` e 48 em `tela_encaixe`: 120 builds ficaram sem espelho. **Não sei o critério exato** que excluiu esses 120; o uploader só grava o conjunto produzido por `gera_encaixe.py` e não garante espelho total.

### b) As 294 linhas

As 294 ausentes se distribuem assim: Goleiro defensivo 120; Goleiro ofensivo 44; Meia de lado por fora 27; Segundo atacante 21; Meia central de chegada 16; Ponta criadora 16; Centroavante fixo 7; Falso nove 7; Meia central armador 7; Volante de construção 6; Zagueiro de combate 6; Meia ofensivo armador 5; Ponta finalizadora 4; Volante de contenção 4; Lateral defensivo 2; Meia de lado por dentro 2. A consulta nominal completa não havia sido salva como artefato antes desta transferência; portanto não vou inventar a lista de card_ids.

### c) Colunas de nota

Confirmado: nas 17.798 linhas, `nota`, `b1n`, `b2`, `b4`, `b5` e `b4r` estão 100% NULL; `b1` está preenchido em 100%. O site/projeção vigente usa `b1`/`linha`. As outras colunas são legado não preenchido na versão atual; não servem como nota vigente.

## 9 · O QUE FOI MEXIDO NO SUPABASE

### Escritas confirmadas da Tarefa 4 — 24/25 de agosto

- Criação do modelo paralelo nos schemas `clubef_read_v2`, `clubef_stage_v2` e `clubef_user_v2`, seus contratos, índices, funções de ingestão/projeção, quarentena e permissões.
- Criação/restrição de `public.cards_completos` como leitura pública controlada.
- Carga canônica de 42.807 `card_id` únicos em `clubef_read_v2.cards_v2`: 42.806 cards da coleta + 1 sentinela.
- Carga de 59.224 habilidades, 85.612 slots de ímpeto, 2.014 boxes, 13.350 relações card-box, 17.798 alvos card-função e 2.080 pares validados de URLs de imagem.
- Cálculo das flags: cadastro nativo 0 sim/42.807 não; otimização 2.691 sim; bônus 2.699 sim; elegíveis com as três flags: 0.
- Batches 14 e 15 encerrados como `validated`, sem falhas.
- Tentativa de reconstrução larga de `card_projection_v2`; o armazenamento acabou. A parte inserida foi revertida e a projeção voltou ao checkpoint de 3 linhas. Como havia zero elegíveis, `public.cards_completos` permaneceu corretamente vazia.
- Não houve escrita da Tarefa 4 em `public.cards_base`, `public.builds`, `public.tela_encaixe`, motor ou arquivos do site.

Os relatórios, readback, manifesto, SQLs e rollbacks estão em `04-SUPABASE-CARGA-V4/`. O manifesto final tem SHA-256 `42B0034E73DC539CC0E336E607F2A9CB2611E34675C6E8F8F6523BB37A4159AC`.

### Histórico anterior

O banco registra migrações anteriores para bônus por posição, boxes, topos dinâmicos, slots de ímpeto e `ficha_final`. Eu consigo listar o histórico, mas **não sei atribuir com segurança cada migração anterior a esta instância/agente apenas pelo catálogo do banco**. Não vou assumir autoria. Não há DELETE em massa do legado confirmado nesta entrega.

## 10 · PENDÊNCIAS DO SITE

1. A pasta-fonte contém 12 arquivos no nível principal, não 10, e também uma subpasta repetida com o mesmo nome/conteúdo; isso cria ambiguidade sobre qual cópia abrir. No ZIP foi colocada uma única cópia dos arquivos do nível principal.
2. O monólito antigo `TELA-CLUBEFOOTBALL-UNICA.html` convive com a versão modular e pode ser aberto por engano.
3. As páginas novas do Elenco ainda tinham validação visual manual pendente; `timeideal` permanecia interno.
4. `user-state-repository.js` só passou em fixtures; a migração do estado real e o caminho Supabase/login não foram homologados.
5. `motor-e-ficha-base.js` tem a duplicidade MED/FILA/ESTV de Falso nove e Centroavante móvel sem origem comprovada.
6. A identidade nativa do ímpeto ainda não foi propagada ao legado do motor/site; as builds e a tela não foram recalculadas após a correção canônica.
7. O frontend continua dependente das estruturas legadas (`tela_encaixe`/dados embutidos); não foi integrado ao novo `public.cards_completos`.
8. Há mais de um listener de navegação/`popstate` no conjunto modular; a página Como funciona tem um segundo tratamento de `popstate`. Não foi feita consolidação final.
9. Há timers/listeners globais herdados. A verificação sintática não substituiu a homologação visual completa de abrir Elenco, Ficha, Ranking, voltar, trocar posição e salvar build.
10. O comportamento estreito/mobile do Elenco tinha regressões conhecidas fora do escopo da última tarefa.
11. O cliente contém URL e chave publicável do Supabase; isso é aceitável somente com RLS correta. A parte de login/RLS de dados pessoais ainda não existe.
12. A integração final entre as novas páginas, o cadeado comercial e o entitlement real não foi implementada; há apenas comportamento visual/local.

## Fechamento

Este ZIP conserva os arquivos existentes como evidência. Não afirma que a base pública esteja pronta: `public.cards_completos` tinha zero linhas porque nenhuma carta cumpria simultaneamente os três critérios de publicação. O banco foi pausado por ordem do Luis e nenhuma carga adicional foi iniciada durante esta transferência.
