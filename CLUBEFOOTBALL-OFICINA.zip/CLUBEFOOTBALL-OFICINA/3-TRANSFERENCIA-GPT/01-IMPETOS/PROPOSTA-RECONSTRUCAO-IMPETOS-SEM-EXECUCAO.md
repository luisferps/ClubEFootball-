# Reconstrução futura dos ímpetos legados — proposta sem execução

Lista versionada: `1.0.0`  
Lote de detecção: `impulse-legacy-divergence-detection-20260824-v1`  
Estado: **nenhuma linha reconstruída; nenhuma escrita no Supabase**.

## Universo comprovado

A lista contém somente cards com par legado (`em_cards_base=True`), classificação `DIVERGENTE` e ao menos um campo `impetos.*` em `campos_divergentes` na comparação validada da Tarefa 2.

- 870 `card_id` únicos com divergência de ímpeto comprovada;
- 699 `pronto_para_reconstrucao`;
- 127 `excluido_ambiguo`;
- 44 `pendente_incompleto`;
- 0 card de cobertura nova/faltante misturado nesta lista;
- 0 reconstrução automática autorizada por este artefato.

Ambiguidade tem precedência sobre incompletude. Dois casos possuem ambas as marcas e permanecem entre os 127 excluídos ambíguos. A lista conserva o detalhe de ambas.

## Fontes

- Antiga: composição por campo de `public.cards_base`, `public.card_impeto`, `public.impeto` e `public.impeto_atributo`.
- Correta esperada: normalização canônica congelada de 42.806 cards derivada do eFootballDB.
- Chave: somente o `card_id` Konami original; nome é evidência visual, nunca chave.

Os hashes da comparação detalhada, da matriz de equivalência, do manifesto de comparação e do manifesto canônico ficam repetidos em cada linha/manifesto. Assim, regenerar com uma fonte diferente falha antes de produzir nova lista.

## Fronteira aprovada para a reconstrução

Esta Tarefa 4 **não reconstrói linhas de ímpeto**, não executa motor e não escreve no Supabase. Seu produto terminal é o pacote auditável de handoff para a futura Tarefa 8.

- A lista de 699 `card_id` prontos é um conjunto de seleção, não uma fila executável por si só.
- Os 127 ambíguos e 44 incompletos permanecem excluídos da reconstrução automática.
- A execução real pertence aos motores existentes no repositório do usuário, incluindo Motor Principal/Otimização e Motor de Bônus.
- A lógica interna dos motores deve permanecer. A mudança arquitetural é somente de I/O: substituir JSON baixado por uma porta de entrada determinística do banco e importar os JSON de resultado em autoridades de saída separadas.
- Nenhum resultado pode ser gravado na tabela/view de entrada, em staging de insumos ou no legado.

## Como a futura Tarefa 8 deverá funcionar

1. Criar um `rebuild_batch` específico de ímpetos com a versão da lista e o SHA-256 do manifesto.
2. Materializar nas autoridades canônicas de entrada somente os 699 `card_id` prontos, depois das mesmas validações de slots e proveniência. Ambíguos e incompletos continuam fora.
3. Para cada card pronto, extrair do canônico os slots previstos pelo contrato, preservando identidade, tipo/subtipo/categoria, `up_point`, 26 deltas, 7 campos de condição, estado preenchido/vaga/nulo e proveniência. Não inventar slot 3 nem converter catálogo duplicado por nome.
4. Gerar as combinações `card_id + funcao_codigo` somente pela porta `clubef_read_v2.motor_input_v2`. A lista de 699 cards não autoriza inferir funções.
5. Exportar payload, `input_version`, algoritmo e `input_hash` da porta estável; adaptar esse payload em memória para o formato atualmente consumido pelo motor. Não alterar fórmulas, podas ou regras internas.
6. Executar os motores fora deste ambiente, no sistema do usuário. Motor Principal/Otimização e Motor de Bônus mantêm saídas discriminadas e o bônus referencia explicitamente o resultado principal correspondente.
7. Importar resultados somente nas autoridades `motor_optimization_results_v2`, `motor_bonus_results_v2` e, quando aprovado, `global_optimized_builds_v2`. Resultado reprovado ou falho não substitui a versão válida anterior.
8. Projetar apenas resultados aprovados para `card_functions_v2`, depois `card_projection_v2` e finalmente `public.cards_completos`.
9. Readback obrigatório: contagem esperada por `card_id + funcao_codigo`, hashes iguais entre entrada e resultados, ausência dos 127+44 excluídos, histórico preservado e fingerprints legados intactos.

## Rollback do lote futuro da Tarefa 8

- identificar exclusivamente as linhas importadas pelo `execution_id`/`batch_id` e pelos hashes de entrada;
- retirar da projeção somente os resultados desse lote e restaurar os ponteiros `is_current` capturados antes da importação;
- remover em transação apenas os novos resultados/builds do lote, na ordem inversa das FKs;
- restaurar dados canônicos de ímpeto apenas se a Tarefa 8 os tiver alterado e o snapshot/hashes anteriores coincidirem;
- reprocessar a projeção dos `card_id + funcao_codigo` afetados;
- comparar contagens/hashes pré e pós-rollback;
- nunca tocar nas quatro tabelas legadas citadas.

## Amostra de controle

- Diego Costa `88045487427597`: pronto; divergência comprovada em `impetos.booster2.estado`.
- Luka Modrić `106777181979954`: pronto; divergência comprovada em `impetos.booster.identidade.pes_id`.
- Jude Bellingham `89138556700485`: excluído da automação por ambiguidade comprovada de código de catálogo, embora possua outros campos divergentes. Não será promovido por inferência.

Esta separação é deliberada: a lista de reconstrução de ímpetos não é o catálogo de cards completos, não é a coleta de cards faltantes e não é a fila de imagens.
