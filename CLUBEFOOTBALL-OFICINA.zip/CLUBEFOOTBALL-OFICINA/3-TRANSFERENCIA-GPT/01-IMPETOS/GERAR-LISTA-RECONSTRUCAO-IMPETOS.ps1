param(
  [string]$ComparisonRoot = "C:\Users\Luis Fernando\Documents\Codex\2026-08-24\inventario-cards-ausentes-efootballdb\outputs\comparacao-somente-leitura-supabase-42806",
  [string]$CanonicalRoot = "C:\Users\Luis Fernando\Documents\Codex\2026-08-24\inventario-cards-ausentes-efootballdb\outputs\normalizacao-canonica-42806",
  [string]$OutputRoot = $PSScriptRoot
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$BatchId = "impulse-legacy-divergence-detection-20260824-v1"
$ListVersion = "1.0.0"
$DetailedPath = Join-Path $ComparisonRoot "COMPARACAO-DETALHADA-42806.csv"
$MappingPath = Join-Path $ComparisonRoot "MATRIZ-CAMPO-CANONICO-PARA-SUPABASE.csv"
$ComparisonManifestPath = Join-Path $ComparisonRoot "MANIFESTO-COMPARACAO-SHA256.json"
$CanonicalManifestPath = Join-Path $CanonicalRoot "MANIFESTO-NORMALIZACAO-CANONICA-42806.json"

$ExpectedHashes = [ordered]@{
  detailed = "2DBB35432C391333F1154E07E54DD5D825A10AB12F789AAFEDA5B81ECE4CFF27"
  mapping = "E50CC4B5C23568D7279979494C4403A7009E11F899238847243C6405A0AEA24D"
  comparison_manifest = "7B6BEF0F3C71BFD302E7F31DB6FFE7CD45634809FAF2C846D5DE12229C9C872F"
  canonical_manifest = "6D289FD0C6BB5CA85C8242B9885F8A112EA95402F0CA62DD5FCEC92B56106FD2"
}

function Get-Sha([string]$PathValue) {
  if (-not (Test-Path -LiteralPath $PathValue -PathType Leaf)) { throw "Arquivo ausente: $PathValue" }
  return (Get-FileHash -Algorithm SHA256 -LiteralPath $PathValue).Hash.ToUpperInvariant()
}

function Get-TextSha([string]$Value) {
  $sha = [Security.Cryptography.SHA256]::Create()
  try {
    $bytes = [Text.UTF8Encoding]::new($false).GetBytes($Value)
    return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace("-", "")
  }
  finally { $sha.Dispose() }
}

function Get-DomainTokens([string]$Value) {
  if ([string]::IsNullOrWhiteSpace($Value)) { return @() }
  return @($Value.Split('|') | Where-Object { $_ -like 'impetos.*' })
}

$ActualHashes = [ordered]@{
  detailed = Get-Sha $DetailedPath
  mapping = Get-Sha $MappingPath
  comparison_manifest = Get-Sha $ComparisonManifestPath
  canonical_manifest = Get-Sha $CanonicalManifestPath
}

foreach ($key in $ExpectedHashes.Keys) {
  if ($ActualHashes[$key] -ne $ExpectedHashes[$key]) {
    throw "Hash divergente em ${key}: esperado=$($ExpectedHashes[$key]) atual=$($ActualHashes[$key])"
  }
}

$rows = Import-Csv -LiteralPath $DetailedPath
$candidates = @($rows | Where-Object {
  $_.classe_comparacao -eq 'DIVERGENTE' -and
  @((Get-DomainTokens ([string]$_.campos_divergentes))).Count -gt 0
})

if ($candidates.Count -ne 870) { throw "Universo comprovado inesperado: $($candidates.Count)/870" }
if (@($candidates.card_id | Sort-Object -Unique).Count -ne 870) { throw "card_id duplicado no universo de impetos" }

$records = foreach ($row in ($candidates | Sort-Object { [decimal]$_.card_id })) {
  if ([string]$row.em_cards_base -ne 'True') { throw "Candidato sem par legado cards_base: $($row.card_id)" }

  $divergent = @(Get-DomainTokens ([string]$row.campos_divergentes))
  $incomplete = @(Get-DomainTokens ([string]$row.campos_incompletos))
  $ambiguous = @(Get-DomainTokens ([string]$row.campos_ambiguos))

  $status = if ($ambiguous.Count -gt 0) {
    "excluido_ambiguo"
  }
  elseif ($incomplete.Count -gt 0) {
    "pendente_incompleto"
  }
  else {
    "pronto_para_reconstrucao"
  }

  $legacySources = if ([string]$row.tem_card_impeto -eq 'True') {
    "public.cards_base|public.card_impeto|public.impeto|public.impeto_atributo"
  }
  else {
    "public.cards_base"
  }

  $canonicalEvidence = "normalizacao-canonica-42806/eFootballDB"
  $canonicalString = @(
    $ListVersion, [string]$row.card_id, ($divergent -join '|'),
    ($incomplete -join '|'), ($ambiguous -join '|'), $legacySources,
    $canonicalEvidence, $BatchId, $status, $ActualHashes.detailed,
    $ActualHashes.comparison_manifest, $ActualHashes.canonical_manifest
  ) -join "||"

  [pscustomobject][ordered]@{
    list_version = $ListVersion
    detection_batch_id = $BatchId
    card_id = [string]$row.card_id
    nome_evidencia = [string]$row.nome_canonico
    status = $status
    campos_impeto_divergentes = $divergent -join '|'
    campos_impeto_incompletos = $incomplete -join '|'
    campos_impeto_ambiguos = $ambiguous -join '|'
    fonte_antiga = $legacySources
    fonte_correta_esperada = $canonicalEvidence
    em_cards_base = [string]$row.em_cards_base
    tem_card_impeto = [string]$row.tem_card_impeto
    estado_booster_canonico = [string]$row.estado_booster_canonico
    estado_booster_legado = [string]$row.estado_booster_legado
    estado_booster2_canonico = [string]$row.estado_booster2_canonico
    estado_booster2_legado = [string]$row.estado_booster2_legado
    estado_booster3_canonico = [string]$row.estado_booster3_canonico
    estado_booster3_legado = [string]$row.estado_booster3_legado
    comparacao_detalhada_sha256 = $ActualHashes.detailed
    comparacao_manifest_sha256 = $ActualHashes.comparison_manifest
    canonical_manifest_sha256 = $ActualHashes.canonical_manifest
    record_sha256 = Get-TextSha $canonicalString
  }
}

$ready = @($records | Where-Object status -eq 'pronto_para_reconstrucao')
$ambiguousExcluded = @($records | Where-Object status -eq 'excluido_ambiguo')
$incompletePending = @($records | Where-Object status -eq 'pendente_incompleto')
if ($ready.Count -ne 699 -or $ambiguousExcluded.Count -ne 127 -or $incompletePending.Count -ne 44) {
  throw "Distribuicao inesperada: ready=$($ready.Count) ambiguous=$($ambiguousExcluded.Count) incomplete=$($incompletePending.Count)"
}

if (-not (Test-Path -LiteralPath $OutputRoot)) { New-Item -ItemType Directory -Path $OutputRoot | Out-Null }
$csvPath = Join-Path $OutputRoot "LISTA-RECONSTRUCAO-IMPETOS-LEGADOS-V1.csv"
$jsonlPath = Join-Path $OutputRoot "LISTA-RECONSTRUCAO-IMPETOS-LEGADOS-V1.jsonl"
$summaryPath = Join-Path $OutputRoot "RESUMO-LISTA-RECONSTRUCAO-IMPETOS-V1.json"
$manifestPath = Join-Path $OutputRoot "MANIFESTO-LISTA-RECONSTRUCAO-IMPETOS-V1.json"

$records | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding utf8
$jsonLines = @($records | ForEach-Object { $_ | ConvertTo-Json -Compress -Depth 5 })
[IO.File]::WriteAllLines($jsonlPath, $jsonLines, [Text.UTF8Encoding]::new($false))

$summary = [ordered]@{
  list_version = $ListVersion
  detection_batch_id = $BatchId
  snapshot_date = "2026-08-24"
  universe_rule = "classe_comparacao=DIVERGENTE and campos_divergentes contains impetos.*"
  total_proven_impulse_divergence = $records.Count
  ready_for_reconstruction = $ready.Count
  excluded_ambiguous = $ambiguousExcluded.Count
  pending_incomplete = $incompletePending.Count
  automatic_reconstruction_allowed_now = $false
  database_writes = 0
  comparison_detailed_sha256 = $ActualHashes.detailed
  mapping_sha256 = $ActualHashes.mapping
  comparison_manifest_sha256 = $ActualHashes.comparison_manifest
  canonical_manifest_sha256 = $ActualHashes.canonical_manifest
}
[IO.File]::WriteAllText($summaryPath, ($summary | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))

$manifest = [ordered]@{
  manifest_version = "1.0.0"
  detection_batch_id = $BatchId
  files = @(
    [ordered]@{name=[IO.Path]::GetFileName($csvPath);bytes=(Get-Item -LiteralPath $csvPath).Length;sha256=Get-Sha $csvPath},
    [ordered]@{name=[IO.Path]::GetFileName($jsonlPath);bytes=(Get-Item -LiteralPath $jsonlPath).Length;sha256=Get-Sha $jsonlPath},
    [ordered]@{name=[IO.Path]::GetFileName($summaryPath);bytes=(Get-Item -LiteralPath $summaryPath).Length;sha256=Get-Sha $summaryPath}
  )
  source_files = @(
    [ordered]@{path=$DetailedPath;sha256=$ActualHashes.detailed},
    [ordered]@{path=$MappingPath;sha256=$ActualHashes.mapping},
    [ordered]@{path=$ComparisonManifestPath;sha256=$ActualHashes.comparison_manifest},
    [ordered]@{path=$CanonicalManifestPath;sha256=$ActualHashes.canonical_manifest}
  )
}
[IO.File]::WriteAllText($manifestPath, ($manifest | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
Write-Host "LISTA GERADA: total=$($records.Count) ready=$($ready.Count) ambiguous=$($ambiguousExcluded.Count) incomplete=$($incompletePending.Count)"
